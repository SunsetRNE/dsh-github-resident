/**
 * 合并包（@sunsetrne/dsh-github-resident-v2）· Host 半 / Deck 半边（数据层实现 · T3 #345）
 * 这是宿主入口：装配动态加载的各个工作模块与几十条宿主电话；实现都在各自文件里（#723 起刷新机制的 装配在 ./refresh/wiring.js），本文件只负责装配与注册。
 * 这套装配分组的「从哪来、为什么留在这里、搬走的实现去了哪」见 docs/design/837-host-index-wiring-ledger.md。
 */

// ===== 规范方言（dynamic dialect）：harness 为自由变量；pkg entry 提供 shim =====
export default {
  // 合并后归户到单包身份（真源 tools/merge/merge-identity.ts 的 MERGED_PACKAGE_NAME；本文件在 deck/ 内不能运行期 import 那份 .ts，字面由 tests/merge/host/identity-parity 逐项核对）。槽位 id / 右栏 tab 类型 id / localStorage 键**不跟着改**，那些是用户既有布局的把手。
  name: '@sunsetrne/dsh-github-resident-v2', // connection + llm + sessionQuery：webServer 仍不加（#596）；llm 给首轮摘要调模型用，sessionQuery 给读首轮两段用（读而不激活），缺任何一个对应功能静默降级（#746）。
  inject: ['connection', 'llm', 'sessionQuery'],
  apply(ctx) {
    // 2026-10-12 gh 解析点归一：Resident 半边把**它那份唯一的 gh 解析器**以服务 `ghResolver` 借给本半边
    //（系统 gh → 插件自带缓存 → 自动落地），Deck 从此不再自己认 PATH / DSH_GH_PATH —— 一个插件只有一个
    //"gh 在哪"的答案。写成晚绑定取值口（合并宿主先跑 Deck 后跑 Resident，服务要等用到 gh 时才在）；
    //  没有那个服务时（单独运行 / 源码态 / 门禁夹具）回 null，平台层行为与从前逐字一致。
    const ghResolver = function () {
      try { const svc = ctx.get('ghResolver'); return (svc && typeof svc.resolve === 'function') ? svc.resolve() : null } catch (eSvc) { return null }
    }
    // 启动门（2026-09-26）：subprocess/timer 晚到时不再静默跳过——旧代码直接 return， wiring 与工具注册 hook 从没跑起来，deck 工具永不注册还查无对证。 先试一次；不齐就挂到框架依赖门上等人齐（官方 ctx.inject 写法，见 dsh-tool-pwsh）； 30 秒还没齐落一条 warn。 为何只能留在入口，见账本 §1。
    const bootBody = () => {
    const subprocess = ctx.get('subprocess')
    const timer = ctx.get('timer')
    const fs = ctx.get('fs')
    if (subprocess === undefined || timer === undefined) return false

    // H1 #445：bundled provider（原 31–215 行）已搬到 ./bootstrap.js；B3 rpc shim 与「方案 C 原样复制」的原委见 docs/design/837-host-index-wiring-ledger.md §2，下接动态接线与分发注册。
    const __DSW_HANDLERS__ = new Map()
    // harness.handle 压成一行写法：本文件顶 350 行上限，省下的行留给真正要读的接线说明（见账本 §1）。
    const harness = { handle: (method, fn) => { __DSW_HANDLERS__.set(String(method).replace(/^wf\./, ''), fn) } }
    // ============ 配置 ============
    // v1.5.0（公共发布）：兜底 gh 路径经 platform.env.get('DSH_GH_PATH')（#171 migrated，零直读 process.env）
    // 默认工作区 = DSH 进程当前目录（可被 wf.snapshot args.cwd 覆盖；去本机硬编码）
    const DEFAULT_CWD = (typeof process !== 'undefined' && typeof process.cwd === 'function') ? process.cwd() : ''
    const TIMEOUT_MS = 30000
    // v1.3.3 提速：快照缓存 5s → 60s（面板打开基本命中缓存，不再每次全量重建 11 次 gh 调用）
    const CACHE_MS = 60000
    // H1 #445：原 235–249 行（技能名单）已搬到 ./bootstrap.js。
    const QUERY = 'query($owner:String!,$name:String!,$n:Int!){repository(owner:$owner,name:$name){issue(number:$n){number title state body url labels(first:20){nodes{name}} subIssues(first:100){totalCount nodes{number title state body url labels(first:10){nodes{name}} assignees(first:10){nodes{login}} blockedBy(first:20){nodes{number title state}} }}}}}'
    // ============ 状态 ============
    // H1 #445：ghPath/ghLastError/repoKeys 留守——721 行外多处直接读写裸变量（env 上报读 ghPath/ghLastError；建仓失效删 repoKeys），只能由 index.js 单一持有，新文件经显式存取器访问。
    let ghPath = null
    // #195 修复：失败不永久缓存 —— ghLastError 仅保留最近一次失败（覆盖式），环境修复后下次 resolveGh 覆盖为 null；不像旧实现首次失败永不重试
    let ghLastError = null
    let repoKeys = {}  // v12：repoKey 按 cwd 缓存（切换仓库会话时不再串仓库）
    // #696 按工作区根分桶：单格改成表，每条含快照与时间（60秒有效），最多20条，超了丢最久没用的那条
    const snapshotByRoot = new Map()
    function touchSnapshotLRU(k, v) { if (snapshotByRoot.has(k)) snapshotByRoot.delete(k); snapshotByRoot.set(k, v); if (snapshotByRoot.size > 20) snapshotByRoot.delete(snapshotByRoot.keys().next().value) }
    function getCache(cwd) { if (cwd == null) return { ts: 0, snapshot: null, error: null, cwd: null }; const k = String(cwd); const e = snapshotByRoot.get(k); if (e) { snapshotByRoot.delete(k); snapshotByRoot.set(k, e); return e } return { ts: 0, snapshot: null, error: null, cwd: k } }
    function setCache(v) { const c = v && v.cwd; if (!c) { snapshotByRoot.clear(); return } /* #696 清全部仅兼容旧调用（现宿主快照写路径都有目录，无生产调用走此分支） */ const k = String(c); if (v.ts === 0 && !v.snapshot && !v.error) { snapshotByRoot.delete(k); return } touchSnapshotLRU(k, { ts: v.ts, snapshot: v.snapshot, error: v.error, cwd: k }) }
    let userHome = null                                     // 保留占位（#171 已迁 platform.getHome，缓存归平台 memoize）
    // H1 #445：repoRoots 留守（建仓失效删裸变量）与 _detectionService 恒空留守（唯一引用是 wf.bind 内无动作空检查，有无值行为一致）。
    let repoRoots = {}           // 根路径按 cwd 缓存
    let _detectionService = null  // H1 #445 恒空留守：唯一裸引用是 wf.bind 处理器内无动作空检查（有无值行为一致）；真状态归 platformChannel 所有
    // H1 #445：原 259–491 行（注册表/平台/探测）已搬到 ./platformChannel.js。
    let lastProbeAtByRepo = {}                            // v1.5 R2 + R2-fix-6（#2 MVP）：probe since 时间戳，按 repoKey 隔离（只在 probe 检测到 change 时推进；build 不得动它 —— 否则会吞掉同窗口编辑，见 buildSnapshot 处注释）
    let lastIssueIndexByRepo = {}                          // #2 deletion fix：保存上次全量 issue 索引，用于发现 GitHub 删除/状态消失
    // #491 房外公共区埋点：宿主侧日志上下文（设计 #335 第 3 章房外行 + #489 白名单；房间目录文件一律不碰）。 fire 防火即发（只进队列就返回，不等写盘）；函数式字段在开关判断通过后才求值；isEnabled 供 P1 外层判断（权威仍是库体内兜底）。
    let logSwitchCache = false
    function fireLog(level, event, fieldsOrFn) { try { _log().then(function (h) { try { if (!h.isEnabled(level, event)) return; if (h.getSwitchState) { try { logSwitchCache = h.getSwitchState().enabled === true } catch (eC) {} } const fields = (typeof fieldsOrFn === 'function') ? fieldsOrFn() : fieldsOrFn; h.log(level, event, fields || {}) } catch (e) {} }).catch(function () {}) } catch (e) {} }
    function isLogEnabled(level) { if (level === 'error' || level === 'warn') return true; return logSwitchCache === true }
    const logCtx = { fire: fireLog, isEnabled: isLogEnabled }
    // H7 #515：分发异常行的两个纯函数（入参散列 shortArgHash + 错误归类 dispatchErrorKind，逐行原样）已搬到 ./dispatchMeta.js；此处只留动态加载器（D7 禁止静态 import）。
    let _dispatchMetaP = null
    function _dispatchMeta() { if (!_dispatchMetaP) _dispatchMetaP = import('./dispatchMeta.js').then(function(m){ return m.createDispatchMeta() }); return _dispatchMetaP }
    // ---- H1 #445 接线：3 新文件动态 import加载（D7 禁止静态 import），依赖全显式传入；新文件之间不互引用；harness 留守原因：harness.handle 在 apply 同步注册，动态 import 无法同步供给。 ----
    let _bootP = null
    function _boot() { if (!_bootP) _bootP = import('./bootstrap.js').then(function(m){ return m.createBootstrap({ ctx: ctx }) }); return _bootP }
    let _platP = null
    function _plat() { if (!_platP) _platP = (async function(){ const boot = await _boot(); const mod = await import('./platformChannel.js'); return mod.createPlatformChannel({ ctx: ctx, subprocess: subprocess, timer: timer, fs: fs, DEFAULT_CWD: DEFAULT_CWD, TIMEOUT_MS: TIMEOUT_MS, ghResolver: ghResolver, getMattSkillProbeNames: function(){ return getMattSkillProbeNames.apply(null, arguments) }, getChainSkillNames: function(){ return getChainSkillNames.apply(null, arguments) }, probeSkill: function(){ return probeSkill.apply(null, arguments) }, getChoiceStore: function(){ return getChoiceStore.apply(null, arguments) }, logCtx: logCtx, getGate: function () { return refreshGate } }) })(); return _platP } // #927：闸要晚一步才建好，所以传一个活的取值口，不传一次性快照
    let _repoP = null
    function _repo() { if (!_repoP) _repoP = (async function(){ const plat = await _plat(); const mod = await import('./repoKeys.js'); return mod.createRepoKeys({ subprocess: subprocess, timer: timer, fs: fs, DEFAULT_CWD: DEFAULT_CWD, TIMEOUT_MS: TIMEOUT_MS, repoKeys: repoKeys, repoRoots: repoRoots, getGhPath: function(){ return ghPath }, setGhPath: function(v){ ghPath = v }, getGhLastError: function(){ return ghLastError }, setGhLastError: function(v){ ghLastError = v }, getPlatform: function(){ return getPlatform.apply(null, arguments) }, getWorkspaceStore: function(){ return getWorkspaceStore.apply(null, arguments) }, setCache: setCache, clearWorkspaceStore: function(){ return plat.clearWorkspaceStore.apply(plat, arguments) }, namingSweepSoon: function(){ return namingSweepSoon.apply(null, arguments) }, getChainBackoff: getChainBackoff, parseGithubRepo: function(){ return parseGithubRepo.apply(null, arguments) }, logCtx: logCtx, getGate: function () { return refreshGate } }) })(); return _repoP } // #927：同上，取数层（runGh / 探测）报账时现问一次
    async function getMattSkillProbeNames() { const h = await _boot(); return h.getMattSkillProbeNames.apply(h, arguments) } async function getChainSkillNames() { const h = await _boot(); return h.getChainSkillNames.apply(h, arguments) } // #968 后者经 _boot 取链目录三项
    async function getTrackerRegistry() { const h = await _plat(); return h.getTrackerRegistry.apply(h, arguments) }
    async function getPlatform() { const h = await _plat(); return h.getPlatform.apply(h, arguments) }
    async function getWorkspaceStore() { const h = await _plat(); return h.getWorkspaceStore.apply(h, arguments) }
    async function detectionExec() { const h = await _plat(); return h.detectionExec.apply(h, arguments) }
    async function getDetectionService() { const h = await _plat(); return h.getDetectionService.apply(h, arguments) }
    async function getChoiceStore() { const h = await _plat(); return h.getChoiceStore.apply(h, arguments) } // #683（F1）：宿主侧那份记忆（H）归 platformChannel 单点持有（读它的是两处：绑定写入与判定读取；队列全进程只许一条。规则见 src/host/choiceStore.js 文件头）。
    async function resolveGh() { const h = await _repo(); return h.resolveGh.apply(h, arguments) }
    async function resetGhCache() { const h = await _repo(); return h.resetGhCache.apply(h, arguments) }
    async function runGh() { const h = await _repo(); return h.runGh.apply(h, arguments) }
    async function execProc() { const h = await _repo(); return h.execProc.apply(h, arguments) }
    async function resolveGit() { const h = await _repo(); return h.resolveGit.apply(h, arguments) }
    async function getHome() { const h = await _repo(); return h.getHome.apply(h, arguments) }
    async function canonicalKey() { const h = await _repo(); return h.canonicalKey.apply(h, arguments) }
    async function getRepoRoot() { const h = await _repo(); return h.getRepoRoot.apply(h, arguments) }
    async function getCacheDir() { const h = await _repo(); return h.getCacheDir.apply(h, arguments) }
    async function cacheFileName() { const h = await _repo(); return h.cacheFileName.apply(h, arguments) }
    async function readDiskCache() { const h = await _repo(); return h.readDiskCache.apply(h, arguments) }
    async function writeDiskCache() { const h = await _repo(); return h.writeDiskCache.apply(h, arguments) }
    async function getRepoKey() { const h = await _repo(); return h.getRepoKey.apply(h, arguments) }
    // #723（T19）：刷新机制在宿主里真的装起来（闸+账本+写事件订阅+视野模型+会话↔票处理链，实现整段在 ./refresh/wiring.js）。这个句柄是那套东西的唯一出口：_detectChain 从它取闸（3g），wf.chain 从它取界面读数。
    let _refreshWiringP = null, refreshGate = null
    try { _boot().catch(function(){}); _dispatchMeta().catch(function(){}); _refreshWiringP = import('./refresh/wiring.js').then(function (m) { return m.makeRefreshLoader({ ctx: ctx, logCtx: logCtx, getChoiceStore: function () { return getChoiceStore.apply(null, arguments) }, canonicalKey: function () { return canonicalKey.apply(null, arguments) }, getCacheDir: function () { return getCacheDir.apply(null, arguments) }, getTrackerRegistry: function () { return getTrackerRegistry.apply(null, arguments) }, getDetectionService: function () { return getDetectionService.apply(null, arguments) }, getPlatform: function () { return getPlatform.apply(null, arguments) }, detectionExec: function () { return detectionExec.apply(null, arguments) }, setCache: setCache, getCache: getCache, readDiskCache: function () { return readDiskCache.apply(null, arguments) }, writeDiskCache: function () { return writeDiskCache.apply(null, arguments) }, runGh: function () { return runGh.apply(null, arguments) }, getRepoKey: function () { return getRepoKey.apply(null, arguments) }, fetchIssueIndex: function () { return fetchIssueIndex.apply(null, arguments) }, issueIndexFromSnapshot: function () { return issueIndexFromSnapshot.apply(null, arguments) }, getNaming: function () { return _naming() } })() }).then(function (w) { refreshGate = (w && w.gate) || null; return w }) } catch (e0) {}
    try { _plat().then(function(pl){ try { pl.getTrackerRegistry().catch(function(){}) } catch (e1) {} }).catch(function(){}) } catch (e2) {}
    // ---- H2 #446 接线：3 新文件动态 import 加载（D7 禁止静态 import），依赖全显式传入；新文件之间不互引用 ---- 留守（行为零变化优先；调用方在 H4/H5/H6 的同步上下文里，动态加载给不出同步函数）：computeLevels/groupTickets（H4 三处同步分组）、isRateLimitError（H5 三处同步判别）、issueIndexFromSnapshot/issueIndexChanged/rememberIssueIndex（H6 探测同步取值与同刻写表）。 这一组的拆分缘由见账本 §3。
    let _mapBodyP = null
    function _mapBody() { if (!_mapBodyP) _mapBodyP = import('./mapBody.js').then(function(m){ return m.createMapBody() }); return _mapBodyP }
    let _issueListP = null
    function _issueList() { if (!_issueListP) _issueListP = (async function(){ const mod = await import('./issueList.js'); return mod.createIssueList({ getRepoKey: function(){ return getRepoKey.apply(null, arguments) }, runGh: function(){ return runGh.apply(null, arguments) }, setCache: setCache, issueIndexFromSnapshot: issueIndexFromSnapshot, issueIndexChanged: issueIndexChanged, rememberIssueIndex: rememberIssueIndex, readDiskCache: function(){ return readDiskCache.apply(null, arguments) }, logCtx: logCtx }) })(); return _issueListP }
    let _issueDetailP = null
    // #599：快照组装在 snapshotBuild.js（单票详情仍在 issueDetail.js）；两边共享的东西由这里组合后传进去 —— 同层互引门禁不许两个干活的文件互相引用，组合点落在入口（既有 25 条同形先例）。
    function _issueSnap() { let p = null; if (!p) p = (async function(){ const mod = await import('./snapshotBuild.js'); const detail = await _issueDetail(); const mb = await _mapBody(); const grp = await _group(); return mod.createSnapshotBuilder({ getRepoKey: function(){ return getRepoKey.apply(null, arguments) }, runGh: function(){ return runGh.apply(null, arguments) }, execProc: function(){ return execProc.apply(null, arguments) }, getTrackerRegistry: function(){ return getTrackerRegistry.apply(null, arguments) }, getPlatform: function(){ return getPlatform.apply(null, arguments) }, getRepoRoot: function(){ return getRepoRoot.apply(null, arguments) }, ctx: ctx, timer: timer, getGhPath: function(){ return ghPath }, getGhLastError: function(){ return ghLastError }, fetchIssues: function(){ return fetchIssues.apply(null, arguments) }, fetchMapsDetailREST: function(){ return fetchMapsDetailREST.apply(null, arguments) }, fetchMapsDetail: detail.fetchMapsDetail, mapTicket: mb.mapTicket, parseMapBody: mb.parseMapBody, computeLevels: grp.computeLevels, groupTickets: grp.groupTickets, isRateLimitError: isRateLimitError }) })(); return p }
    function _issueDetail() { if (!_issueDetailP) _issueDetailP = (async function(){ const mod = await import('./issueDetail.js'); return mod.createIssueDetail({ getRepoKey: function(){ return getRepoKey.apply(null, arguments) }, runGh: function(){ return runGh.apply(null, arguments) }, execProc: function(){ return execProc.apply(null, arguments) }, getTrackerRegistry: function(){ return getTrackerRegistry.apply(null, arguments) }, getPlatform: function(){ return getPlatform.apply(null, arguments) }, getRepoRoot: function(){ return getRepoRoot.apply(null, arguments) }, ctx: ctx, timer: timer, getGhPath: function(){ return ghPath }, getGhLastError: function(){ return ghLastError }, isRateLimitError: isRateLimitError }) })(); return _issueDetailP }
    async function normalizeBody() { const h = await _mapBody(); return h.normalizeBody.apply(h, arguments) } async function parseMapBody() { const h = await _mapBody(); return h.parseMapBody.apply(h, arguments) } async function parseProgress() { const h = await _mapBody(); return h.parseProgress.apply(h, arguments) } async function mapTicket() { const h = await _mapBody(); return h.mapTicket.apply(h, arguments) }
    async function fetchMaps() { const h = await _issueList(); return h.fetchMaps.apply(h, arguments) }
    async function fetchAllIssuesManual() { const h = await _issueList(); return h.fetchAllIssuesManual.apply(h, arguments) }
    async function fetchAllIndexManual() { const h = await _issueList(); return h.fetchAllIndexManual.apply(h, arguments) }
    async function fetchIssues() { const h = await _issueList(); return h.fetchIssues.apply(h, arguments) }
    async function fetchIssueIndex() { const h = await _issueList(); return h.fetchIssueIndex.apply(h, arguments) }
    async function fetchIssueIndexWindowed() { const h = await _issueList(); return h.fetchIssueIndexWindowed.apply(h, arguments) } async function commitIssueIndex() { const h = await _issueList(); return h.commitIssueIndex.apply(h, arguments) } // #723（T19c）第 E 件：水印的唯一推进口（只在变化真的并进列表之后调它）
    async function cacheSnapshotIsCurrent() { const h = await _issueList(); return h.cacheSnapshotIsCurrent.apply(h, arguments) }
    async function adoptSnapshot() { const h = await _issueList(); return h.adoptSnapshot.apply(h, arguments) }
    async function fetchMapsDetailREST() { const h = await _issueList(); return h.fetchMapsDetailREST.apply(h, arguments) }
    async function fetchMapsDetail() { const h = await _issueSnap(); return h.fetchMapsDetail.apply(h, arguments) }
    async function fetchIssueDetailREST() { const h = await _issueDetail(); return h.fetchIssueDetailREST.apply(h, arguments) }
    async function fetchIssueDetail() { const h = await _issueDetail(); return h.fetchIssueDetail.apply(h, arguments) }
    async function buildSnapshot() { const h = await _issueSnap(); return h.buildSnapshot.apply(h, arguments) }
    // ---- H3 #447 接线：3 新文件动态 import 加载，新文件之间不互引用 ---- 留守：parseGithubRepo 留守（repoKeys 同步调用）；链表由本块持有（按工作区根+后端+语言，30秒有效，最多20条）；harness.handle 注册留守。 这一组的拆分缘由见账本 §4。
    const chainByKey = new Map()
    function touchChainLRU(k, v) { if (chainByKey.has(k)) chainByKey.delete(k); chainByKey.set(k, v); if (chainByKey.size > 20) chainByKey.delete(chainByKey.keys().next().value) }
    function getChainCache(key) { if (!key) return { ts: 0, key: null, value: null }; const k = String(key); const e = chainByKey.get(k); if (e) { chainByKey.delete(k); chainByKey.set(k, e); return e } return { ts: 0, key: k, value: null } }
    function setChainCache(v) { if (!v || !v.key) { chainByKey.clear(); return } /* #696 清全部仅技能广播（无目录）与旧调用 */ touchChainLRU(String(v.key), { ts: v.ts, key: String(v.key), value: v.value }) }
    function invalidateChainCacheForKey(scopeKey) { try { const prefix = String(scopeKey) + '|'; for (const k of Array.from(chainByKey.keys())) { if (k === String(scopeKey) || k.indexOf(prefix) === 0) chainByKey.delete(k) } } catch {} } // #968 按工作区键只清一桶
    let _remotePredP = null
    function _remotePred() { if (!_remotePredP) _remotePredP = import('./remotePredicates.js').then(function(m){ return m.createRemotePredicates() }); return _remotePredP }
    let _skillProbeP = null
    function _skillProbe() { if (!_skillProbeP) _skillProbeP = (async function(){ const mod = await import('./skillProbe.js'); return mod.createSkillProbe({ ctx: ctx, getPlatform: function(){ return getPlatform.apply(null, arguments) }, getWorkspaceStore: function(){ return getWorkspaceStore.apply(null, arguments) }, resetChainCache: function(){ chainByKey.clear() } /* #696 不带工作区的技能广播才清全部链 */, resetChainCacheForKey: function(key){ invalidateChainCacheForKey(key) } /* #968 带工作区的广播只清那一桶 */, logCtx: logCtx }) })(); return _skillProbeP }
    let _detectChainP = null
    // #709（T5）：检查链退避的宿主薄壳（懒加载一次，之后复用）。它自己不排任何定时器。
    function getChainBackoff() {
      if (!getChainBackoff._p) getChainBackoff._p = (async function () { try { const mod = await import('./refresh/chainBackoff.js'); return mod.createChainBackoff({ logCtx: logCtx }) } catch (e) { return null } })()
      return getChainBackoff._p
    }
    function _detectChain() { if (!_detectChainP) _detectChainP = (async function(){ const mod = await import('./detectChain.js'); const w = _refreshWiringP ? await _refreshWiringP.catch(function(){ return null }) : null; const ghMod = await import('./tracker/backends/github/client.js').catch(function(){ return null }); return mod.createDetectChain({ gate: (w && w.gate) || null, ghTimeoutMs: ghMod ? ghMod.TIMEOUT_MS : 0, canonicalKey: function(){ return canonicalKey.apply(null, arguments) }, DEFAULT_CWD: DEFAULT_CWD, resetGhCache: function(){ return resetGhCache.apply(null, arguments) }, getDetectionService: function(){ return getDetectionService.apply(null, arguments) }, getPlatform: function(){ return getPlatform.apply(null, arguments) }, getTrackerRegistry: function(){ return getTrackerRegistry.apply(null, arguments) }, getRepoKey: function(){ return getRepoKey.apply(null, arguments) }, runGh: function(){ return runGh.apply(null, arguments) }, timer: timer, probeSkill: function(){ return probeSkill.apply(null, arguments) }, mdParseOkPredicate: function(){ return mdParseOkPredicate.apply(null, arguments) }, getChainCache: getChainCache, setChainCache: setChainCache, getChainBackoff: getChainBackoff, logCtx: logCtx, sandboxPolicyFor: function(info){ try { const cwd = String((info && info.cwd) || ''); const sid = String((info && info.sessionId) || ''); let svc = null; try { svc = ctx.get('sandboxPolicy') } catch(eG){ svc = null } if(!svc || typeof svc.resolve !== 'function') return Promise.resolve({ policy: undefined, sessionId: sid }); let sessionsSvc = null; try { sessionsSvc = ctx.get('sessions') } catch(eS){ sessionsSvc = null } let session = null; try { if(sid && sessionsSvc && typeof sessionsSvc.get === 'function') session = sessionsSvc.get(sid) || null } catch(eG2){ session = null } if(!session && sessionsSvc && typeof sessionsSvc.list === 'function' && cwd){ try { const keyOf = function(p){ return String(p||'').replace(/\\/g,'/').replace(/\/+$/,'').toLowerCase() }; const want = keyOf(cwd); const prefix = want + '/'; let all = []; try { all = sessionsSvc.list() || [] } catch(eL){ all = [] } const cwdOf = function(s){ try { if(!s || typeof s !== 'object') return ''; if(typeof s.cwd === 'string' && s.cwd) return s.cwd; if(s.header && typeof s.header.cwd === 'string' && s.header.cwd) return s.header.cwd; if(s.workspace && typeof s.workspace.cwd === 'string' && s.workspace.cwd) return s.workspace.cwd; if(s.workspaceRoot && typeof s.workspaceRoot === 'string') return s.workspaceRoot } catch(eC){} return '' }; const exact = []; const inside = []; for(const item of all){ const c = cwdOf(item); if(!c) continue; const k = keyOf(c); if(!k) continue; if(k === want) exact.push(item); else if(k.indexOf(prefix) === 0) inside.push(item) } if(exact.length === 1) session = exact[0]; else if(exact.length === 0 && inside.length === 1) session = inside[0] } catch(eF){} } if(!session) return Promise.resolve({ policy: undefined, sessionId: sid }); let policy = undefined; try { policy = svc.resolve({ session: session }) } catch(eR){ policy = undefined } let realId = sid; try { if(session && session.id) realId = String(session.id) } catch(eI){} return Promise.resolve({ policy: policy, sessionId: realId }) } catch(e){ return Promise.resolve({ policy: undefined, sessionId: String((info && info.sessionId) || '') }) } } }) })(); return _detectChainP }
    async function mdParseOkPredicate() { const h = await _remotePred(); return h.mdParseOkPredicate.apply(h, arguments) }
    async function mdMapCandidates() { const h = await _remotePred(); return h.mdMapCandidates.apply(h, arguments) }
    async function fileExistsChainRel() { const h = await _remotePred(); return h.fileExistsChainRel.apply(h, arguments) }
    async function probeFsExists() { const h = await _skillProbe(); return h.probeFsExists.apply(h, arguments) }
    async function directSkillCardRead() { const h = await _skillProbe(); return h.directSkillCardRead.apply(h, arguments) }
    async function directPathExists() { const h = await _skillProbe(); return h.directPathExists.apply(h, arguments) }
    async function findProjectRootDir() { const h = await _skillProbe(); return h.findProjectRootDir.apply(h, arguments) }
    async function probeCardViaFs() { const h = await _skillProbe(); return h.probeCardViaFs.apply(h, arguments) }
    async function probeCardViaDirect() { const h = await _skillProbe(); return h.probeCardViaDirect.apply(h, arguments) }
    async function evidenceSummary() { const h = await _skillProbe(); return h.evidenceSummary.apply(h, arguments) }
    async function isSkillCardValid() { const h = await _skillProbe(); return h.isSkillCardValid.apply(h, arguments) }
    async function lightProbeReason() { const h = await _skillProbe(); return h.lightProbeReason.apply(h, arguments) }
    async function probeSkill() { const h = await _skillProbe(); return h.probeSkill.apply(h, arguments) }

    // H2 #446 留守：upcaseState/upcaseSnapStates 留入口（H4 四处同步升格快照状态；动态加载给不出同步函数）。 客户端契约：state 按旧链路大写 OPEN/CLOSED（mapTicket 曾如此）；composer 归一为小写 open/closed， 在此适配层统一升格，避免客户端把全部 closed 误判为 open（#327 面板“0 已关闭/大量错误状态”根因）。
    const upcaseState = function (s) { return String(s || '').toUpperCase() === 'CLOSED' ? 'CLOSED' : 'OPEN' }
    const upcaseSnapStates = function (inner) {
      if (!inner || typeof inner !== 'object') return inner
      ;(inner.maps || []).forEach(function (m) {
        m.state = upcaseState(m.state)
        ;(m.tickets || []).forEach(function (t) {
          t.state = upcaseState(t.state)
          if (Array.isArray(t.blockedBy)) t.blockedBy.forEach(function (b) { if (b && typeof b === 'object' && b.state != null) b.state = upcaseState(b.state) })
          if (Array.isArray(t.blocking)) t.blocking.forEach(function (b) { if (b && typeof b === 'object' && b.state != null) b.state = upcaseState(b.state) })
        })
      })
      ;(inner.issues || []).forEach(function (it) { it.state = upcaseState(it.state) })
      return inner
    }

    // H2 #446 留守：索引小函数留入口（H6 探测同步取值与同刻写表；file2 经显式参数复用同一份）。
    const issueIndexFromSnapshot = function (snap) {
      const index = {}
      const items = snap && Array.isArray(snap.issues) ? snap.issues : []
      items.forEach(function (item) {
        if (item && item.number !== undefined && item.number !== null) index[String(item.number)] = String(item.state || '').toUpperCase() + '|' + String(item.updatedAt || '')
      })
      return index
    }
    const issueIndexChanged = function (before, after) {
      if (!before) return true
      const beforeKeys = Object.keys(before)
      const afterKeys = Object.keys(after)
      if (beforeKeys.length !== afterKeys.length) return true
      for (let i = 0; i < afterKeys.length; i++) if (before[afterKeys[i]] !== after[afterKeys[i]]) return true
      return false
    }
    const rememberIssueIndex = function (repo, index) {
      if (repo && repo.owner && repo.name) lastIssueIndexByRepo[repo.owner + '/' + repo.name] = index
    }

    // H2 #446 留守：isRateLimitError 留入口（H5 三处同步判别；file3 经显式参数复用同一份）。
    function isRateLimitError(r) {
      const t = String((r && r.error) || (r && r.kind) || '').toLowerCase()
      return /rate\s*limit|ratelimit|403/.test(t)
    }

    // v1.3.3 提速：GraphQL aliases 一次查询全部 map 详情（8 次 → 1 次，Windows 下串行 8×2.4s → 单次 ~3.6s） 每个 map 一个 alias（m0/m1/...），响应按 alias 取；网络类失败整批重试 1 次

    // ============ git 远程解析（getRepoKey 与后端谓词复用，#284）============
    // 解析 git 远程 URL → GitHub owner/repo；非 GitHub 返回 null
    function parseGithubRepo(url) {
      const s = String(url || '').trim()
      const m = s.match(/github\.com[\/:]([^\/\s]+)\/([^\/\s]+?)(?:\.git)?\s*$/)
      if (!m) return null
      return { owner: m[1], name: m[2] }
    }
    // H3 #447：远程谓词、技能探测通道、探测编排三组接线都在上面 H3 段（原委见账本 §4）。
    harness.handle('wf.detect', async function (args) { const h = await _detectChain(); return h.handleDetect(args) }); harness.handle('wf.chain', async function (args) { const h = await _detectChain(); return h.handleChain(args) })   // 后两句合一行：本文件已顶 350 行上限，把腾出的一行留给下面 888 的技能原文直读
    harness.handle('skill.readDoc', async function (args) { const m = await import('./skillDoc.js'); return m.createSkillDoc({}).readDoc(args) })
    harness.handle('wf.pluginIdentity', async function () { const m = await import('./pluginIdentity.js'); return m.handlePluginIdentity() })   // 2026-10-12 身份融合：版本号与仓库链接读「装着的这一份」
    // ---- H4 #448 接线：3 新文件动态 import 加载（D7 禁止静态 import），依赖全显式传入；新文件之间不互引用 ---- harness 留守原因：harness.handle 在 apply 同步注册，动态 import 无法同步供给。 这一组的拆分缘由见账本 §5。
    let _sessLifeP = null
    function _sessLife() { if (!_sessLifeP) _sessLifeP = (async function(){ const mod = await import('./sessionLifecycle.js'); return mod.createSessionLifecycle({ ctx: ctx, DEFAULT_CWD: DEFAULT_CWD, errText: errText, canonicalKey: function(){ return canonicalKey.apply(null, arguments) }, getDetectionService: function(){ return getDetectionService.apply(null, arguments) }, getTrackerRegistry: function(){ return getTrackerRegistry.apply(null, arguments) }, getPlatform: function(){ return getPlatform.apply(null, arguments) }, logCtx: logCtx }) })(); return _sessLifeP }
    let _sessSnapP = null
    function _sessSnap() { if (!_sessSnapP) _sessSnapP = (async function(){ const life = await _sessLife(); const mod = await import('./sessionSnapshot.js'); const grp = await _group(); const env = await import('./snapshotEnvelope.js'); let ckr = null; let w0 = null; try { w0 = await _refreshWiringP; ckr = w0 && w0.chainReadout ? w0.chainReadout : null } catch (eW) {} return mod.createSessionSnapshot({ envelope: env.createSnapshotEnvelope({ getGhPath: function(){ return ghPath }, getGhLastError: function(){ return ghLastError }, adoptSnapshot: function(){ return adoptSnapshot.apply(null, arguments) }, logCtx: logCtx }), chainReadout: ckr, chainField: (w0 && w0.chainField) || 'sessionTickets', canonicalKey: function(){ return canonicalKey.apply(null, arguments) }, selectEarly: life.selectEarly, isComposerSelection: life.isComposerSelection, getTrackerRegistry: function(){ return getTrackerRegistry.apply(null, arguments) }, getPlatform: function(){ return getPlatform.apply(null, arguments) }, ctx: ctx, getCache: getCache, setCache: setCache, CACHE_MS: CACHE_MS, cacheSnapshotIsCurrent: function(){ return cacheSnapshotIsCurrent.apply(null, arguments) }, send: function (req, perform) { return _refreshWiringP.then(function (w) { return w.send(req, perform) }) }, upcaseSnapStates: upcaseSnapStates, computeLevels: grp.computeLevels, groupTickets: grp.groupTickets, getRepoRoot: function(){ return getRepoRoot.apply(null, arguments) }, getRepoKey: function(){ return getRepoKey.apply(null, arguments) }, readDiskCache: function(){ return readDiskCache.apply(null, arguments) }, writeDiskCache: function(){ return writeDiskCache.apply(null, arguments) }, adoptSnapshot: function(){ return adoptSnapshot.apply(null, arguments) }, detectionExec: function(){ return detectionExec.apply(null, arguments) }, getGhPath: function(){ return ghPath }, getGhLastError: function(){ return ghLastError }, errText: errText, DEFAULT_CWD: DEFAULT_CWD, logCtx: logCtx, getChoiceStore: function(){ return getChoiceStore.apply(null, arguments) } }) })(); return _sessSnapP }
    let _mapTicketsP = null // #691（阶段 3）：地图子票按需电话 —— 点开一张地图时现去后端把它的子票拉全（已关闭的地图不在快照首屏里）
    function _mapTickets() { if (!_mapTicketsP) _mapTicketsP = (async function(){ const life = await _sessLife(); const mod = await import('./mapTickets.js'); const grp = await _group(); return mod.createMapTickets({ canonicalKey: function(){ return canonicalKey.apply(null, arguments) }, selectEarly: life.selectEarly, isComposerSelection: life.isComposerSelection, getTrackerRegistry: function(){ return getTrackerRegistry.apply(null, arguments) }, getPlatform: function(){ return getPlatform.apply(null, arguments) }, ctx: ctx, DEFAULT_CWD: DEFAULT_CWD, logCtx: logCtx, groupTickets: grp.groupTickets, getMapBody: function(){ return _mapBody() }, detectionExec: function(){ return detectionExec.apply(null, arguments) } }) })(); return _mapTicketsP }
    let _sessRefP = null
    function _sessRef() { if (!_sessRefP) _sessRefP = (async function(){ const life = await _sessLife(); const mod = await import('./sessionRefresh.js'); const env = await import('./snapshotEnvelope.js'); const grp = await _group(); let ckr = null; let w0 = null; try { w0 = await _refreshWiringP; ckr = w0 && w0.chainReadout ? w0.chainReadout : null } catch (eW) {} return mod.createSessionRefresh({ envelope: env.createSnapshotEnvelope({ getGhPath: function(){ return ghPath }, getGhLastError: function(){ return ghLastError }, adoptSnapshot: function(){ return adoptSnapshot.apply(null, arguments) }, logCtx: logCtx, chainReadout: ckr, chainField: (w0 && w0.chainField) || 'sessionTickets' }), chainReadout: ckr, chainField: (w0 && w0.chainField) || 'sessionTickets', canonicalKey: function(){ return canonicalKey.apply(null, arguments) }, selectEarly: life.selectEarly, isComposerSelection: life.isComposerSelection, resetGhCache: function(){ return resetGhCache.apply(null, arguments) }, send: function (req, perform) { return _refreshWiringP.then(function (w) { return w.send(req, perform) }) }, getTrackerRegistry: function(){ return getTrackerRegistry.apply(null, arguments) }, getPlatform: function(){ return getPlatform.apply(null, arguments) }, ctx: ctx, getCache: getCache, setCache: setCache, upcaseSnapStates: upcaseSnapStates, computeLevels: grp.computeLevels, groupTickets: grp.groupTickets, getRepoRoot: function(){ return getRepoRoot.apply(null, arguments) }, getRepoKey: function(){ return getRepoKey.apply(null, arguments) }, readDiskCache: function(){ return readDiskCache.apply(null, arguments) }, writeDiskCache: function(){ return writeDiskCache.apply(null, arguments) }, adoptSnapshot: function(){ return adoptSnapshot.apply(null, arguments) }, detectionExec: function(){ return detectionExec.apply(null, arguments) }, getGhPath: function(){ return ghPath }, getGhLastError: function(){ return ghLastError }, errText: errText, DEFAULT_CWD: DEFAULT_CWD, logCtx: logCtx }) })(); return _sessRefP }
    // #498 退役：wf.ping 删注册（全仓零调用点、零日志行；探活改走 wf.logGetSwitch）。handlePing 实现留守（他处未引用，删注册不断链）。

    // v13：按 sessionId 反查会话工作目录（client 切换对话时用；宿主 sessions.meta 是权威字段， 不再依赖 client 猜测 ConversationSnapshot 字段名）
    // 错误对象 → 可读文本：fetchMaps/buildSnapshot 抛出的是 {kind, error} 对象，String() 会变 [object Object]
    const errText = function (e) {
      if (e === undefined || e === null) return '未知错误'
      if (typeof e === 'string') return e
      if (typeof e.message === 'string') return e.message
      if (typeof e.error === 'string') return e.error
      try { return JSON.stringify(e) } catch (err) { return String(e) }
    }

    harness.handle('wf.cwd', async function (args) { const h = await _sessLife(); return h.handleCwd(args) })

    // #179 回切自愈：空 cwd 仍兜 DEFAULT_CWD 作最后兜底（避免“没有仓库”空白），但客户端已保证同 sid 切工作区亦触发，空窗极短
    harness.handle('wf.snapshot', async function (args) { const h = await _sessSnap(); return h.handleSnapshot(args) })

    // #691：地图子票按需取（in-panel 地图详情页打开时调用；后端没实现这条读路径时界面照旧用快照那份）
    harness.handle('wf.mapTickets', async function (args) { const h = await _mapTickets(); return h.handleMapTickets(args) })

    // #758：这批 deck 工具的宿主代执行（agent 行经它拿真结果；同一份闸与注册表）。 平台区动态引入（D7；平台区被排除在宿主层之外，不新增同层边）。
    let _deckExecP = null
    function _deckExec() { if (!_deckExecP) _deckExecP = (async function(){ const mod = await import('./platform/deckExec.js'); return mod.createDeckExec({ getTable: function(){ return _refreshWiringP.then(function(w){ return (w && typeof w.deckToolsForHost === 'function') ? w.deckToolsForHost() : null }) }, logCtx: logCtx }) })(); return _deckExecP }
    harness.handle('wf.deckExec', async function (args) { const h = await _deckExec(); return h.handleDeckExec(args) })
    let _vcP = null // #817 版本管理页签：三条只读电话，git 命令都在 ./versionControl.js 里起，闸与日志口在这里接上。
    function _vc() { if (!_vcP) _vcP = (async function(){ const w = _refreshWiringP ? await _refreshWiringP.catch(function(){ return null }) : null; const mod = await import('./versionControl.js'); return mod.createVersionControl({ subprocess: subprocess, timer: timer, fs: fs, getPlatform: function(){ return getPlatform.apply(null, arguments) }, DEFAULT_CWD: DEFAULT_CWD, TIMEOUT_MS: TIMEOUT_MS, gate: (w && w.gate) || null, logCtx: logCtx }) })(); return _vcP }
    harness.handle('wf.gitStatus', async function (args) { const h = await _vc(); return h.handleGitStatus(args) })
    harness.handle('wf.gitDiff', async function (args) { const h = await _vc(); return h.handleGitDiff(args) })
    harness.handle('wf.gitLog', async function (args) { const h = await _vc(); return h.handleGitLog(args) })
    // 写电话（1 预检 + 6 执行）：装配在 ./versionControl.js 内部（同一个 runGit 出口、同一个 loggedPhone、同一条 git.exec 日志），这里只做注册。
    harness.handle('wf.gitWriteCheck', async function (args) { const h = await _vc(); return h.handleGitWriteCheck(args) })
    harness.handle('wf.gitStage', async function (args) { const h = await _vc(); return h.handleGitStage(args) })
    harness.handle('wf.gitUnstage', async function (args) { const h = await _vc(); return h.handleGitUnstage(args) })
    harness.handle('wf.gitCommit', async function (args) { const h = await _vc(); return h.handleGitCommit(args) })
    harness.handle('wf.gitPull', async function (args) { const h = await _vc(); return h.handleGitPull(args) })
    harness.handle('wf.gitFetch', async function (args) { const h = await _vc(); return h.handleGitFetch(args) })
    harness.handle('wf.gitPush', async function (args) { const h = await _vc(); return h.handleGitPush(args) })

    harness.handle('wf.refresh', async function (args) { const h = await _sessRef(); return h.handleRefresh(args) })

    // #707（T3）视野模型：判定在 refresh-core/src/attention.ts 的产物里；#723（T19）起用接线那一份同一个实例—— wf.focus 上报的「我在看谁」必须与写事件白名单、闸的活跃集合同源（票面 3c）。
    harness.handle('wf.focus', function (args) { return _refreshWiringP.then(function (w) { return w.focus(args) }) })
    harness.handle('wf.gateStats', function () { const t0 = Date.now(); return _refreshWiringP.then(function (w) { const out = w.stats(); try { if (logCtx) logCtx.fire('info', 'host.call', { method: 'wf.gateStats', latencyMs: Date.now() - t0, ok: true, kind: 'gate-stats' }) } catch (eL) {} return out }) }) // #927：闸的三个累计数（撞限流 / 记账对不上 / 绕闸）的只读出口——观察期就靠它看；成功一行走既有 host.call
    // ---- H5 #449 接线：2 新文件动态 import 加载（D7 禁止静态 import），依赖全显式传入；新文件之间不互引用 ---- 留守：harness.handle 注册留守（apply 同步注册，动态加载无法同步供给）；isRateLimitError 留守（H2 已注：H5 三处同步判别经显式参数复用同一份）。 这一组的拆分缘由见账本 §6。
    let _workspaceP = null
    function _workspace() { if (!_workspaceP) _workspaceP = (async function(){ const mod = await import('./workspaceCwd.js'); return mod.createWorkspaceCwd({ ctx: ctx, DEFAULT_CWD: DEFAULT_CWD, getPlatform: function(){ return getPlatform.apply(null, arguments) }, getTrackerRegistry: function(){ return getTrackerRegistry.apply(null, arguments) }, getWorkspaceStore: function(){ return getWorkspaceStore.apply(null, arguments) }, getChoiceStore: function(){ return getChoiceStore.apply(null, arguments) }, getDecisionFn: function(){ return _plat().then(function(h){ return h.getDecisionFn(); }) }, canonicalKey: function(){ return canonicalKey.apply(null, arguments) }, setCache: setCache, timer: timer, detectionExec: function(){ return detectionExec.apply(null, arguments) }, logCtx: logCtx }) })(); return _workspaceP }
    let _commentsP = null
    function _comments() { if (!_commentsP) _commentsP = (async function(){ const ws = await _workspace(); const life = await _sessLife(); const mod = await import('./commentThreads.js'); return mod.createCommentThreads({ normCwd: ws.normCwd, canonicalKey: function(){ return canonicalKey.apply(null, arguments) }, selectEarly: life.selectEarly, isComposerSelection: life.isComposerSelection, getTrackerRegistry: function(){ return getTrackerRegistry.apply(null, arguments) }, getPlatform: function(){ return getPlatform.apply(null, arguments) }, ctx: ctx, timer: timer, DEFAULT_CWD: DEFAULT_CWD, errText: errText, isRateLimitError: isRateLimitError, getRepoKey: function(){ return getRepoKey.apply(null, arguments) }, runGh: function(){ return runGh.apply(null, arguments) }, execProc: function(){ return execProc.apply(null, arguments) }, fetchIssueDetail: function(){ return fetchIssueDetail.apply(null, arguments) }, fetchIssueIndex: function(){ return fetchIssueIndex.apply(null, arguments) }, fetchIssueIndexWindowed: function(){ return fetchIssueIndexWindowed.apply(null, arguments) }, issueIndexFromSnapshot: issueIndexFromSnapshot, issueIndexChanged: issueIndexChanged, rememberIssueIndex: rememberIssueIndex, commitIssueIndex: function () { return commitIssueIndex.apply(null, arguments) }, getCache: getCache, setCache: setCache, lastIssueIndexByRepo: lastIssueIndexByRepo, lastProbeAtByRepo: lastProbeAtByRepo, deltaRefresh: function (cwd, opts) { return _refreshWiringP.then(function (w) { return w.deltaRefresh(cwd, opts) }) }, logCtx: logCtx }) })(); return _commentsP }
    let _issuePageP = null; function _issuePage() { if (!_issuePageP) _issuePageP = (async function(){ const ws = await _workspace(); const life = await _sessLife(); const mod = await import('./issuePage.js'); return mod.createIssuePage({ normCwd: ws.normCwd, selectEarly: life.selectEarly, getTrackerRegistry: function(){ return getTrackerRegistry.apply(null, arguments) }, getPlatform: function(){ return getPlatform.apply(null, arguments) }, getRepoKey: function(){ return getRepoKey.apply(null, arguments) }, ctx: ctx, DEFAULT_CWD: DEFAULT_CWD, detectionExec: function(){ return detectionExec.apply(null, arguments) }, logCtx: logCtx }) })(); return _issuePageP }
    harness.handle('wf.issuesPage', async function (args) { const h = await _issuePage(); return h.handleIssuesPage(args) }) // #690 历史票按页取（已关闭票按需翻页那三个触发点的唯一出口）
    async function normCwd() { const h = await _workspace(); return h.normCwd.apply(h, arguments) }
    harness.handle('wf.bind', async function () { const h = await _workspace(); return h.handleBind.apply(h, arguments) })
    harness.handle('wf.bindings', async function () { const h = await _workspace(); return h.handleBindings.apply(h, arguments) })
    harness.handle('wf.registry', async function () { const h = await _workspace(); return h.handleRegistry.apply(h, arguments) })
    harness.handle('wf.selection', async function () { const h = await _workspace(); return h.handleSelection.apply(h, arguments) })
    harness.handle('wf.setupLayout', async function (args) { const h = await _workspace(); return h.handleSetupLayout(args) }) // #683（F1 · ADR 的 R6）：布局答案按工作区记（H 与 C 各一份），卡片确认同时写两处。
    // #627 标签配色两条电话：端点名与契约操作名一致（listLabels / setLabelColors）， 界面经客户端到宿主那条既有接口（/api/dsws 通道按端点名分发）就能调到它们。
    harness.handle('wf.listLabels', async function (args) { const h = await _workspace(); return h.handleListLabels(args) })
    harness.handle('wf.setLabelColors', async function (args) { const h = await _workspace(); return h.handleSetLabelColors(args) })
    harness.handle('wf.issueDetail', async function () { const h = await _comments(); return h.handleIssueDetail.apply(h, arguments) })
    harness.handle('wf.issueComments', async function () { const h = await _comments(); return h.handleIssueComments.apply(h, arguments) })
    harness.handle('wf.commentIssue', async function () { const h = await _comments(); return h.handleCommentIssue.apply(h, arguments) })
    harness.handle('wf.probe', async function () { const h = await _comments(); return h.handleProbe.apply(h, arguments) })

    // ---- H6 #450 接线：5 新文件动态 import 加载（D7 禁止静态 import），依赖全显式传入；新文件之间不互引用 ---- 第 5 件 ticketGrouping 为压线追加（用户定夺）：computeLevels/groupTickets 纯函数搬出，H2/H4 loader 取值后转供给。 这一组的拆分缘由见账本 §7。
    let _handoffP = null
    function _handoff() { if (!_handoffP) _handoffP = (async function(){ const mod = await import('./handoffClaim.js'); return mod.createHandoffClaim({ fs: fs, DEFAULT_CWD: DEFAULT_CWD, normCwd: function(){ return normCwd.apply(null, arguments) }, getDetectionService: function(){ return getDetectionService.apply(null, arguments) }, getTrackerRegistry: function(){ return getTrackerRegistry.apply(null, arguments) }, getPlatform: function(){ return getPlatform.apply(null, arguments) }, ctx: ctx, getRepoKey: function(){ return getRepoKey.apply(null, arguments) }, runGh: function(){ return runGh.apply(null, arguments) }, setCache: setCache, logCtx: logCtx }) })(); return _handoffP }
    let _namingP = null
    function _naming() { if (!_namingP) _namingP = (async function(){ const mod = await import('./namingGuardian.js'); return mod.createNamingGuardian({ fs: fs, timer: timer, DEFAULT_CWD: DEFAULT_CWD, getCacheDir: function(){ return getCacheDir.apply(null, arguments) }, getPlatform: function(){ return getPlatform.apply(null, arguments) }, getRepoKey: function(){ return getRepoKey.apply(null, arguments) }, runGh: function(){ return runGh.apply(null, arguments) }, logCtx: logCtx, getFirstText: function (sid) { try { return _refreshWiringP.then(function (w) { try { return w.firstTextOf(sid) } catch (eW) { return null } }).catch(function () { return null }) } catch (eG) { return Promise.resolve(null) } }, getTitleFact: function (sid) { try { return _refreshWiringP.then(function (w) { try { return w.titleFactOf(sid) } catch (eW) { return null } }).catch(function () { return null }) } catch (eG) { return Promise.resolve(null) } } }) })(); return _namingP }
    let _publishP = null
    function _publish() { if (!_publishP) _publishP = (async function(){ const mod = await import('./publishFlow.js'); return mod.createPublishFlow({ DEFAULT_CWD: DEFAULT_CWD, resolveGit: function(){ return resolveGit.apply(null, arguments) }, resolveGh: function(){ return resolveGh.apply(null, arguments) }, getGhLastError: function(){ return ghLastError }, runGh: function(){ return runGh.apply(null, arguments) }, execProc: function(){ return execProc.apply(null, arguments) }, canonicalKey: function(){ return canonicalKey.apply(null, arguments) }, getRepoKey: function(){ return getRepoKey.apply(null, arguments) }, repoKeys: repoKeys, repoRoots: repoRoots, setCache: setCache, logCtx: logCtx }) })(); return _publishP }
    let _pickerP = null
    function _picker() { if (!_pickerP) _pickerP = (async function(){ const mod = await import('./pickerShell.js'); return mod.createPickerShell({ DEFAULT_CWD: DEFAULT_CWD, getPlatform: function(){ return getPlatform.apply(null, arguments) }, subprocess: subprocess, timer: timer, logCtx: logCtx }) })(); return _pickerP }
    let _groupP = null
    function _group() { if (!_groupP) _groupP = import('./ticketGrouping.js').then(function(m){ return m.createTicketGrouping() }); return _groupP }
    // H6 同步外形保持：_repo 接线经此同步函数取即时推进（原命名块内同步定义；现为加载后防火即发，无返回值、永不抛，调用方 try 包裹语义不变）。
    function namingSweepSoon(delayMs) { _naming().then(function(h){ try { h.namingSweepSoon(delayMs) } catch (eSw) {} }).catch(function(){}) }
    harness.handle('wf.handoffLatest', async function () { const h = await _handoff(); return h.handleHandoffLatest.apply(h, arguments) })
    harness.handle('wf.handoffResolve', async function () { const h = await _handoff(); return h.handleHandoffResolve.apply(h, arguments) })
    // #498 退役：wf.claim 删注册（全仓零调用点、零日志行；认领取走 wf.handoffResolve）。handleClaim 实现留守（删注册不断链）。
    harness.handle('wf.namingRegister', async function () { const h = await _naming(); return h.namingRegisterHandler.apply(h, arguments) })
    harness.handle('wf.registerNewSessionWatcher', async function () { const h = await _naming(); return h.namingRegisterHandler.apply(h, arguments) })
    harness.handle('wf.namingSignal', async function () { const h = await _naming(); return h.handleNamingSignal.apply(h, arguments) })
    harness.handle('wf.namingPlan', async function () { const h = await _naming(); return h.handleNamingPlan.apply(h, arguments) })
    harness.handle('wf.namingResult', async function () { const h = await _naming(); return h.handleNamingResult.apply(h, arguments) })
    harness.handle('wf.cancelNewSessionWatcher', async function () { const h = await _naming(); return h.handleCancelNewSessionWatcher.apply(h, arguments) })
    harness.handle('wf.awaitCreatedIssue', async function () { const h = await _naming(); return h.handleAwaitCreatedIssue.apply(h, arguments) })
    harness.handle('wf.openFolder', async function () { const h = await _picker(); return h.handleOpenFolder.apply(h, arguments) })
    harness.handle('wf.initPublish', async function () { const h = await _publish(); return h.handleInitPublish.apply(h, arguments) })
    harness.handle('wf.retryPush', async function () { const h = await _publish(); return h.handleRetryPush.apply(h, arguments) })
    harness.handle('wf.pickDirectory', async function () { const h = await _picker(); return h.handlePickDirectory.apply(h, arguments) })
    harness.handle('wf.pickFile', async function () { const h = await _picker(); return h.handlePickFile.apply(h, arguments) })
    harness.handle('wf.openPath', async function () { const h = await _picker(); return h.handleOpenPath.apply(h, arguments) })

    // ---- #490 host 日志底座 + #564 切日志包：优先走包派生（./logFromPackage.js），失败回退旧实现（旧文件留而不搬） ----
    let _logP = null
    function _log() { if (!_logP) _logP = (async function(){ try { const adapter = await import('./logFromPackage.js'); return await adapter.createLogFromPackage({ fs: fs, timer: timer, getCacheDir: function(){ return getCacheDir.apply(null, arguments) }, getPlatform: function(){ return getPlatform.apply(null, arguments) }, DEFAULT_CWD: DEFAULT_CWD }) } catch (ePkg) { const mod = await import('./logStore.js'); return mod.createLogStore({ fs: fs, timer: timer, getCacheDir: function(){ return getCacheDir.apply(null, arguments) }, getPlatform: function(){ return getPlatform.apply(null, arguments) }, DEFAULT_CWD: DEFAULT_CWD }) } })(); return _logP }
    harness.handle('wf.logBatch', async function (args) { const h = await _log(); return h.handleLogBatch(args) })
    harness.handle('wf.logExport', async function (args) { const h = await _log(); return h.handleLogExport(args) })
    harness.handle('wf.logClear', async function (args) { const h = await _log(); return h.handleLogClear(args) })
    harness.handle('wf.logGetSwitch', async function (args) { const h = await _log(); return h.handleLogGetSwitch(args) })
    harness.handle('wf.logSetSwitch', async function (args) { const h = await _log(); return h.handleLogSetSwitch(args) })
    // 启动链 import 失败静默（#499 红队 C2）：日志库没加载出来时管道尚未就绪、无处可记；首次命中由分发异常行 #46 在调用方记。
    _log().then(function(h){ try { h.loadSwitch().catch(function(){}) } catch (eSw) {} try { h.writeStartupHeader().catch(function(){}) } catch (eHd) {} }).catch(function(){})
    // ---- #873 薄接线：更新能力只走已安装的更新包（updateFromPackage.js），旧实现与回退分支已删；包缺失直接抛错，不静默降级。
    let _updateP = null
    function _update() { if (!_updateP) _updateP = (async function(){ const args = { logCtx: logCtx, ctx: ctx }; const migrated = await import('./updateFromPackage.js'); return migrated.createUpdatePhoneHandlers(args) })(); return _updateP }
    harness.handle('wf.updateStatus', async function (args) { const h = await _update(); return h.handleUpdateStatus(args) })
    harness.handle('wf.updateCheck', async function (args) { const h = await _update(); return h.handleUpdateCheck(args) })
    harness.handle('wf.updateInstall', async function (args) { const h = await _update(); return h.handleUpdateInstall(args) })
    harness.handle('wf.updateChangelog', async function (args) { const h = await _update(); return h.handleUpdateChangelog(args) })
    // 轮询已按 #348 Q3 关闭（60s 全量贴配额上限）：纯手动刷新 + 打开面板即刷，自动待 P1 再议。命名守护按 #709（T5）改事件驱动，
    // 下面这一次只做一次性铺垫（预热跟踪态、把攒下的脏账落盘），此后每一跳都由事件带起来，宿主侧没有自续定时器（由门禁守着）。缘由见账本 §8。
    _naming().then(function(h){ try { h.startNamingGuardianEvents() } catch (eEvents) {} }).catch(function(){})
    // ---- RPC 通道注册（#596 换到 /api 载体，细节见 ./rpcChannel.js，这里只递端点表与日志函数）---- 这里那个 catch 只兜「本文件加载 rpcChannel.js 失败」；通道注册失败由 rpcChannel.js 自己记账。
    let _rpcChannelP = null
    function _rpcChannel() { if (!_rpcChannelP) _rpcChannelP = import('./rpcChannel.js'); return _rpcChannelP }
    _rpcChannel().then(function (ch) {
      ch.createRpcChannel({ ctx: ctx, handlers: __DSW_HANDLERS__, fireLog: fireLog, dispatchMeta: function () { return _dispatchMeta() } })
    }).catch(function (eLoad) {
      try { fireLog('error', 'host.dispatch.error', { method: '/api/dsws 通道注册', argsHash: '', errorKind: 'internal' }) } catch (eR2) {}
    })
    return true
    }
    if (bootBody()) return
    let booted = false
    const bootOnce = () => { if (booted) return; booted = true; try { bootBody() } catch (eBoot) {} }
    try { ctx.inject(['subprocess', 'timer'], bootOnce) } catch (eInj) { bootOnce() }
    setTimeout(() => {
      if (booted) return
      try { console.warn('[GitHub 常驻] host boot deferred: subprocess/timer not ready after 30s, deck tools not registered') } catch (eW) {}
    }, 30000)
  },
}