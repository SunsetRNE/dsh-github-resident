/**
 * GitHub 常驻（GitHub Resident）· Deck 半（UX v25 · 2026-08-14 T2a 配置页骨架；2026-10-12 身份融合）
 *
 * v27 变更（#95 · 阶段 2 步骤 1 Ctx 接线）：src/client/kernel/ctx.js（createCx + DswsCtx，
 *   G3 冻结 8 字段 #91）经构建注入 apply 闭包顶部；插槽组件注册处包 DswsCtx.Provider（withCx）。
 *   不搬任何组件，行为零变化。
 *
 * v26 变更（#373 用户拍板 2026-08-14）：
 *   打开形式收敛为「仅右侧 details 列」——移除 Document PiP 独立小窗（Electron 不可用、
 *   曾致桌面卡死）、停靠/悬浮双模式记忆（PANEL_MODE_KEY）、状态栏「停靠」seg、右栏「悬浮」按钮；
 *   状态栏胶囊允许换行（窄栏不再截断）。
 *
 * v25 变更（map #364）：
 *   T2a：配置页骨架（settings.plugins.tab「GitHub 常驻」+ 持久化 + 广播）；
 *   T2b：动作模板编辑器 + 占位符保护；
 *   T3（#366）：dsws locale 命名空间 zh/en 字典，全控件文字双语跟随 harness 语言（GitHub 数据不翻译）。
 *
 * v25 变更（map #364 · T2a）：
 *   50. 配置页骨架：settings.plugins.tab「GitHub 常驻」注册（设置 → 插件可见）；
 *       三组既有配置迁入（面板默认高度三档 / 开始模板 / 外观）；
 *       配置持久化 dsws.cfg + dsws.templates（旧 dsws.startCfg 自动迁移）；
 *       保存后广播同步所有会话 store（修复外观/尺寸不持久化隐性 bug）；
 *       面板内 StartCfgModal 移除，Run 卡保留「打开配置」引导按钮。
 *
 * v24 变更（用户反馈）：
 *   48. 交接第二击文件名修复：记忆第一击模板的时间戳，第二击读同一个文件
 *       （模板写什么名就读什么名；不再因目录无文档而兜底旧 latest.md；未点第一击才回退查最新）
 *   49. 面板默认高度 1/4 → 1/2（用户反馈 1/4 太小）
 *
 * v23：面板默认高度 = 屏幕约 1/4。
 * v22：引导句「从第一性原理出发完成任务，并对抗式审查。」；交接第一击恢复注入时间戳模板；
 * 第二击预填优化+复制。
 * v21：动作按钮 prompt 精简 + 统一引导句。
 * v20：标签「+N」点击展开全部标签/收起。
 * v19：grilling→讨论 / 头部 repo 名 / 环境段末尾 / map 详情执行+任务动作 / map 行进度 /
 * 交接时间戳+查最新+复制。
 * v18：可接/占用列表口径 / 按钮去开始（诊断/执行/修复）/ 点击预填输入框。
 * v17：isLight 改 YIQ 感知亮度。v16：按钮色 = label 配置色。
 * v15：状态栏防换行自适应 / map 置顶 / 被阻塞标签 / 会话 cwd 改 SessionSummary.cwd。
 * v14：全部执行批次（三选一动作 / map 行突出 / 已关闭折叠 / chips 深边框 / 窄屏折叠 /
 * 刷新遮罩 / 主题安全色 / 交接按钮 / 状态栏等宽 / 按会话 store）。
 * v13：cwd 权威反查（wf.cwd）+ sessionId 变化重探测。v12：repoKey 按 cwd 缓存 /
 * 失败不兜假数据 / 三视图收敛 / 沉淀=注入快照模板。
 * v11：label 颜色 = GitHub 配置色。v10：cwd 关联 / 标签视图 / 圆形技能环。
 * v9：DESIGN.md §12.2 Round 3 定稿 1A-7A 落实。
 *
 * 本文件内容 = cordis_define 的 code.client（纯 JS 函数体，返回 Cordis Plugin）。
 */

// ===== 规范方言（dynamic dialect）：host/styles/React/timer 为自由变量；pkg entry 提供 shim =====
export default {
  apply(ctx) {
    const slots = ctx.get('slots')
    if (slots === undefined) return
    // ==== leaf:hostShim (spliced by build) ====
    // ==== kernel:portal (spliced by build) ====
    // 身份融合（2026-10-12）：下面三个都由 scripts/build.mjs 按主包 package.json 注入（独立构建时回落
    // deck 自己的 package.json）。DSW_IDENTITY = 界面与状态里的身份串（dock 槽位 / 右栏 tab / 设置页 slug）；
    // DSW_VERSION 与 DSW_REPO_URL 是**构建期兜底值**，真实值由 panelAssembly 的 probePluginIdentity()
    // 启动时向宿主取（已装目录 package.json）——所以它们是 let。（#repo-link：版本号可点开主包仓库主页。）
    const DSW_IDENTITY = '__DSW_IDENTITY__'
    let DSW_VERSION = __DSW_VERSION__
    let DSW_REPO_URL = __DSW_REPO_URL__

    // ============================== 0. 样式 ==============================
    // ==== kernel:backendList (spliced by build) ====
    // ==== kernel:link (spliced by build) ====
    // ==== kernel:identityMigration (spliced by build) ====
    // 身份迁移（2026-10-12）：必须抢在任何注册之前——槽位与右栏 tab 按身份串认领，注册先发生的话
    //   老会话会先按旧串找不到自己的位置，再迁移也补不回那一帧（详见该模块文件头）。
    try { runIdentityMigration((typeof localStorage !== 'undefined') ? localStorage : null) } catch (eIdMig) {}

    // ==== kernel:styles (spliced by build) ====
    styles.insert(STYLE_TEXT)
    // #851：版本管理页签的视觉语言另起一个样式叶子（styles.js 已 350/350 冻结）；仍走同一个 insert 接缝。
    // ==== leaf:vcStyles (spliced by build) ====
    styles.insert(VC_STYLE_TEXT)
    // ==== leaf:pixelStyles (spliced by build) ====  // 887：技能详情像素风皮肤（做法同 vcStyles）
    styles.insert(PIXEL_STYLE_TEXT)
    // ==== leaf:feedbackStyles (spliced by build) ====
    styles.insert(FEEDBACK_STYLE_TEXT) // 948 反馈样式叶子（同像素皮肤做法）

    // ============================================================
    // 0.5 locale（T3 #366 · dsws 命名空间 zh/en；跟随 harness 语言；GitHub 数据不翻译）
    // 契约：ctx.locale（dsh-client-locale）：register(ns, {zh, en}) + bind(ns) 稳定引用，调用时读当前语言；
    // 所有 outlet 在 locale 切换时自动重渲染（useLocaleRevision），模块级 t 即可生效。
    // v1.5：全部 prompt（GUIDE_LINE/MAP_EXECUTE/COMPLETE/FIXATE/TPL_DEFAULT/setup/newWayfinder/mapHead）
    //   集中为 L 字典 prompt.*（zh/en 双语跟随 DSH 语言），审阅与优化见 docs/prompts-review.md。
    // ============================================================
    // ==== kernel:localePanel (spliced by build) ====
    // ==== kernel:localeFlow (spliced by build) ====
    // ==== kernel:localeWord (spliced by build) ====
    // #621：标签配色弹窗的中英词条单独一份片段（老的三份片段都在 350 行上限附近，塞不下）
    // ==== kernel:localeLabels (spliced by build) ====
    // #690 历史票按需翻页的五条文案：locale-flow.js 已贴 350 行上限，照 #621 的做法自成一个片段。
    // ==== kernel:localePages (spliced by build) ====
    // #842 写操作那一族的词条：locale-panel 与 locale-flow 都在上限上，照 #621/#690 的做法自成一个片段。
    // ==== kernel:localeVcWrite (spliced by build) ====
    // #879 技能描述 27 条中英词条：locale-word.js 已贴 350 行上限，照 #621/#690/#842 的做法自成一个片段。
    // ==== kernel:localeSkilldesc (spliced by build) ====
    // 887：技能详情像素风的中英词条单独一份片段（sd.*）。
    // ==== kernel:localeSkilldetail (spliced by build) ==== // ==== kernel:localeCards (spliced by build) ====
    // ==== kernel:locale (spliced by build) ====
    const localeSvc = ctx.get('locale')
    if (localeSvc && typeof localeSvc.register === 'function') {
      ctx.effect(function () {
        return localeSvc.register('dsws', L)
      }, 'dsws: locale')
    }
    // tr：locale 绑定（稳定引用，调用时读当前语言；命名 tr 避免与票务参数 t 冲突）；服务缺失时退化 zh 字典（与 locale 同语义：{name} 参数替换）
    const tr = (localeSvc && typeof localeSvc.bind === 'function')
      ? localeSvc.bind('dsws')
      : function (key, params) {
          let s = (L.zh[key] !== undefined) ? L.zh[key] : key
          if (params) s = s.replace(/\{(\w+)\}/g, function (m, name) { return name in params ? String(params[name]) : m })
          return s
        }

    // ============================================================
    // 1. 技能目录 + 场景推荐映射
    // ============================================================
    // T3：描述在渲染时 tr('skilldesc.<name>')（此处 use 字段为中文静态参考）
    // ==== shared:mattSkills (spliced by build) ====
    // #fix-banner：动态占位供 installSkills prompt 使用；probeList/probeCount 由 SKILLS 派生（与 host MATT_SKILL_PROBE_NAMES 同源）
    const installSkillsParams = function () {
      const names = (Array.isArray(SKILLS) ? SKILLS : []).map(function (s) { return s && s.name }).filter(Boolean)
      return { probeList: names.join(' / '), probeCount: String(names.length) }
    }
    const TYPE_SKILLS = {
      research: ['research'],
      prototype: ['prototype'],
      grilling: ['grilling', 'domain-modeling'],
      task: ['implement'],
    }
    const TYPE_LABEL = {
      research: ['research', 'r', '研究'],
      prototype: ['prototype', 'p', '原型'],
      grilling: ['grilling', 'g', '对齐'],
      task: ['task', 't', '任务'],
      map: ['map', 'm', '地图'],
    }
    // 图标按类型分发。issue（普通票：没有 wayfinder 类型标签的票）故意没有图标 —— 徽章只出文字、灰底，
    // 前面挂一个圆点像多出来的项目符号，去掉后文字才左右对称；齿轮必须留给任务票，不让普通票兜底落进去（#626）
    const TYPE_ICON = { research: 'search', prototype: 'hammer', grilling: 'chat', task: 'gear', map: 'map' }

    // ============================================================
    // 2. 外观方案（图标 + 动作词，可切换）
    // ============================================================
    // ==== shared:trackerConstants (spliced by build) ====
    // #668 首开引导链的步骤清单（顺序唯一真源）：宿主管排序，界面（#663 横幅 / #664 注入决策）也要读它。
    // ==== shared:guideSteps (spliced by build) ====
    // ==== shared:namingTitles (spliced by build) ==== // ==== shared:namingTracking (spliced by build) ==== // ==== shared:namingAttribution (spliced by build) ====
    // ==== shared:trackerSync (spliced by build) ====
    // ==== shared:slots (spliced by build) ====
    // ==== kernel:icons (spliced by build) ====
    // ==== kernel:healthCheck (spliced by build) ====

    // ============================================================
    // 2.5 配置模型（v25 · T2a：dsws.cfg + dsws.templates；旧 dsws.startCfg 自动迁移）
    // 必须位于 §3 store 之前（DEFAULT_PANEL_H 固定 1/2）
    // ============================================================
    // ============================================================
    // §prompts：prompt 注册表（内容层 · 独立于 UI 文案 i18n）—— 方案 A
    //   每条：{ version, placeholders, use, zh, en }；运行时按当前语言经 promptText(id, params) 取用
    //   占位符契约：文本内 {x} 必须声明在 placeholders；promptText 只替换已声明参数（未知保留）
    //   原则：所有 prompt 相对所引用技能（wayfinder/grilling/triage 等）只做「追加扩展要求」，绝不覆盖技能自身规则。
    //   审阅：docs/reviews/prompts-review-v1.5.html / .md · 契约校验：tests/verify-prompts.js
    // ============================================================
    // ==== kernel:prompts (spliced by build) ====
    // ==== kernel:promptsSetup (spliced by build) ====
    // ==== kernel:modalFields (spliced by build) ====
    // ==== kernel:config (spliced by build) ====
    // ==== kernel:log (spliced by build) ====

    // ============================================================
    // 3. store（v14：按会话隔离；无 sid 时用 shared）
    // ============================================================
    // v24-48：面板默认高度 = 屏幕约 1/2
    // v1.5 T3：面板默认高度固定 1/2（用户拍板彻底移除 panelHeight 配置 —— details 列高度与它无关，配置不生效）
    // ==== shared:workspaceKey (spliced by build) ====
    // #629 配色核心：色值归一、合法性判断、比较颜色有没有变，以及调色盘表格与提示词的拼装。
    // 这两份是内置 TypeScript 核（label-color-core/）的产物，界面只当普通函数调用；
    // 界面文案一律从词条传进去，核心不含任何用户能看到的字（详见 label-color-core/README.md）。
    // ==== shared:labelColors (spliced by build) ====
    // ==== shared:labelColorPrompt (spliced by build) ====
    // #715 诚实显示：新鲜度阈值（5 分钟黄 / 30 分钟红）、写入合并窗口、降档的延迟承诺，
    // 只有一份真源（refresh-core/src/budget.ts → src/shared/refresh/budget.js），拼进来给界面读；
    // 判据与渲染见 views/shared/truthLines.js 与 views/ListTab.js。
    // ==== shared:refreshBudget (spliced by build) ====
    // #842 写操作：能不能暂存/提交/拉取/推送的判定只有一份真源（version-control-core/src/rules.ts →
    // src/shared/version-control/rules.js）。界面按同一份判定画按钮状态，不自己算 —— 自己算就会与
    // 宿主执行前那次判定各说各话。
    // ==== shared:vcRules (spliced by build) ====
    // ==== kernel:storePrefs (spliced by build) ====
    // ==== kernel:storeSwitch (spliced by build) ====
    // ==== kernel:storeSnapshot (spliced by build) ====
    // ==== kernel:storeDerived (spliced by build) ====

    // ---- 环境检查链（#228/#284 · host.call('wf.chain')；通用链 + 后端链全链快照）----
    // #284：九格目录视图（wf.status/checks）退役，读数点位全部改从链快照派生
    // ==== kernel:probeStale (spliced by build) ====
    // ==== kernel:probeChain (spliced by build) ====
    // ==== kernel:probeSnapshot (spliced by build) ====
    // #727：probe-select.js —— 「这个工作区用哪个后端」这条事实的两条专用轨迹（补问一次 wf.selection、
    //   迟到快照回包的落地判据）。单独一片的原因与 #707 那次一样：probe-snapshot.js 贴着 350 行上限。
    // ==== kernel:probeSelect (spliced by build) ====
    // ==== kernel:probeSnapshotHelpers (spliced by build) ====
    // ==== kernel:probeAuto (spliced by build) ====
    // ==== kernel:attentionHeartbeat (spliced by build) ====
    // 打开形式（#373 用户拍板 2026-08-14；#646 改版；2026-09-21 收敛为唯一一条路）：
    //   面板只落在 DSH 原生右侧边栏里 —— 本插件自己在原生登记表注册一个类型，右栏里那一格由我们渲染，
    //   不依赖任何第三方插件，也没有第二个落点、没有可选的入口。
    //   已移除：① Document PiP 独立小窗（Electron 无法创建 PiP 窗口、曾致桌面卡死 —— 代码不再含 pip 形态）；
    //   ② 停靠/悬浮双模式记忆（PANEL_MODE_KEY）；③ 状态栏「停靠」seg 与右栏「悬浮」按钮；
    //   ④ #646：页内浮窗形态整体退役（打开面板那两个老函数与 details 列那条路，在维护者拍板后删除）；
    //   ⑤ 2026-09-21：把面板交给 dsh-better-sidebar 打开的那条路整段删除，设置页的「打开位置」一栏随之去掉
    //      （两条路并存时，那个插件把面板画进同一列，原生右栏引导页里会出现两枚同名入口）。
    // ==== kernel:router (spliced by build) ====

    // v10：沉淀 = 会话级动作 —— 注入「零丢失快照」prompt（默认文本见 §2.5 FIXATE_PROMPT，T2b 可编辑）
    // ==== kernel:apiNaming (spliced by build) ====
    // ==== kernel:apiPresetGuard (spliced by build) ====
    // ==== kernel:apiWorkspace (spliced by build) ====
    // ==== kernel:apiNewSession (spliced by build) ====
    // ==== kernel:apiIo (spliced by build) ====
    // #690：历史票的页数据（已关闭票按需翻页）。排在 apiIo 之后 —— 它调的 fetchIssuesPage 住在 apiIo 里。
    // ==== kernel:issuePages (spliced by build) ====

    // ==== kernel:actions (spliced by build) ====
    // ==== kernel:slots (spliced by build) ====
    // ==== kernel:slotRendererQueue (spliced by build) ====
    // ==== kernel:slotRendererRepoSync (spliced by build) ====
    // ==== kernel:slotRendererModalView (spliced by build) ====

    // ==== leaf:chips (spliced by build) ====
    // ==== leaf:hoverTip (spliced by build) ====
    // ==== leaf:tip (spliced by build) ====
    // 887：八个像素风最小组件。
    // ==== leaf:pixelBtn (spliced by build) ====
    // ==== leaf:pixelDot (spliced by build) ====
    // ==== leaf:pixelNum (spliced by build) ====
    // ==== leaf:pixelStateIcon (spliced by build) ====
    // ==== leaf:pixelSeal (spliced by build) ====
    // ==== leaf:pixelSkeleton (spliced by build) ====
    // ==== leaf:pixelBanner (spliced by build) ====
    // ==== leaf:pixelStatusLine (spliced by build) ==== // ==== leaf:cardsTheme (spliced by build) ==== // ==== leaf:cardsStyles (spliced by build) ==== // ==== leaf:cardPin (spliced by build) ==== // ==== leaf:cardTitle (spliced by build) ==== // ==== leaf:cardNo (spliced by build) ==== // ==== leaf:cardTags (spliced by build) ==== // ==== leaf:cardNote (spliced by build) ==== // ==== leaf:cardFoot (spliced by build) ==== // ==== leaf:cardStamp (spliced by build) ==== // ==== leaf:blockedChrome (spliced by build) ==== // ==== leaf:cardBtns (spliced by build) ==== // ==== leaf:mapDots (spliced by build) ==== // ==== leaf:cardHead (spliced by build) ==== // ==== leaf:issueCard (spliced by build) ==== // ==== leaf:issueMapCard (spliced by build) ==== // ==== leaf:mapCard (spliced by build) ==== // S1/S6/S7 三张卡：先主题与皮肤，再共享小件，最后大卡，次序即依赖次序。
    styles.insert(PIXEL_CARDS_STYLE_TEXT)
    // ==== leaf:backendSelector (spliced by build) ====
    // ==== leaf:switchConfirmModal (spliced by build) ====

    // #621 标签配色：面板头部小图标打开一个弹窗改标签颜色。
    // 七份按依赖次序拼：先纯函数（错误档位到人话、电话回包取形状、显示与契约的色值换算、保存成功后
    // 把确认过的颜色写进面板快照、入口图标的颜色），再状态机钩子，最后三份界面（一行取色控件、弹窗本体、头部入口按钮）。
    // ==== leaf:labelColorErrors (spliced by build) ==== // ==== leaf:labelColorPatch (spliced by build) ==== // ==== leaf:labelColorPalette (spliced by build) ==== // ==== leaf:useLabelColors (spliced by build) ====
    // ==== leaf:labelColorRow (spliced by build) ==== // ==== leaf:labelColorDialog (spliced by build) ==== // ==== leaf:labelColorEntry (spliced by build) ====
    // ==== leaf:subworkspaceMark (spliced by build) ====
    // #653：面板头部那一枚归属标志（排在 Tip 之后，它用 Tip 渲染浮层）

    // ==== leaf:seg (spliced by build) ====
    // ==== leaf:checksums (spliced by build) ====
    // ==== leaf:chainRenderer (spliced by build) ====
    // ==== leaf:skillFloatList (spliced by build) ====
    // ==== leaf:vcText (spliced by build) ==== // ==== leaf:vcFold (spliced by build) ==== // ==== leaf:vcDiff (spliced by build) ==== // ==== leaf:vcCommit (spliced by build) ==== // ==== leaf:vcRows (spliced by build) ==== // ==== leaf:vcWrite (spliced by build) ==== // ==== leaf:vcWriteRun (spliced by build) ==== // ==== leaf:vcWriteUi (spliced by build) ==== // ==== leaf:vcWriteOps (spliced by build) ==== // ==== leaf:vcWriteView (spliced by build) ==== // ==== leaf:vcDiffOps (spliced by build) ==== // ==== leaf:vcBlocks (spliced by build) ==== // ==== leaf:vcViews (spliced by build) ==== // ==== leaf:vcAiHandoff (spliced by build) ====
    // ==== leaf:vcTabVisible (spliced by build) ==== // ==== leaf:vcData (spliced by build) ==== // ==== leaf:vcCache (spliced by build) ==== // ==== leaf:vcInView (spliced by build) ==== // ==== leaf:versionControlTab (spliced by build) ====
    // ==== leaf:tabs (spliced by build) ====
    // ==== leaf:truthLines (spliced by build) ====
    // 2026-09-24：降级横幅的「画」那一段从 ListTab.js 搬来这里（判据仍是上面 truthLines 里的 restFallbackView）。
    // ==== leaf:restFallbackBanner (spliced by build) ====
    // ==== leaf:sessionChainView (spliced by build) ====

    // #725：状态栏胶囊那条横条的逐字折叠阶梯（纯函数）与它的阶梯机（读写 DOM），都排在 statusBar 之前
    //   —— 状态栏那边只留接线：把胶囊元素与两张跨调用带着走的表交给机器。
    //   #74 起这一族按「让位次序 / 形态档 / 尺子 / 机器」四件排（capFold · barForm · capFoldRuler · capFoldMachine）。
    // ==== leaf:capFold (spliced by build) ==== // ==== leaf:barForm (spliced by build) ==== // ==== leaf:capFoldRuler (spliced by build) ==== // ==== leaf:barScroll (spliced by build) ==== // ==== leaf:capFoldMachine (spliced by build) ====
    // ==== leaf:StatusMenus (spliced by build) ==== // ==== leaf:StatusBackend (spliced by build) ==== // ==== leaf:bannerChain (spliced by build) ==== // ==== leaf:logDangerConfirm (spliced by build) ==== // ==== leaf:StatusLogMenu (spliced by build) ==== // ==== leaf:statusBar (spliced by build) ====
    // ==== leaf:sessionChainCapsule (spliced by build) ====

    // ==== leaf:md (spliced by build) ====
    // ==== leaf:ticket (spliced by build) ====
    // ==== leaf:stateKind (spliced by build) ====

    // ==== leaf:ticketRow (spliced by build) ====

    // ==== leaf:mapDetailHead (spliced by build) ====
    // ==== leaf:mapDetailTop (spliced by build) ====
    // ==== leaf:mapDetail (spliced by build) ====

    // ==== leaf:IssueDetailComments (spliced by build) ==== // ==== leaf:issueDetailFold (spliced by build) ==== // ==== leaf:useIssueDetailFold (spliced by build) ==== // ==== leaf:IssueDetail (spliced by build) ====

    // ==== leaf:tagsFit (spliced by build) ====
    // ==== leaf:pop (spliced by build) ====
    // ==== leaf:noRepoCard (spliced by build) ====
    // ==== leaf:setupCard (spliced by build) ====
    // ==== leaf:ListTabClosed (spliced by build) ==== // ==== leaf:ListTabRow (spliced by build) ==== // ==== leaf:listTab (spliced by build) ====

    // ==== leaf:prTab (spliced by build) ====


    // ==== leaf:skillsTab (spliced by build) ====
    // 887：技能详情像素风中组件与整页（皮肤拼在上面样式区）。
    // ==== leaf:pixelContents (spliced by build) ====
    // ==== leaf:pixelMarkdown (spliced by build) ====
    // ==== leaf:pixelSkillRow (spliced by build) ====
    // ==== leaf:pixelSkillList (spliced by build) ====
    // ==== leaf:pixelSkillDetailModal (spliced by build) ====
    // ==== leaf:pixelSkillOps (spliced by build) ====

    // ==== leaf:checksTab (spliced by build) ====

    const TABS_FOLD_HYST = 4
    const TABS_LEVELS = 3
    const tabsLevelDecide = function (level, avail, nats) {
      if (!Array.isArray(nats) || !nats.length) return 0
      let cur = level < 0 ? 0 : level
      while (cur < nats.length - 1 && nats[cur] > avail + 1) cur++
      while (cur > 0 && avail >= nats[cur - 1] + TABS_FOLD_HYST) cur--
      return cur
    }
    // issue#15 修复：scrollWidth 会被容器宽度钳制（容器宽于内容时 scrollWidth===clientWidth），
    // 导致折叠后展开判定 avail>=nats[cur-1]+4 永不成立（死锁）。改测内容 children 的真实横跨宽。
    const measureContentWidth = function (t) {
      if (!t || !t.children || t.children.length === 0) return 0
      const tr = t.getBoundingClientRect()
      let minX = Infinity, maxX = -Infinity
      for (let i = 0; i < t.children.length; i++) {
        const c = t.children[i]
        const r = c.getBoundingClientRect()
        if (r.width > 0) { if (r.x < minX) minX = r.x; if (r.x + r.width > maxX) maxX = r.x + r.width }
      }
      if (minX === Infinity) return 0
      return maxX - tr.x
    }
    // ==== leaf:namingFailBanner (spliced by build) ====

    // 2026-09-24：快照还没回来时那条灰色占位骨架（排在 dock 之前 —— 面板头部那一行要画它）。
    // ==== leaf:repoChipSkeleton (spliced by build) ====
    // ==== leaf:DockSync (spliced by build) ==== // ==== leaf:headFold (spliced by build) ==== // ==== leaf:dock (spliced by build) ====

    // ==== leaf:OverlayGate (spliced by build) ====

    // ==== kernel:updateClient (spliced by build) ====

    // ==== kernel:updateEntryBundle (spliced by build) ====

    // ==== leaf:debugSwitchFailHint (spliced by build) ==== // ==== leaf:SettingsWorkspaces (spliced by build) ====
    // #876：更新入口挂载点（只挂包的入口件，含内部 dialog 面板；本仓不再自带按钮状态机与浮层弹窗）
    // ==== leaf:updateEntryHost (spliced by build) ==== // ==== leaf:settingsPage (spliced by build) ====
    // ==== leaf:runPanel (spliced by build) ==== // ==== leaf:panelAssembly (spliced by build) ====
  },
}