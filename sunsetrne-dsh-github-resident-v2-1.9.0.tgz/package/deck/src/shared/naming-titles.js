// src/shared/naming-titles.js —— S2（#452）从 naming-guardian.js 拆出之占位识别、标题清洗截断、草稿档与编号档合成，纯结构、行为零变化。
// 以后谁改它：改占位四式、标题清洗截断规则、草稿档或编号档合成的人。预估约175行，超 350 打回。
// 接线：纯函数，无输入输出、无内核依赖（promptLang 为可选闭包自由变量，typeof 守卫）；不引用跟踪与归属文件（墙要求）；
//   宿主半运行时引用本文件（与另两文件合并），界面半由 scripts/build.mjs 以 SHARED_SPLICE 拼回闭包。

/**
 * src/shared/naming-titles.js — 命名守护标题合成半（#265/#205 · 从 naming-guardian.js 拆出，S2 #452）。
 *
 * 契约（#264 规约 · 单缝原则）：本文件是标题合成的真源 —— 占位识别、标题合成（草稿档 + 编号档，
 * 清洗截断沿用 #205 既有规则与 UTF-8 120 字节预算）。分档状态机、跟踪态、计划单见 naming-tracking.js，
 * 编号归属见 naming-attribution.js；三文件之间不互相引用（墙要求）。
 * 宿主半运行时引用本文件（与另两文件合并）；界面半由 scripts/build.mjs 以 SHARED_SPLICE 方式将
 * 三文件声明体拼回 src/client/index.js 闭包（一源两物，与 kernel/leaf 拼接同模式），
 * 两半均不另写第二处命名实现。
 *
 * 生效日期：2026-08-28
 * 效力规则：本文件以 #264 规约 + #260 五决议 + ADR 20260827 为基线；与更早方案冲突以
 *           本规约为准；未来任何定版方案若改动本规约，以未来版本为准（见 CONTEXT.md「版本与效力」）。
 *
 * 本模块为纯函数：无输入输出、无内核依赖（promptLang 为可选闭包自由变量，typeof 守卫），
 * 可被 Node 校验测试直接引用复跑。
 */

export const NAMING_CORE_VERSION = 1

// ============ 占位（P0）============
// 占位（#211 定版 · 跟随 harness 语言 + 动作分形）：
//   原四式：[New] 新建需求 / [New] 新建 Bug / New Requirement / New Bug（历史兼容保留）；
//   八个动作：诊断/修复/讨论/研究/原型/接手/补充/体检 —— 界面上每个建会话的入口各占一个（见 ACTION_WORDS）；
//   交接历史词（交接 / Handoff）仍视为占位，草稿时原样保留该词，不强制改成接手。
export const SESSION_TITLE_PREFIX = '[New]'

export const PLACEHOLDER_TITLES = {
  zh: { requirement: '新建需求', bug: '新建 Bug' },
  en: { requirement: 'New Requirement', bug: 'New Bug' },
}

// 动作中英文（用户定稿：占位加动作字，草稿落为对应动作档，不碰编号档）。八条各对应界面一个真实入口：
// 诊断/修复/讨论/研究/原型（行级动作与详情页顶栏）、接手（交接第二击）、补充（沉淀）、体检（体检按钮）。
export const ACTION_WORDS = {
  diagnose: { zh: '诊断', en: 'Diagnose' },
  fix: { zh: '修复', en: 'Fix' },
  discuss: { zh: '讨论', en: 'Discuss' },
  research: { zh: '研究', en: 'Research' },
  prototype: { zh: '原型', en: 'Prototype' },
  handoff: { zh: '接手', en: 'Handoff' },
  supplement: { zh: '补充', en: 'Supplement' },
  health: { zh: '体检', en: 'Health check' },
}

// 历史兼容：交接旧词仍算占位（新起统一用接手，旧会话的交接不判死）
const LEGACY_PLACEHOLDER_WORDS = ['交接', 'Handoff']

function allPlaceholderWords() {
  const out = []
  out.push(PLACEHOLDER_TITLES.zh.requirement, PLACEHOLDER_TITLES.zh.bug)
  out.push(PLACEHOLDER_TITLES.en.requirement, PLACEHOLDER_TITLES.en.bug)
  for (const k in ACTION_WORDS) {
    const w = ACTION_WORDS[k]
    if (w) { out.push(w.zh, w.en) }
  }
  for (let i = 0; i < LEGACY_PLACEHOLDER_WORDS.length; i++) out.push(LEGACY_PLACEHOLDER_WORDS[i])
  return out
}

export function isPlaceholderTitle(s) {
  const raw = String(s == null ? '' : s).trim()
  const words = allPlaceholderWords()
  for (let i = 0; i < words.length; i++) {
    if (raw === SESSION_TITLE_PREFIX + ' ' + words[i]) return true
  }
  return false
}

/** 生成占位标题（纯语言参数；lang 缺省 zh，'en' 开头即英文）。type 支持：bug/requirement + 动作键。 */
export function placeholderTitleFor({ type, lang }) {
  const t = String(type || '').toLowerCase()
  const en = typeof lang === 'string' && lang.indexOf('en') === 0
  // 七动作优先（diagnose/fix/discuss/research/prototype/handoff/supplement，前缀匹配即可）
  for (const k in ACTION_WORDS) {
    if (t.indexOf(k) === 0 || t === ACTION_WORDS[k].zh || t.toLowerCase() === ACTION_WORDS[k].en.toLowerCase()) {
      return SESSION_TITLE_PREFIX + ' ' + (en ? ACTION_WORDS[k].en : ACTION_WORDS[k].zh)
    }
  }
  const bug = t.indexOf('bug') >= 0
  const w = (en ? PLACEHOLDER_TITLES.en : PLACEHOLDER_TITLES.zh)[bug ? 'bug' : 'requirement']
  return SESSION_TITLE_PREFIX + ' ' + w
}

/**
 * 兼容签名 (type, lang?)：Tabs/StatusBar 沿用旧调用形态；lang 缺省按 harness 语言
 * （promptLang 为闭包自由变量，在宿主/Node 独立加载时 typeof 守卫安全降级 zh）。
 */
export function newSessionTitleNew(type, lang) {
  let en = false
  if (lang) {
    try { en = String(lang).toLowerCase().indexOf('en') === 0 } catch (e) {}
  } else {
    try { en = (typeof promptLang === 'function' ? promptLang() === 'en' : false) } catch (e) {}
  }
  return placeholderTitleFor({ type: type, lang: en ? 'en' : 'zh' })
}

// ============ 标题清洗/截断/编号档合成（#205 契约 · 迁移自 router.js）============
export const SESSION_TITLE_MAX_BYTES = 120

// 契约 #205：会话标题 = [#n] + 单空格 + 清洗后标题（120 bytes 预算，前缀永不截断）
export const SESSION_TITLE_RE = /^\[#\d+\] .+/

export const SESSION_TITLE_RE_ALLOW_BARE = /^\[#\d+\](?: .+)?$/

/** 编号档识别：`[#n]` 或 `[#n] 标题` → { number, title }；不是编号档回 null。
 *  注册通道用它把「在新会话打开」这类会话按编号档收编，好让宿主首句名盖不掉它。 */
export function parseNumberedTitle(s) {
  const m = /^\s*\[#(\d+)\](?:\s+([\s\S]*))?$/.exec(String(s == null ? '' : s))
  if (!m) return null
  // numberText 保留原样（本地 Markdown 后端的地图编号是 '00'，只留数值会被改写成 [0]，名字就变形了）
  return { number: Number(m[1]), numberText: m[1], title: cleanTitleText(m[2] || '') }
}

/** 清洗：剥控制/方向/隐形字符，空白归一为单空格并 trim，emoji 保留（沿用 #205 既有规则）。 */
export function cleanTitleText(s) {
  let t = String(s || '')
  t = t.replace(/\x1B\][^\x07]*\x07/g, '').replace(/\x1B\[[0-9;]*[A-Za-z]/g, '').replace(/\x1B[^\x5B\x5D\x07]/g, '')
  t = t.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, ' ')
  t = t.replace(/[\u200B-\u200F\u202A-\u202E\u2060-\u206F\uFEFF]/g, ' ')
  t = t.replace(/\s+/g, ' ').trim()
  return t
}

export function utf8Bytes(str) {
  if (typeof Buffer !== 'undefined' && Buffer.byteLength) return Buffer.byteLength(str, 'utf8')
  try { return new TextEncoder().encode(str).length } catch (e) { return str.length }
}

/** UTF-8 字节预算截断：prefix + 单空格 + title（超长尾部截 + …），prefix 永不截断。 */
export function truncateTitleUtf8(prefix, title, maxBytes) {
  const sep = ' '
  const base = prefix + sep
  const baseBytes = utf8Bytes(base)
  if (utf8Bytes(title) + baseBytes <= maxBytes) return title
  const ellipsis = '…'
  const ellipsisBytes = utf8Bytes(ellipsis)
  let acc = 0; let out = ''
  for (const ch of title) {
    const b = utf8Bytes(ch)
    if (baseBytes + acc + b + ellipsisBytes > maxBytes) break
    acc += b; out += ch
  }
  return out.trimEnd() + ellipsis
}

/** 编号档（P2）标题合成：[#n] + 清洗/截断后标题（#205 契约）。 */
export function newSessionTitle(t) {
  const raw = (t && t.numberText != null && String(t.numberText).trim()) ? String(t.numberText).trim() : (t && t.number != null ? t.number : '')
  const n = String(raw).trim()
  if (!/^\d+$/.test(n)) throw new Error('newSessionTitle: invalid number ' + n)
  const prefix = '[' + '#' + n + ']'
  let title = cleanTitleText(t && t.title != null ? t.title : '')
  if (!title) return prefix
  title = truncateTitleUtf8(prefix, title, SESSION_TITLE_MAX_BYTES)
  return prefix + ' ' + title
}

// ============ 草稿档（P1）============
// 档位词按本机语言落地（界面半按语言取词，计划单本身不含语言字面量 —— #264 D2）
export const DRAFT_WORDS = { zh: '草稿', en: 'Draft' }

export const DRAFT_TITLE_RE = /^\[(草稿|Draft)\](?: .+)?$/

export function draftWordFor(lang) {
  return typeof lang === 'string' && lang.indexOf('en') === 0 ? DRAFT_WORDS.en : DRAFT_WORDS.zh
}

/**
 * 草稿标题合成：面包屑语义线索优先（[草稿][新增需求/BUG] <线索>），无线索则仅类型标签；
 * 清洗截断沿用 #205 规则与 UTF-8 120 字节总预算（含前缀，前缀永不截断）。
 * baselineTitle 用于区分“新增需求”与“新增BUG”（取自注册占位），为用户要求“[草稿][新增需求]xxx”而加。
 */
export function composeDraftTitle({ hint, lang, baselineTitle }) {
  const prefix = '[' + draftWordFor(lang) + ']'
  const isEn = String(lang).toLowerCase().indexOf('en') === 0
  let typeTag = ''
  if (baselineTitle) {
    const bt = String(baselineTitle)
    // 七动作优先：基线含哪个动作词就落哪个动作档（如 [New] 诊断 → [草稿][诊断]）
    let hit = null
    for (const k in ACTION_WORDS) {
      const w = ACTION_WORDS[k]
      if (!w) continue
      if (bt.indexOf(w.zh) >= 0 || bt.toLowerCase().indexOf(w.en.toLowerCase()) >= 0) { hit = w; break }
    }
    // 历史兼容：旧交接词仍保留原词
    if (!hit) {
      if (bt.indexOf('交接') >= 0) hit = { zh: '交接', en: 'Handoff' }
    }
    if (hit) typeTag = '[' + (isEn ? hit.en : hit.zh) + ']'
    else {
      const isBug = /Bug/i.test(bt)
      if (isBug) typeTag = (isEn ? '[New Bug]' : '[新增BUG]')
      else typeTag = (isEn ? '[New Requirement]' : '[新增需求]')
    }
  }
  const fullPrefix = typeTag ? prefix + typeTag : prefix
  const rawHint = cleanTitleText(hint || '')
  if (!rawHint) return fullPrefix
  // 线索本身只是类型词（占位派生的“新建需求”“诊断”等）时不再叠字，直接裸档；
  // 无基线（无标签）时不去重，避免把有效线索吞掉。
  if (typeTag) {
    const condensed = String(rawHint).toLowerCase().replace(/\s+/g, '')
    const bareWords = ['新建需求', '新增需求', '新建bug', '新增bug', 'newrequirement', 'newbug',
      '诊断', '修复', '讨论', '研究', '原型', '接手', '补充', '交接', '体检',
      'diagnose', 'fix', 'discuss', 'research', 'prototype', 'handoff', 'supplement', 'health', 'healthcheck']
    if (bareWords.indexOf(condensed) >= 0) return fullPrefix
  }
  return fullPrefix + ' ' + truncateTitleUtf8(fullPrefix, rawHint, SESSION_TITLE_MAX_BYTES)
}
