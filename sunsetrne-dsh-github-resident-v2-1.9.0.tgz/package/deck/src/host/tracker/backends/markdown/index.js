import { ERROR_KIND } from '../../../../shared/tracker/constants.js'
import { mdPath, effortMapPath, effortIssuePath } from './path.js'
import { parseMd } from './parse.js'
import { normalizeIssue } from './normalize.js'
import { readTextFile, exists } from './read.js'
import { listIssues, getIssue, createIssue, closeIssue, reopenIssue, updateIssue, setBlockedByIssue, setAssigneesIssue, setParentIssue, setLabelsIssue } from './issues.js'
import { countIssues } from './counts.js'
import { listIssuesPage } from './page.js'
import { getDependenciesForKey } from './graph.js'
import { addComment } from './comments.js'
import { listLabels, setLabelColors } from './label-colors-ops.js'
import { ensureLabelColors } from './label-colors.js'
import { useBuiltinLabelColors } from './label-colors-palette.js'
import nodePath from 'node:path'
function getPlat(ctx){if(ctx&&ctx.platform&&ctx.platform.path)return ctx.platform.path;if(ctx&&ctx.path)return ctx.path;if(typeof process!=='undefined'&&process.platform==='win32')return nodePath.win32;return nodePath.posix}
function isAbsolute(p,plat){try{return plat.isAbsolute(p)}catch{return nodePath.isAbsolute(p)}}
export async function matches(handle, ctx){
  try{
    const cwd=handle&&handle.cwd?String(handle.cwd):(handle&&handle.refId?String(handle.refId):'')
    if(!cwd)return false
    const plat=getPlat(ctx)
    let candidatePaths=[]
    if(handle.refId&&String(handle.refId).includes('.scratch')){
      const p=isAbsolute(String(handle.refId),plat)?String(handle.refId):plat.join(cwd,String(handle.refId))
      candidatePaths.push(plat.join(p,'map.md'))
      candidatePaths.push(p)
    }
    const root=plat.join(cwd,'.scratch')
    candidatePaths.push(plat.join(root,'map.md'))
    try{
      const fs=ctx&&ctx.platform?ctx.platform.fs:(ctx&&ctx.fs)||(ctx&&typeof ctx.get==='function'?ctx.get('fs'):null)
      let entries=[]
      if(fs&&typeof fs.resolve==='function'&&typeof fs.listDir==='function'){try{const t=await fs.resolve(root);entries=await fs.listDir(t)}catch{}}
      else if(fs&&typeof fs.readdir==='function'){try{entries=await fs.readdir(root)}catch{}}
      for(const e of entries){
        const name=typeof e==='string'?e:(e&&e.name)||''
        if(!name||name.startsWith('.'))continue
        candidatePaths.push(plat.join(root,name,'map.md'))
      }
    }catch{}
    for(const p of candidatePaths){if(await exists(ctx,p))return true}
    // bug 修复：setup 已选 Local Markdown 但尚未落 map.md 时，仍应算 Markdown 身份（底层 Markdown 格式以 docs/agents/issue-tracker.md 声明为准，非仅 map.md 数据）
    try{
      const itPath=plat.join(cwd,'docs/agents/issue-tracker.md')
      if(await exists(ctx,itPath)){
        let txt=''
        try{ txt=await readTextFile(ctx,itPath) }catch{
          try{
            const fs2=ctx&&ctx.platform?ctx.platform.fs:(ctx&&ctx.fs)||null
            if(fs2&&typeof fs2.resolve==='function'&&typeof fs2.readText==='function'){ const t=await fs2.resolve(itPath,{cwd}); txt=await fs2.readText(t) }
          }catch{}
        }
        if(typeof txt==='string'&&/Local\s+Markdown/i.test(txt)) return true
      }
    }catch{}
    return false
  }catch{return false}
}
export function describe(handle, backendId){
  const cwd=handle&&handle.cwd?String(handle.cwd):''
  const refId=handle&&handle.refId?String(handle.refId):(cwd?cwd:'')
  const finalRef=refId||cwd||''
  const name=finalRef?finalRef.split(/[\\/]/).pop()||finalRef:backendId
  // effort 维度：handle 带 effortId 时如实透传（describe 是 ref 的唯一产地，这里丢掉就再也拿不回来）
  const out={backend:backendId,refId:finalRef,name:name||backendId,url:''}
  if(handle&&handle.effortId!==undefined&&handle.effortId!==null) out.effortId=String(handle.effortId)
  return out
}
export function issueUrl(ref, key) {
  try {
    if (ref == null || key == null) return ''
    const k = String(key).trim()
    if (!k) return ''
    const cwdArg = { cwd: (ref && ref.refId) || '' }
    // effort 维度：带 effort 范围的引用 → 路径落在 <cwd>/.scratch/<effortId>/ 下（'00' 是地图文件）
    if (ref.effortId !== undefined && ref.effortId !== null) {
      if (String(k).padStart(2, '0') === '00') return effortMapPath(ref, cwdArg)
      return effortIssuePath(ref, k, cwdArg)
    }
    // 文件约束内现算：mdPath 已处理 refId 绝对/相对、repo.path、getRoot 三分支
    // UI 拿到的是裸盘符路径（D:\…\issues\01-xxx.md），由 wf.openPath 按 OS 打开，不经 file:// 编码
    return mdPath(ref, 'issue', k, cwdArg)
  } catch { return '' }
}
export function searchUrl(name) { return '' }
export const linkPattern = "#(\\d+)"
export function createMarkdownBackend(ctx){
  return{
    id:'markdown',
    preflight: async (handle,opCtx)=>{
      const c=opCtx||ctx
      try{
        const plat=getPlat(c)
        const cwd=(handle&&handle.cwd)||(c&&c.cwd)||''
        // 检查全局 .scratch 下是否有任意 map.md 或 docs 声明
        if(cwd){
          const root=plat.join(cwd,'.scratch')
          try{
            const fs=c&&c.platform?c.platform.fs:(c&&c.fs)||(c&&typeof c.get==='function'?c.get('fs'):null)
            let entries=[]
            if(fs&&typeof fs.resolve==='function'&&typeof fs.listDir==='function'){try{const t=await fs.resolve(root);entries=await fs.listDir(t)}catch{}}
            else if(fs&&typeof fs.readdir==='function'){try{entries=await fs.readdir(root)}catch{}}
            for(const e of entries){
              const name=typeof e==='string'?e:(e&&e.name)||''
              if(!name||name.startsWith('.'))continue
              const cand=plat.join(root,name,'map.md')
              if(await exists(c,cand)) return{ok:true}
            }
            if(await exists(c,plat.join(root,'map.md'))) return{ok:true}
          }catch{}
        }
        const repo=handle&&handle.backend?handle:describe(handle,'markdown')
        const mapP=mdPath(repo,'map',undefined,c)
        if(await exists(c,mapP))return{ok:true}
        const plat2=getPlat(c)
        const cwd2=(handle&&handle.cwd)||(c&&c.cwd)||''
        if(cwd2){
          const root=plat2.join(cwd2,'.scratch')
          if(await exists(c,plat2.join(root,'map.md')))return{ok:true}
        }
        return{ok:false,error:{kind:ERROR_KIND.NOTFOUND,message:'markdown map.md not-found'}}
      }catch(e){const kind=e&&e.kind?e.kind:ERROR_KIND.ENV;return{ok:false,error:{kind,message:e&&e.message?e.message:String(e)}}}
    },
    list:(repo,filter,opCtx)=>listIssues(opCtx||ctx,repo,filter),
    // #691：本地 Markdown 补上契约的 counts（数「列举会返回的那些票行」，地图容器行分开算）。
    // 语义见 tracker/contract.js 的「计数契约」；本后端数的口径见 counts.js 顶部注释。
    counts:(repo,filter,opCtx)=>countIssues(opCtx||ctx,repo,filter),
    // #691：本地 Markdown 补上契约的 listPage（按「创建时间倒序」切一页票行 + 同口径总数）。
    // 语义见 tracker/contract-page.js 的「分页契约」；本后端的游标是「排好序的票行列表里的下标」。
    listPage:(repo,filter,opts,opCtx)=>listIssuesPage(opCtx||ctx,repo,filter,opts),
    get:(repo,key,opts,opCtx)=>getIssue(opCtx||ctx,repo,key,opts),
    getDependencies:(repo,key,opts,opCtx)=>getDependenciesForKey(opCtx||ctx,repo,key),
    create:(repo,input,opCtx)=>createIssue(opCtx||ctx,repo,input),
    close:(repo,key,opts,opCtx)=>closeIssue(opCtx||ctx,repo,key),
    reopen:(repo,key,opCtx)=>reopenIssue(opCtx||ctx,repo,key),
    comment:(repo,key,body,opCtx)=>addComment(opCtx||ctx,repo,key,body),
    update:(repo,key,patch,opCtx)=>updateIssue(opCtx||ctx,repo,key,patch),
    setLabels:(repo,key,labels,opts,opCtx)=>setLabelsIssue(opCtx||ctx,repo,key,labels),
    setAssignees:(repo,key,assignees,opts,opCtx)=>setAssigneesIssue(opCtx||ctx,repo,key,assignees),
    setParent:(repo,key,parentKey,opts,opCtx)=>setParentIssue(opCtx||ctx,repo,key,parentKey),
    setBlockedBy:(repo,key,blockers,opts,opCtx)=>setBlockedByIssue(opCtx||ctx,repo,key,blockers),
    // #618：标签配色契约的两条操作（形状见 src/host/tracker/contract.js 的「标签配色契约」一节）。
    // listLabels 会在文件缺失时顺手补一份默认配色文件（首次打开改色弹窗那条放置路）。
    listLabels:(repo,opCtx)=>listLabels(opCtx||ctx,repo),
    setLabelColors:(repo,changes,opCtx)=>setLabelColors(opCtx||ctx,repo,changes),
    // 放置配色文件的入口，给「用户为工作区选定后端」那一步用（host 不问后端 id，只问它愿不愿意放）。
    // 只有本后端实现它，所以只有 Markdown 系后端会往工作区放这个文件。
    ensureLabelColorsFile:(repo,opCtx)=>ensureLabelColors(opCtx||ctx,repo),
    getCurrentUser: async ()=>({ok:false,error:{kind:ERROR_KIND.UNSUPPORTED,message:'markdown getCurrentUser unsupported'}}),
    initProject: async ()=>({ok:false,error:{kind:ERROR_KIND.UNSUPPORTED,message:'markdown initProject unsupported'}}),
    normalize:normalizeIssue,
    parse:parseMd,
  }
}
/** #323（2026-08-29 定版复核）：本地 Markdown 后端自己的默认调色盘（不依赖 GitHub）——
 *  这里是本地标签结构与**内置默认色值**的真源；模块经契约层（BackendModule.labelPalette）提供给面板。
 *  #618 起颜色的可改层换成工作区里的 docs/agents/label-colors.json（用户可手改的那份配色文件），
 *  旧的那张 docs/agents/triage-labels.md 调色盘表不再读（干净切断，不迁移、不回填）。
 *  颜色渲染由宿主侧按配色文件查色、文件里没收录的回落这份内置默认色，AI 不参与。 */
export const defaultLabelPalette = [
  { name: 'bug', color: 'd73a4a' },
  { name: 'needs-triage', color: 'fbca04' },
  { name: 'needs-info', color: '5319e7' },
  { name: 'ready-for-agent', color: '0e8a16' },
  { name: 'ready-for-human', color: 'b60205' },
  { name: 'wontfix', color: 'ffffff' },
  { name: 'wayfinder:map', color: '8b5cf6' },
  { name: 'wayfinder:research', color: '0ea5e9' },
  { name: 'wayfinder:prototype', color: 'f59e0b' },
  { name: 'wayfinder:grilling', color: '9d7cd8' },
  { name: 'wayfinder:task', color: '10b981' },
]
// 这一份就是全仓唯一的内置默认色表：标签配色机制（label-colors.js）用它做三件事——
// 并集里补上内置默认的那些标签、首建配色文件时按它预填、票面标签既不在文件里也不在内置表里才回灰。
// 为什么用「装载时交给它」而不是让它自己 import 这份表：本文件会 import label-colors.js，
// 反过来的 import 会形成循环引用（Node 能跑，但读代码的人很难判断谁先初始化）。
useBuiltinLabelColors(defaultLabelPalette)
/** 修复契约注入文案（Markdown 后端本地语义，双语单源；供 fixes 引用，host 组装时解析）。 */
export const prompts = {
  // #716：本地 Markdown 后端没有自己的命令行工具（票就是工作区里的文件），所以只声明站点名字；
  //   {cli} 那一格留空，渲染时回落中性说法「当前后端的命令行」—— 提示词里绝不写死别的后端的命令名。
  commandVocabulary: { cliBrand: '本地 Markdown' },
  // 2026-08-29 定版（用户）：注入只放 /wayfinder 命令与需求占位，规则由技能自身负责，不加解释。
  wayfinderMapBuild: {
    zh: '/wayfinder (请输入任务需求)',
    en: '/wayfinder (enter the task requirement)',
  },
  subIssue: {
    // 2026-09 修正：旧文案让 agent 执行 setParent(map.key) / list({parentKey})，但宿主侧没有这些 agent tool，
    //   随包分发的也只有两个 GitHub 专用脚本 —— 照做不到。改成这个后端真的能做的动作：在 map 文件的任务清单里引用子票。
    zh: '在本仓库的 map 文件里，按已有写法在任务清单逐条引用这些子票，并把清单条目数与 map 的子票数对齐一致',
    en: 'add each sub-ticket to the task list inside the map file the way this repo already writes it, and keep the task-list entry count equal to the map sub-ticket count',
  },
  // #684：「体检」的本地 Markdown 科目。这里的票就是工作区里的文件，所以游离必须落到文件上：
  //   两条判据查的都是「票文件与地图清单对不对得上」。另外照别的后端那条口径，把「这张能不能单张票处理掉」
  //   的 AI 判断一起带上（是的话也可以不管、只在报告里登记一行）。
  // #716：本条原先点名「与 GitHub 同一套」「照 GitHub 的口径」—— 这是本地后端自己的科目，不该拿另一个
  //   后端的名字来解释自己，改成中性说法（同一个工作区的票仓结构在三个后端上本来就是同一套）。
  healthCheck: {
    zh: '**本后端的票就是工作区里的文件**（每个工作单元一个目录，地图写在 map.md 里、每张票写成一个文件），所以「游离」必须落到文件上。**查两条文件级判据**：\n1. 票文件存在，却没有被任何 map.md 的清单引用 —— 游离在外；\n2. map.md 的清单里列了某张票，但对应的文件不存在 —— 断链。\n\n**一条 AI 判断照同一套口径一起带上**：对每一张判一句「这张是不是明确可以单张票处理掉的」；是的话也可以不管，只登记一行。\n\n**三种结论**（挂在某张地图下 / 建议自立成一张新地图 / 建议留在原地 + 一句话理由）都只进建议清单，等人点头才动手。\n\n**不碰**：已关闭的票、任何票的标题与正文、标签与认领状态、别的仓库；不关票、不改源码、不提交。\n\n体检的范围是这个工作区里的全部票文件，不跟随面板当前的筛选。',
    en: '**On this backend a ticket is a file in this workspace** (one directory per work unit, the map written as map.md and each ticket as a file), so "orphaned" has to land on files. **Check two file-level criteria**:\n1. a ticket file exists but no map.md list references it — it is floating outside;\n2. a map.md list references a ticket whose file does not exist — a broken link.\n\n**One AI judgement on the same rules**: for each ticket, judge with one sentence — "is this clearly something a single ticket can finish?" If yes, you may also leave it alone and just log one line.\n\n**All three conclusions** (attach under a map / suggest a new map of its own / suggest leaving it where it is + a one-sentence reason) only go into the suggestion list — act only after the human nods.\n\n**Never touch**: closed tickets, any ticket title or body, labels and claim state, other repositories; do not close tickets, change source code, or commit.\n\nThe health check covers every ticket file in this workspace and does not follow the current panel filters.',
  },
}

/** 修复契约（Fix Contract · 2026-08-28）：后端检查失败 → 修复指引；结构见 host/tracker/fixContract.js。
 * 2026-08-29 用户定版：
 *  - md:scratchWritable 不提供修复指引（后端无法修复目录存在/权限问题——行 fail 仅如实展示，无按钮）；
 *  - md:parseOk 的修复指引 = 注入 wayfinder 技能构造关卡地图（地图缺失才失败，唯一真实修复路径是生成地图）。 */
export const fixes = Object.freeze({
  'md:parseOk': {
    hint: {
      zh: '本项目的关卡地图还没生成。点「执行 wayfinder 构造地图」让 AI 用 wayfinder 技能生成地图，完成后重查。',
      en: 'The local track map has not been created yet. Use "Build map with wayfinder" to have AI generate the map via the wayfinder skill, then re-check.',
    },
    actions: [
      { type: 'inject-prompt', prompt: 'wayfinderMapBuild', label: { zh: '执行 wayfinder 构造地图', en: 'Build map with wayfinder' } },
      { type: 'refresh', target: 'chain' },
    ],
  },
})

export const markdownModule = {
  id: 'markdown',
  label: 'Markdown',
  describe,
  issueUrl,
  searchUrl,
  linkPattern,
  // #191：品牌色完整色板（B 方案定版 · #177）
  presentation: {
    color: '#1a7f37',
    darkColor: '#3fb950',
    bg: 'light-dark(rgba(26,127,55,.12), rgba(63,185,80,.14))',
    border: 'light-dark(rgba(26,127,55,.25), rgba(63,185,80,.30))',
  },
  // #230（D10 · 键入 locale）：setup 描述数据键；labelReqs='' → Markdown 注入的 setupRun 不要求标签齐全
  setupPrompt: {
    trackerLine: 'setup.markdown.trackerLine',
    trackerChoice: 'setup.markdown.trackerChoice',
    backendNote: 'setup.markdown.backendNote',
    labelReqs: 'setup.markdown.labelReqs',
  },
  // #323（2026-08-29 定版复核）：本地后端自己的默认调色盘（结构/label/颜色）经契约层供给面板；工作区表为用户覆盖层
  labelPalette: defaultLabelPalette,
  create: createMarkdownBackend,
  matches,
  // #231：本地 Markdown 无远程链接 —— issueUrl 由后端现算为裸盘符路径，links 仅留提及识别正则；开仓为打开文件夹
  links: { linkPatternSource: "#(\\d+)" },
  openRepository: 'folder',
  prompts,
  fixes,
}
export default createMarkdownBackend