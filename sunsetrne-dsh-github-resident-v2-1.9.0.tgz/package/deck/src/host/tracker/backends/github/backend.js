/**
 * backends/github/backend.js — 后端装配（githubMatches / createGithubBackend）。
 *
 * 由 #440 从 index.js 纯结构移出，行为零变化。
 * 以后改后端装配的人改它。预估约 115 行。
 */

import { ERROR_KIND } from '../../../../shared/tracker/constants.js'
import { ghClient } from './client.js'
import { ghPreflight } from './preflight.js'
import { listIssues, getIssue } from './issues.js'
import { countIssues } from './counts.js'
import { listIssuesPage } from './page.js'
import { listSubIssues } from './sub-issues.js'
import { createIssue, closeIssue, reopenIssue, updateIssue, setAssignees } from './issues-write.js'
import { addComment } from './comments.js'
import { setLabels } from './labels.js'
import { readRepoPermissions } from './repo-permissions.js'
import { listLabels, setLabelColors } from './label-colors-ops.js'
import { setParent, getDependencies, setBlockedBy } from './graph.js'
import { initProject } from './init-project.js'
import { describe, issueUrl, getRepoKey } from './repo.js'

/**
 * Registry 身份：matches(handle, ctx) → boolean
 * 启发式：handle.refId 含 '/' → 视为 github（显式绑定）；否则检查 cwd 下 .git/config 是否含 github.com
 * 不抛错；不确定一律 false + diagnostics 由 registry 调用方日志（此处只返回 boolean）
 */
export async function githubMatches(handle, ctx) {
  try {
    if (handle && typeof handle.refId === 'string' && handle.refId.includes('/')) {
      // 若 refId 已显式为 owner/name，视为命中（由 host 显式绑定或 registry describe 产生）
      // 进一步可校验 fs 上是否有 .scratch/map.md，但 GitHub 真实归属以 remote 为准，此处宽松命中
      return true
    }
    // 尝试读 .git/config（经 platform.fs）
    const platform = ctx && ctx.platform ? ctx.platform : null
    const fs = platform && platform.fs ? platform.fs : (ctx && ctx.fs ? ctx.fs : null)
    const cwd = (handle && handle.cwd) || (ctx && ctx.cwd) || ''
    if (fs && cwd && typeof fs.readText === 'function' && typeof fs.resolve === 'function') {
      try {
        const t = await fs.resolve('.git/config', { cwd })
        const txt = await fs.readText(t)
        if (typeof txt === 'string' && /github\.com/i.test(txt)) return true
      } catch {}
    }
    // 回落：尝试 git remote get-url origin（经 ctx.exec）
    if (ctx && typeof ctx.exec === 'function' && cwd) {
      try {
        const r = await ctx.exec('git', ['-C', cwd, 'remote', 'get-url', 'origin'], { cwd, timeout: 3000 })
        const out = (r && (r.stdout || r.text)) || ''
        if (/github\.com/i.test(String(out))) return true
      } catch {}
    }
    return false
  } catch {
    return false
  }
}

/**
 * 创建 GitHub 后端适配器（Tracker）。
 * @param {import('../../contract.js').BackendContext} ctx DSH host ctx（platform 已解析实例注入，#113）
 * @returns {import('../../contract.js').Tracker}
 */
export function createGithubBackend(ctx) {
  // 可选：预解析 ghPath 无副作用，此处不做
  void ghClient(ctx)
  return {
    id: 'github',
    preflight: (handle, opCtx) => ghPreflight(handle, opCtx || ctx),
    list: (repo, filter, opCtx) => listIssues(repo, filter, opCtx || ctx),
    // #689：后端计数（一次 GraphQL 的 totalCount，只数工单）。语义见 contract.js 的「计数契约」。
    counts: (repo, filter, opCtx) => countIssues(repo, filter, opCtx || ctx),
    // #690：按页取票（创建时间倒序 + 薄片段 + 游标 + 总数）。语义见 tracker/contract-page.js 的「分页契约」。
    listPage: (repo, filter, opts, opCtx) => listIssuesPage(repo, filter, opts, opCtx || ctx),
    // #691：一张地图的全部子票（翻页拉到底 + totalCount 核对 + 1000 张硬上限）。
    //   它是读路径的实现细节、不进契约的 OPERATIONS（与 snapshotFast 同一条豁免，见 contract.js 的「非 op 旁路豁免」）；
    //   唯一调用者是宿主电话 wf.mapTickets，没实现它的后端由那条电话按 unsupported 退化。
    listSubIssues: (repo, mapKey, opts, opCtx) => listSubIssues(repo, mapKey, opts, opCtx || ctx),
    get: (repo, key, opts, opCtx) => getIssue(repo, key, opts, opCtx || ctx),
    getDependencies: (repo, key, opts, opCtx) => getDependencies(repo, key, opts, opCtx || ctx),
    create: (repo, input, opCtx) => createIssue(repo, input, opCtx || ctx),
    close: (repo, key, opts, opCtx) => closeIssue(repo, key, opts, opCtx || ctx),
    reopen: (repo, key, opCtx) => reopenIssue(repo, key, opCtx || ctx),
    comment: (repo, key, body, opCtx) => addComment(repo, key, body, opCtx || ctx),
    update: (repo, key, patch, opCtx) => updateIssue(repo, key, patch, opCtx || ctx),
    setLabels: (repo, key, labels, opts, opCtx) => setLabels(repo, key, labels, opts, opCtx || ctx),
    // #620：仓库级的两条标签配色操作（列全部标签 / 批量改颜色），实现见 label-colors-ops.js
    listLabels: (repo, opCtx) => listLabels(repo, opCtx || ctx),
    setLabelColors: (repo, changes, opCtx) => setLabelColors(repo, changes, opCtx || ctx),
    setAssignees: (repo, key, assignees, opts, opCtx) => setAssignees(repo, key, assignees, opts, opCtx || ctx),
    setParent: (repo, key, parentKey, opts, opCtx) => setParent(repo, key, parentKey, opts, opCtx || ctx),
    setBlockedBy: (repo, key, blockers, opts, opCtx) => setBlockedBy(repo, key, blockers, opts, opCtx || ctx),
    getCurrentUser: async (repo, opCtx) => {
      const c = ghClient(opCtx || ctx)
      const r = await c.execGh(['api', 'user', '--jq', '{login: .login, name: .name, avatarUrl: .avatar_url}'], { cwd: (opCtx && opCtx.cwd) || (ctx && ctx.cwd) })
      if (!r.ok) {
        const kind = (r.error && r.error.kind) || 'unsupported'
        // 未登录或无权限 → 返回 unsupported，UI 将不做“本人不显”过滤（全显）
        if (kind === 'auth' || kind === 'unsupported') return { ok: false, error: { kind: ERROR_KIND.UNSUPPORTED, message: r.error && r.error.message || 'viewer unsupported' } }
        return { ok: false, error: r.error }
      }
      try {
        const j = JSON.parse(r.data.stdout || r.data.text || '{}')
        const login = String(j.login || '').trim()
        if (!login) return { ok: false, error: { kind: ERROR_KIND.UNSUPPORTED, message: 'viewer login empty' } }
        const actor = { login }
        if (j.name) actor.name = String(j.name)
        if (j.avatarUrl) actor.avatarUrl = String(j.avatarUrl)
        else if (j.avatar_url) actor.avatarUrl = String(j.avatar_url)
        actor.kind = 'user'
        return { ok: true, data: actor }
      } catch (e) {
        return { ok: false, error: { kind: ERROR_KIND.PARSE, message: String(e.message || e) } }
      }
    },
    initProject: (handle, input, opCtx) => initProject(handle, input, opCtx || ctx),
    describe: (handle, opCtx) => describe(handle, 'github'),
    issueUrl: (ref, key) => issueUrl(ref, key),
    // 调用方没有仓库标识时的补全口（#758）：注册表出空 refId 是常态（匹配源不带标识），
    // 有该能力的后端把三层兜底（git remote → 配置 → gh 视图）开给调用方自己补；
    // 没有该能力的后端没有这一格，调用方跳过，原样诚实失败。只读，无副作用。
    getRepoKey: (cwd, opCtx) => getRepoKey(cwd, opCtx || ctx),
    // #992：仓库写权限旁路（只读，不进 OPERATIONS、不驱动渲染分支、不参与能力验证）。
    //   这是 contract.js「非 op 旁路豁免」那一条的用法（与 listSubIssues 同例）：只回答
    //   「当前账号在这个仓库上有没有 push / triage」，给 deck_context 的能力位与失败归因共用。
    //   问不出来（网络、仓库不存在）如实回 ok:false，调用方按「未知」处理，不捏造。
    getRepoPermissions: async (repo, opCtx) => {
      const c = ghClient(opCtx || ctx)
      const refId = repo && typeof repo.refId === 'string' ? repo.refId.trim() : ''
      const idx = refId.indexOf('/')
      if (idx <= 0) return { ok: false, error: { kind: ERROR_KIND.NOTFOUND, message: 'getRepoPermissions: repo.refId missing' } }
      const perms = await readRepoPermissions(c, refId, opCtx || ctx)
      if (!perms) return { ok: false, error: { kind: ERROR_KIND.NETWORK, message: 'getRepoPermissions: 仓库权限问不出来（网络或仓库不可达），按未知处理' } }
      return { ok: true, data: perms }
    },
  }
}
