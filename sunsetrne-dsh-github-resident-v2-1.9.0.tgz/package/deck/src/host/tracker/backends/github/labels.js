/**
 * backends/github/labels.js — 「票身上带哪些标签」的实现（#133 定版 + #138 落地）。
 *
 * 契约：`setLabels(repo, key, labels: LabelInput[], opts?: SetOpts, ctx: OpContext): Promise<OpResult<Issue>>`
 *  - `LabelInput = string | {name: string, color?: string, description?: string}`
 *  - `SetOpts = { expectedUpdatedAt?: string }` → 不匹配 → `kind:'conflict'`（显式产生，非 regex）
 *  - Last-write-wins 且整集替换（尽力单次/近原子；GitHub 用 diff → gh issue edit --add-label/--remove-label）
 *  - GitHub 原生支持 labels → `Issue.labels` 恒存在，空→ `[]` EMPTY（#126），颜色无则 ''（string 非 number）
 *
 * 2026-09-13（#620）：仓库级的「列全部标签 / 批量改标签颜色」两条契约操作搬进同目录的
 * label-colors-ops.js（它们跟这里的 setLabels 不是一件事：这里是给一张票贴标签，那两条是改仓库的标签本身）。
 * 本文件只保留了它们要用的仓库名拆解（parseRepo / repoId），不再自己列标签。
 */

import { fail } from '../../preflight.js'
import { ERROR_KIND } from '../../../../shared/tracker/constants.js'
import { normalizeIssue } from './normalize.js'
import { ghClient } from './client.js'
import { classifyGhError } from './errors.js'
import { readRepoPermissions, readonlyMessage } from './repo-permissions.js'
import { getIssue } from './issues.js'

function normalizeLabelInput(li) {
  if (typeof li === 'string') {
    const name = li.trim()
    if (!name) return null
    return { name, color: '' }
  }
  if (!li || typeof li !== 'object') return null
  const name = typeof li.name === 'string' ? li.name.trim() : ''
  if (!name) return null
  const color = typeof li.color === 'string' ? li.color : ''
  const out = { name, color }
  if (typeof li.description === 'string' && li.description.trim() !== '') out.description = li.description
  return out
}

function normalizeLabelInputs(labels) {
  if (!Array.isArray(labels)) return []
  const out = []
  const seen = new Set()
  for (const li of labels) {
    const l = normalizeLabelInput(li)
    if (!l) continue
    if (seen.has(l.name)) continue
    seen.add(l.name)
    out.push(l)
  }
  return out
}

export function parseRepo(repo) {
  if (!repo || typeof repo.refId !== 'string' || !repo.refId) return null
  const s = repo.refId.trim()
  const idx = s.indexOf('/')
  if (idx <= 0) return null
  return { owner: s.slice(0, idx), name: s.slice(idx + 1) }
}

export function repoId(repo) {
  if (!repo) return ''
  if (typeof repo.refId === 'string' && repo.refId) return repo.refId
  if (typeof repo.name === 'string' && repo.name) return repo.name
  return ''
}

/**
 * 给票贴标签失败时的归因（#992）。
 * 只读仓库上建标签定义（要 push）与给票打标（要 triage 起）撞到的都是 404，
 * 光看错误文本分不清「标签不存在」还是「你没有写权限」。撞到疑似权限的失败
 * （404 或 GraphQL 那句复数权限句）就多问一次仓库权限：只有读权限（triage 为假）
 * 才改判成鉴权档并说清仓库与原因；问不出来或本就有写权限，原样返回、不瞎猜。
 */
async function attributeLabelFailure(c, spec, wantNames, err, ctx) {
  const text = String((err && (err.message || err.stderr)) || '')
  const suspicious = /HTTP 404|\b404\b|does not have the correct permissions|addlabelstolabelable/i.test(text)
    || (err && err.kind === ERROR_KIND.AUTH)
  if (!suspicious) return err
  const perms = await readRepoPermissions(c, spec, ctx)
  if (perms && perms.triage === false) {
    return { kind: ERROR_KIND.AUTH, message: readonlyMessage(spec, wantNames) }
  }
  return err
}

/**
 * 整集替换 labels（GitHub 对齐）。
 * 若提供 expectedUpdatedAt，先取当前 Issue.updatedAt 比对，不匹配 → conflict 不落盘。
 */
export async function setLabels(repo, key, labels, opts, ctx) {
  const wanted = normalizeLabelInputs(labels)
  const k = String(key || '').trim()
  if (!k) return fail(ERROR_KIND.PARSE, 'setLabels: key required (string)')

  try {
    const parsed = parseRepo(repo)
    if (!parsed) return fail(ERROR_KIND.NOTFOUND, `setLabels: repo.refId missing: ${repoId(repo)}`)

    // If-Match 前置：expectedUpdatedAt 强一致
    if (opts && typeof opts.expectedUpdatedAt === 'string' && opts.expectedUpdatedAt !== '') {
      const cur = await getIssue(repo, k, {}, ctx)
      if (!cur.ok) return cur
      if (cur.data.updatedAt !== opts.expectedUpdatedAt) {
        return fail(ERROR_KIND.CONFLICT, `conflict: expectedUpdatedAt mismatch (want ${opts.expectedUpdatedAt} got ${cur.data.updatedAt})`)
      }
    }

    const c = ghClient(ctx)
    // 读当前 labels 做 diff（需知 toAdd/toRemove）
    const curRes = await getIssue(repo, k, {}, ctx)
    const curLabels = curRes.ok ? curRes.data.labels.map((l) => l.name) : []
    const wantNames = wanted.map((l) => l.name)
    const toAdd = wantNames.filter((n) => !curLabels.includes(n))
    const toRemove = curLabels.filter((n) => !wantNames.includes(n))
    const spec = `${parsed.owner}/${parsed.name}`

    for (const n of toRemove) {
      const r = await c.execGh(['issue', 'edit', k, '--repo', spec, '--remove-label', n], { cwd: ctx && ctx.cwd })
      if (!r.ok) return { ok: false, error: await attributeLabelFailure(c, spec, wantNames, r.error, ctx) }
    }
    for (const n of toAdd) {
      const r = await c.execGh(['issue', 'edit', k, '--repo', spec, '--add-label', n], { cwd: ctx && ctx.cwd })
      if (!r.ok) return { ok: false, error: await attributeLabelFailure(c, spec, wantNames, r.error, ctx) }
    }

    // 读回最新
    const finalRes = await getIssue(repo, k, {}, ctx)
    if (!finalRes.ok) {
      // optimistic 回落（测试桩或离线时）
      const optimisticRaw = { number: Number(k) || k, title: '', state: 'open', body: '', url: '', labels: { nodes: wanted.map((l) => ({ name: l.name, color: l.color || '', description: l.description || '' })) }, updatedAt: new Date().toISOString() }
      const issue = normalizeIssue(optimisticRaw)
      issue.labels = wanted
      return { ok: true, data: issue }
    }
    // 确保 labels 为归一后的 wanted（带 color '' 兜底、description 可选）
    finalRes.data.labels = wanted
    return finalRes
  } catch (err) {
    const kind = classifyGhError(err)
    if (kind === ERROR_KIND.CONFLICT) return fail(ERROR_KIND.CONFLICT, err && err.message ? String(err.message) : 'conflict')
    return fail(kind, err && err.message ? String(err.message) : String(err))
  }
}

// 旧名兼容：addLabel → setLabels（#124：label→setLabels）—— 保留别名但标记弃用
export const addLabel = (...args) => setLabels(...args)

export default { setLabels, addLabel }
