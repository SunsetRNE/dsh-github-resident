/**
 * backends/github/normalize.js — GitHub 原始形状 → 契约标准形状。
 *
 * 定版依据：#126（Label 形状与 EMPTY/MISSING）+#127（单 key/无 number/无 subIssues/树边=parentKey+tickets）
 * +#124（setLabels/create labels 富输入）+#138 一页纸方案（形状归一不变量）
 *
 * 不变量（第一性推导）：
 *  - 单 key：`Issue.key: string = String(raw.number)`，永不产出 `number` 字段（harness 断言 no number）。
 *  - 无 `subIssues`/`blocking`：树边 = `parentKey` 向上 + `MapNode.tickets` 向下；`blocking` 仅 `getDependencies` 投影。
 *  - GitHub 原生支持 labels/assignees/comments/blockedBy/reason → 恒 EMPTY（[]/'' 非 MISSING），capability-by-fill。
 *  - `Label = { name: string; color: string; description?: string }`，color 无则 ''，description 仅非空携带。
 *  - `parentKey: string|null` 核心字段永远存在；子票只认原生 parent（忽略 task list）。
 */

import { STATE, ISSUE_TYPE } from '../../../../shared/tracker/constants.js'

function normalizeLabel(rawLabel) {
  if (typeof rawLabel === 'string') {
    const name = rawLabel.trim()
    if (!name) return null
    return { name, color: '' }
  }
  if (!rawLabel || typeof rawLabel !== 'object') return null
  const name = typeof rawLabel.name === 'string' ? rawLabel.name.trim() : ''
  if (!name) return null
  const color = typeof rawLabel.color === 'string' ? rawLabel.color : ''
  const out = { name, color }
  if (typeof rawLabel.description === 'string' && rawLabel.description.trim() !== '') {
    out.description = rawLabel.description
  }
  return out
}

function normalizeLabels(raw) {
  let nodes = null
  if (raw && raw.labels && Array.isArray(raw.labels.nodes)) nodes = raw.labels.nodes
  else if (Array.isArray(raw && raw.labels)) nodes = raw.labels
  else if (Array.isArray(raw)) nodes = raw
  else return [] // 无来源 → EMPTY（GitHub 恒可实现）
  const out = []
  for (const n of nodes) {
    const l = normalizeLabel(n)
    if (l) out.push(l)
  }
  return out
}

function kindFromTypename(t) {
  const s = String(t || '').toLowerCase()
  if (s === 'bot') return 'bot'
  if (s === 'organization') return 'organization'
  return 'user'
}

function normalizeActor(raw) {
  if (!raw || typeof raw !== 'object') return null
  const login = typeof raw.login === 'string' ? raw.login.trim() : ''
  if (!login) return null
  const out = { login }
  const kind = raw.__typename ? kindFromTypename(raw.__typename) : (raw.kind ? String(raw.kind) : undefined)
  if (kind) out.kind = kind
  if (typeof raw.name === 'string' && raw.name.trim() !== '') out.name = raw.name
  if (typeof raw.avatarUrl === 'string' && raw.avatarUrl !== '') out.avatarUrl = raw.avatarUrl
  else if (typeof raw.avatar_url === 'string' && raw.avatar_url !== '') out.avatarUrl = raw.avatar_url
  return out
}

function normalizeAssignees(raw) {
  let nodes = null
  if (raw && raw.assignees && Array.isArray(raw.assignees.nodes)) nodes = raw.assignees.nodes
  else if (Array.isArray(raw && raw.assignees)) nodes = raw.assignees
  else if (raw && Array.isArray(raw.nodes)) nodes = raw.nodes
  else return [] // GitHub 恒实现 → EMPTY
  const out = []
  for (const n of nodes) {
    const a = normalizeActor(n)
    if (a) out.push(a)
  }
  return out
}

function deriveKey(raw) {
  if (raw == null) return '0'
  if (typeof raw.key === 'string' && raw.key !== '') return raw.key
  if (raw.number != null) return String(raw.number)
  if (raw.id != null) return String(raw.id)
  return '0'
}

function deriveType(raw) {
  const labels = normalizeLabels(raw)
  if (labels.some((l) => l.name === 'wayfinder:map')) return ISSUE_TYPE.MAP
  if (raw && (raw.isMap === true || raw.type === 'map')) return ISSUE_TYPE.MAP
  return ISSUE_TYPE.ISSUE
}

function deriveParentKey(raw) {
  if (!raw) return null
  if (typeof raw.parentKey === 'string') return raw.parentKey
  if (raw.parentKey === null) return null
  if (raw.parent && raw.parent.number != null) return String(raw.parent.number)
  if (raw.parent && typeof raw.parent.key === 'string') return raw.parent.key
  return null
}

function normalizeMilestone(raw) {
  const src = raw && raw.milestone
  if (!src || typeof src !== 'object') return undefined
  const title = typeof src.title === 'string' ? src.title.trim() : ''
  if (!title) return undefined
  const out = { name: title }
  if (typeof src.description === 'string' && src.description.trim() !== '') out.description = src.description
  if (typeof src.state === 'string') {
    const s = src.state.toLowerCase()
    if (s === 'open' || s === 'closed') out.state = s
  }
  if (typeof src.dueOn === 'string' && src.dueOn !== '') out.dueOn = src.dueOn
  else if (typeof src.due_on === 'string' && src.due_on !== '') out.dueOn = src.due_on
  else out.dueOn = null
  return out
}

function normalizeComments(raw) {
  let nodes = null
  if (raw && raw.comments && Array.isArray(raw.comments.nodes)) nodes = raw.comments.nodes
  else if (Array.isArray(raw && raw.comments)) nodes = raw.comments
  else return [] // 恒实现 → EMPTY
  const out = []
  for (const n of nodes) {
    if (!n || typeof n !== 'object') continue
    const body = typeof n.body === 'string' ? n.body : ''
    const author = normalizeActor(n.author || n.user) || { login: '' }
    const association = typeof n.authorAssociation === 'string' ? n.authorAssociation : (typeof n.author_association === 'string' ? n.author_association : '')
    const c = {
      author,
      authorAssociation: association,
      body,
      createdAt: typeof n.createdAt === 'string' ? n.createdAt : (typeof n.created_at === 'string' ? n.created_at : ''),
      updatedAt: typeof n.updatedAt === 'string' ? n.updatedAt : (typeof n.updated_at === 'string' ? n.updated_at : ''),
    }
    if (typeof n.id === 'string' || typeof n.id === 'number') c.id = String(n.id)
    if (typeof n.editedAt === 'string' || n.editedAt === null) c.editedAt = n.editedAt
    else if (typeof n.lastEditedAt === 'string' || n.lastEditedAt === null) c.editedAt = n.lastEditedAt
    else if (typeof n.edited_at === 'string' || n.edited_at === null) c.editedAt = n.edited_at
    else if (typeof n.last_edited_at === 'string' || n.last_edited_at === null) c.editedAt = n.last_edited_at
    out.push(c)
  }
  return out
}

function normalizeBlockedBy(raw) {
  let nodes = null
  if (raw && raw.blockedBy && Array.isArray(raw.blockedBy.nodes)) nodes = raw.blockedBy.nodes
  else if (raw && raw.blocked_by && Array.isArray(raw.blocked_by)) nodes = raw.blocked_by
  else if (Array.isArray(raw && raw.blockedBy)) nodes = raw.blockedBy
  else return [] // 恒实现 → EMPTY
  const out = []
  for (const n of nodes) {
    if (!n || typeof n !== 'object') continue
    const k = n.number != null ? String(n.number) : (typeof n.key === 'string' ? n.key : '')
    if (!k) continue
    const title = typeof n.title === 'string' ? n.title : ''
    const stateRaw = n.state != null ? String(n.state).toLowerCase() : 'open'
    const state = stateRaw === 'closed' ? STATE.CLOSED : STATE.OPEN
    const ref = { key: k, title, state }
    // type 可选，若来源有 wayfinder:map label 可推断
    if (n.type === 'map' || n.type === 'issue') ref.type = n.type
    out.push(ref)
  }
  return out
}

// 拉取请求三字段归一（#504 落 #294 形状 A：复用工单形状加三个可选字段，不新增实体）。
// 双路输入：GraphQL pullRequest 节点（mergedAt/reviews.nodes）与 REST pull 对象
// （merged_at/pull_request 标记/reviews 数组）都认；来源没有内容给空值（null/[]），
// GitHub 有该能力所以逐票必带 isPullRequest（true/false），坏值按空值收敛，不断言缺失。
// 取舍（与 queries.js 同口径）：列表走 REST 时评审恒为空数组（列表不拉 /reviews，见 pulls.js），
// 列表走 GraphQL 时评审与评论各给 20 条（工单评论 50 条是历史配额，拉取请求取 20 条省配额），
// #506 前端房只做展示不依赖明细，点开单票才有真值。
// 缺边（与 queries.js 同口径）：拉取请求类型原生没有 parent 与 blockedBy 边（2026-09-06 真仓探针已确认），
// 所以查询侧首版不取这两条边；归一侧仍走同一函数（deriveParentKey 给 null，normalizeBlockedBy 给空数组），
// milestone 在拉取请求类型可用，查询侧已补取，缺内容时归一给省略，与工单一致。
function normalizeReview(n) {
  if (!n || typeof n !== 'object') return null
  if (typeof n.state !== 'string' || n.state === '') return null
  const out = { state: n.state }
  let login = ''
  const cand = [n.reviewer, n.author, n.user]
  for (const c of cand) {
    if (c && typeof c === 'object' && typeof c.login === 'string' && c.login.trim() !== '') { login = c.login; break }
  }
  if (login) out.reviewer = { login }
  const when = typeof n.submittedAt === 'string' ? n.submittedAt : (typeof n.submitted_at === 'string' ? n.submitted_at : '')
  if (when) out.submittedAt = when
  return out
}

function normalizeReviews(raw) {
  let nodes = null
  if (raw && raw.reviews && Array.isArray(raw.reviews.nodes)) nodes = raw.reviews.nodes
  else if (raw && Array.isArray(raw.reviews)) nodes = raw.reviews
  else return [] // 无来源 → EMPTY（GitHub 恒可实现；REST 列表页无评审明细恒给 []，单票页 enrichSinglePR 才补真值，#506 展示不依赖条数）
  const out = []
  for (const n of nodes) {
    const r = normalizeReview(n)
    if (r) out.push(r)
  }
  return out
}

function deriveIsPullRequest(raw) {
  if (!raw || typeof raw !== 'object') return false
  if (typeof raw.isPullRequest === 'boolean') return raw.isPullRequest // 已归一重入
  if (raw.pull_request != null) return true // REST issue 列表里的拉取请求标记
  if (typeof raw.__typename === 'string' && raw.__typename.toLowerCase() === 'pullrequest') return true
  if ('mergedAt' in raw || 'merged_at' in raw) return true // 拉取请求形状才有合并时间键
  if (raw.reviews != null) return true // 评审键只出现在拉取请求形状
  return false
}

function deriveMergedAt(raw) {
  if (!raw || typeof raw !== 'object') return null
  if (typeof raw.mergedAt === 'string') return raw.mergedAt
  if (typeof raw.merged_at === 'string') return raw.merged_at
  const pr = raw.pull_request
  if (pr && typeof pr === 'object' && typeof pr.merged_at === 'string') return pr.merged_at
  return null // 没合并或不是拉取请求 → null（EMPTY）；无能力后端才省略，本房恒给
}

/**
 * GitHub 原始数据里的状态 → 契约状态（只有打开 / 已关闭两种，见 shared/tracker/shape.js）。
 *
 * 为什么要它（#599）：GitHub 的拉取请求有三种状态（OPEN / CLOSED / MERGED），契约只有两种，
 * 所以要有一处把「已合并」收成「已关闭」，且只有这一处：
 *   一、GraphQL 的拉取请求自己写 state=MERGED；
 *   二、REST 兜底路上，/issues 与 /pulls 对已合并的拉取请求都给 state=closed（2026-09-11 真仓核过），
 *       所以两条路本来就同口径。
 * 契约保持两态，界面另按合并时间把这类条目显示成「已合并」（判据在 client 的 views/shared/stateKind.js）。
 * 宿主单票详情那条路（src/host/issueDetail.js）也调它，保证两处状态口径一致。
 */
export function pullStateOf(raw) {
  const s = raw && raw.state != null ? String(raw.state).toLowerCase() : ''
  return (s === 'closed' || s === 'merged') ? STATE.CLOSED : STATE.OPEN
}

/**
 * @param {Object} raw GitHub issue 原始对象（GraphQL issue 或 REST issue，或测试桩）
 * @returns {import('../../../../shared/tracker/shape.js').Issue}
 */
export function normalizeIssue(raw) {
  const key = deriveKey(raw)
  const type = deriveType(raw)
  // 状态：交给 pullStateOf 一处判定（已合并归到已关闭）；合并时间原样留在 mergedAt，界面据此显示「已合并」
  const state = pullStateOf(raw)
  const mergedAt = deriveMergedAt(raw)
  const labels = normalizeLabels(raw)
  const assignees = normalizeAssignees(raw)
  const comments = normalizeComments(raw)
  const blockedBy = normalizeBlockedBy(raw)
  const parentKey = deriveParentKey(raw)

  // 基础核心字段（永远存在）
  // effortId：GitHub 一个仓库只有一个隐含 effort，核心字段填 ''（EMPTY，不是 MISSING）
  const issue = {
    key,
    effortId: '',
    type,
    title: raw && typeof raw.title === 'string' ? raw.title : '',
    state,
    body: raw && typeof raw.body === 'string' ? raw.body : '',
    url: raw && typeof raw.html_url === 'string' && raw.html_url ? raw.html_url : (raw && typeof raw.url === 'string' ? raw.url : ''),
    createdAt: raw && typeof raw.createdAt === 'string' ? raw.createdAt : (typeof raw.created_at === 'string' ? raw.created_at : ''),
    updatedAt: raw && typeof raw.updatedAt === 'string' ? raw.updatedAt : (typeof raw.updated_at === 'string' ? raw.updated_at : ''),
    closedAt: raw && (typeof raw.closedAt === 'string' || raw.closedAt === null) ? raw.closedAt : (raw && (typeof raw.closed_at === 'string' || raw.closed_at === null) ? raw.closed_at : null),
    parentKey,
    labels,
    assignees,
    comments,
    blockedBy,
    // reason：GitHub 支持 closedReason，open 也输出 ''(EMPTY)
    reason: raw && typeof raw.reason === 'string' ? raw.reason : (raw && typeof raw.stateReason === 'string' ? raw.stateReason : ''),
  }

  // 能力字段：author（有则给对象，无则 MISSING → 省略）
  const authorRaw = raw && (raw.author || raw.user)
  const author = normalizeActor(authorRaw)
  if (author) issue.author = author

  // milestone：有则给对象，无则 MISSING（省略）
  const milestone = normalizeMilestone(raw)
  if (milestone) issue.milestone = milestone

  // customFields：GitHub 无结构化字段 → 始终 MISSING（省略）
  // 不产出 customFields

  // 拉取请求三字段：本房恒有能力，逐票必带（#505 交接）；缺内容给空值，不省略
  issue.isPullRequest = deriveIsPullRequest(raw)
  issue.mergedAt = mergedAt
  issue.reviews = normalizeReviews(raw)

  return issue
}

export default normalizeIssue
