// src/host/platformChannel.js —— 平台与探测通道（H1 #445 从 host/index.js 259–491 搬出，纯结构、行为零变化）
// 以后谁改它：改平台抽象、后端注册表或探测级联的人。预估约 280 行，超 350 打回。
// 接线：由 index.js 动态 import 动态加载；STATUS_CACHE_MS 随本文件搬入（无外部引用）；getMattSkillProbeNames/probeSkill 显式注入；共享层只引用 src/shared（出站分档/准入/测量，#963）。本文件不引用其他宿主新文件。
// #968 技能按需多一个显式注入 getChainSkillNames（链条目录里要的三项技能名，查链时只问这三项）。
import { timeoutForGhArgs, isWriteGhArgs } from '../shared/tracker/outbound-tiers.js'
import { getGhLane } from '../shared/tracker/outbound-admission.js'
// #968 平时问三项、重查问全量的分流判据（纯函数，门禁直测它）：
//   范围是“链”就只问链条要的三项，其余（全量、未知）都问全量——未知时宁可多问，不漏判。
export function selectSkillProbeNames(allNames, chainNames, scope) {
  try {
    if (String(scope || '') === 'chain' && Array.isArray(chainNames) && chainNames.length) return chainNames.slice()
  } catch {}
  try { return (allNames || []).slice() } catch { return [] }
}

export function createPlatformChannel(deps) {
  const { ctx, subprocess, timer, fs, DEFAULT_CWD, TIMEOUT_MS, getMattSkillProbeNames, getChainSkillNames, probeSkill, logCtx, gate, getGate, ghResolver, identityEnvFor } = deps
  // #494 O1：旧文本通道退役——backend.diagnostic 不再产生（残留 ctx.log.* 自动静默）。房内埋点只走 logEvent/isEnabled。
  // #927：闸可能晚一步就位（刷新接线要到插件起步才建好），所以每次报账现问一次（一次性快照会让先建好的那一路永远拿不到闸）。
  function gateOf() {
    let g = null
    try { g = (typeof getGate === 'function') ? getGate() : gate } catch (e) { g = null }
    return (g && typeof g.noteOutbound === 'function') ? g : null
  }
  const backendLogCtx = (logCtx && typeof logCtx.fire === 'function') ? logCtx : null
  function backendLogEvent(level, event, fields) { try { if (backendLogCtx) backendLogCtx.fire(level, event, fields) } catch (e) {} }
  function backendLogEnabled(level) { try { return backendLogCtx ? backendLogCtx.isEnabled(level) : (level === 'error' || level === 'warn') } catch (e) { return level === 'error' || level === 'warn' } }
  const backendCtxForRooms = { logEvent: backendLogEvent, isEnabled: backendLogEnabled }
  // #606 房外埋点 helper：工作区只记短指纹，不记原始路径。
  function hash8(s) { try { const t = String(s || ''); let h = 5381; for (let i = 0; i < t.length; i++) h = (((h << 5) + h + t.charCodeAt(i)) >>> 0); return ('0000000' + h.toString(16)).slice(-8) } catch { return '00000000' } }
  // #606 命令名只留程序名：调用方通常给的是 'gh' / 'git' 这种裸名字，但若给了带目录的完整路径，
  //   这里也把目录部分去掉，保证日志里永远不会出现一条文件系统路径。
  function progName(cmd) { try { return String(cmd || '').split(/[\\/]/).pop() || '' } catch { return '' } }
  const STATUS_CACHE_MS = 30000  // workspaceStore 探测级联 TTL（#344 沿革 · #284 保留；原 index.js 234 行）
    // ============ Tracker Registry（#155 · 后端选择 UI）============
    let _trackerRegistry = null, _trackerRegistryInit = null
    async function getTrackerRegistry() {
      if (_trackerRegistryInit) return _trackerRegistryInit   // 已建好或正在建：直接复用（同一实例只建一次）
      _trackerRegistryInit = (async () => {
        try {
          const injected = ctx.get('trackerRegistry')
          if (injected && typeof injected.select === 'function') { _trackerRegistry = injected; return _trackerRegistry }
        } catch {}
        try {
          const regMod = await import('./tracker/registryCore.js') // V1 #461：registry.js 已拆为三块，装配入口为 registryCore.js
          const createRegistry = regMod.createRegistry || regMod.default
          const reg = createRegistry(backendCtxForRooms, { matchesTimeout: 3000 })
          // 注册内置后端（github/markdown/gitlab），失败忽略（保持可用）
          try {
            const ghMod = await import('./tracker/backends/github/index.js')
            const m = ghMod.githubModule || ghMod.defaultModule || ghMod.default
            if (m && m.id) try { reg.register(m) } catch {}
          } catch {}
          try {
            const mdMod = await import('./tracker/backends/markdown/index.js')
            // #230（D10）修复 2026-08-28：必须注册【完整模块】——markdownModule 携带 setupPrompt 键表（locale 键名），
            //   wf.registry 原样转发到 st.backendModules，setupRunPrompt 按它取 markdown 模板文案（"本地 Markdown 模板…"）。
            //   此前 host 重新拼装只保留 id/label/presentation/create/matches，setupPrompt 丢失 → 弹窗选 markdown 后
            //   注入的 setup 提示词落入缺省键组（GitHub 模板，谎称"已按默认 GitHub 初始化"），导致错误地生成 GitHub 主锚。
            const fullMdModule = mdMod.markdownModule || null
            let mdModule = fullMdModule
            if (!mdModule) {
              const mkCreate = mdMod.createMarkdownBackend || mdMod.createBackend || mdMod.default
              const mkMatches = mdMod.matches
              const mdPresentation = mdMod.markdownModule?.presentation || mdMod.presentation
              mdModule = mkCreate ? { id: 'markdown', label: 'Markdown', presentation: mdPresentation || { color: '#1a7f37' }, create: mkCreate, matches: mkMatches || (async()=>false) } : null
            }
            if (mdModule) try { reg.register(mdModule) } catch {}
          } catch {}
          try {
            const glMod = await import('./tracker/backends/gitlab/index.js')
            const m2 = glMod.gitlabBackend || glMod.default
            if (m2 && m2.id) try { reg.register(m2) } catch {}
          } catch {}
          _trackerRegistry = reg
          try { ctx.set && ctx.set('trackerRegistry', reg) } catch {}
          return reg
        } catch (e) {
          // 回落：空 registry（仅 explicit 能力）
          try {
            const regMod2 = await import('./tracker/registryCore.js') // V1 #461：同上（回落分支）
            const cr = regMod2.createRegistry || regMod2.default
            _trackerRegistry = cr(backendCtxForRooms, { matchesTimeout: 3000 })
            return _trackerRegistry
          } catch { return null }
        }
      })()
      _trackerRegistry = await _trackerRegistryInit
      return _trackerRegistry
    }
    try { getTrackerRegistry().catch(()=>{}) } catch {}   // 触发预热（不阻塞主流程）
    // ===== 平台抽象（#171 惰性单例）=====  第一性原理：平台单点 + 零手拼 + 双闸不变量；经 ctx.get('platform')
    // 或内联 fallback（零 import 语法，避 D7 dev host vm.Script 阻塞）
    let _platform = null, _platformInit = null, lastPlatformOk = null
    async function getPlatform() {
      const platT0 = Date.now()
      if (_platform) return _platform
      if (_platformInit) return _platformInit
      _platformInit = (async () => {
        const injected = ctx.get('platform')
        if (injected && typeof injected.getHome === 'function' && injected.path) {
          // 2026-10-12 gh 解析点归一：注入的平台对象也要认合并宿主的 gh 解析器，否则"有没有 ctx.platform
          //   服务"会决定 Deck 走哪套 gh 解析（症状是换个宿主就时好时坏）。只包 gh 一个名字，其余逐字透传。
          if (typeof ghResolver === 'function' && typeof injected.resolveExecutable === 'function') {
            try {
              return Object.freeze(Object.assign({}, injected, { resolveExecutable: async function (name) {
                if (name !== 'gh') return injected.resolveExecutable.call(injected, name)
                try { const p = await ghResolver(); return p || null } catch (eGh) { return null }
              } }))
            } catch (eWrap) {}
          }
          return injected
        }
        try {
          const platMod = await import('./platform/index.js')
          const createPlatform = platMod.createPlatform || platMod.default
          // 2026-10-12 gh 解析点归一：gh 解析器随 opts 进平台层（见 platform/index.js 的 injectedGh）；没注入时行为不变。
          if (typeof createPlatform === 'function') return createPlatform(ctx, ghResolver ? { ghResolver: ghResolver } : undefined)
        } catch {}
        let nodePath = null
        let nodeOs = null
        try { const m = await import('node:path'); nodePath = m.default || m } catch {}
        try { const m2 = await import('node:os'); nodeOs = m2.default || m2 } catch {}
        if (!nodePath || !nodeOs) {
          const sepWin = String.fromCharCode(92)
          nodePath = { posix: { join: (...a) => a.join('/').replace(/\/\//g,'/'), sep: '/', dirname: (p)=>p.slice(0,p.lastIndexOf('/')), basename: (p)=>p.split('/').pop(), resolve: (...a)=>a.join('/'), normalize: (p)=>p, isAbsolute: (p)=>p.startsWith('/'), relative: (a,b)=>b }, win32: { join: (...a) => a.join(sepWin).replace(/\//g,sepWin), sep: sepWin, dirname: (p)=>p.slice(0,p.lastIndexOf(sepWin)), basename: (p)=>p.split(sepWin).pop(), resolve: (...a)=>a.join(sepWin), normalize: (p)=>p, isAbsolute: (p)=>/^[A-Za-z]:/.test(p), relative: (a,b)=>b } }
          nodeOs = { homedir: () => (typeof process !== 'undefined' && process.env && (process.env.USERPROFILE || process.env.HOME)) || '', platform: () => { try { return (typeof process !== 'undefined' && process['platform']) || 'win32' } catch { return 'win32' } } }
        }
        const osName = (nodeOs.platform ? nodeOs.platform() : 'win32')
        const pathImpl = osName === 'win32' ? nodePath.win32 : nodePath.posix
        const envSrc = (typeof process !== 'undefined' && process.env) ? process.env : {}
        const homedirFn = () => { try { return nodeOs.homedir() } catch { return '' } }
        const WIN32_GUARD_RE = /^[A-Za-z]:/
        let cachedHome
        const getHomeInner = async () => {
          if (cachedHome !== undefined) return cachedHome
          let primary = ''
          try { const v = homedirFn(); primary = v == null ? '' : String(v) } catch { primary = '' }
          if (osName === 'win32') {
            if (primary && WIN32_GUARD_RE.test(primary)) { cachedHome = primary; return cachedHome }
            const up = envSrc.USERPROFILE
            if (up) { cachedHome = up; return cachedHome }
            const combined = (envSrc.HOMEDRIVE || '') + (envSrc.HOMEPATH || '')
            if (combined) { cachedHome = combined; return cachedHome }
            cachedHome = null; return cachedHome
          } else {
            try { const v = homedirFn(); cachedHome = v || null; return cachedHome } catch { cachedHome = null; return cachedHome }
          }
        }
        const pathObj = Object.freeze({
          join: pathImpl.join.bind(pathImpl),
          sep: pathImpl.sep,
          dirname: pathImpl.dirname.bind(pathImpl),
          basename: pathImpl.basename.bind(pathImpl),
          resolve: pathImpl.resolve.bind(pathImpl),
          normalize: pathImpl.normalize.bind(pathImpl),
          isAbsolute: pathImpl.isAbsolute.bind(pathImpl),
          relative: pathImpl.relative.bind(pathImpl),
          async joinHome(...segs) { const h = await getHomeInner(); return pathImpl.join(h, ...segs) },
        })
        async function resolveExec(name) {
          const mapped = osName === 'win32' && name === 'cmd' ? 'cmd.exe' : name
          const subprocessSvc = ctx.get('subprocess')
          try { return await subprocessSvc.resolveExecutable(mapped) } catch (e) {
            if (name === 'gh') {
              const fb = envSrc.DSH_GH_PATH || ''
              if (!fb) throw e
              const fss = ctx.get('fs')
              if (!fss || typeof fss.lstat !== 'function') throw e
              try { const info = await fss.lstat(fb); if (info) return fb } catch {}
            }
            throw e
          }
        }
        const resolveExecutable = async (name) => { try { return await resolveExec(name) } catch { return null } }
        const fss = ctx.get('fs')
        const envView = Object.freeze({ get(k){ return envSrc[k] }, has(k){ return k in envSrc } })
        return Object.freeze({ os: osName, getHome: getHomeInner, path: pathObj, resolveExecutable, fs: fss, env: envView })
      })()
      _platform = await _platformInit
      try { const okNow = !!_platform; if (logCtx && logCtx.isEnabled('debug') && okNow !== lastPlatformOk) { lastPlatformOk = okNow; logCtx.fire('debug', 'platform.resolve', function () { return { name: 'platform', ok: okNow, latencyMs: Date.now() - platT0 } }) } } catch (eL) {}
      return _platform
    }
    // ============ 探测级联 · workspaceStore + detectionService（#152 · #150 Q1-Q7）============
    // 四层严格 + 轻量化二联骨架 + per-workspace 内存 Map<handleKey→Selection> 不落盘 + pending 不缓存 + wf.bind 薄兼容
    let _workspaceStore = null
    let _detectionService = null
    async function getWorkspaceStore() {
      if (_workspaceStore) return _workspaceStore
      try {
        const mod = await import('./tracker/detection/workspaceStore.js')
        const create = mod.createWorkspaceStore || mod.default
        _workspaceStore = create({ ttl: STATUS_CACHE_MS, logCtx: logCtx })
        // registry stale 清理（#150 Q3 unregister stale → emit bind）
        try {
          const reg = await getTrackerRegistry()
          if (reg && typeof reg.on === 'function') reg.on('bind', (evt) => { if (evt && evt.stale) { try { _workspaceStore.onRegistryBindStale(evt.handle) } catch {} } })
        } catch {}
      } catch { _workspaceStore = { get: () => null, set: () => {}, has: () => false, clear: () => {}, invalidate: () => {}, keys: () => [], onRegistryBindStale: () => {} } }
      return _workspaceStore
    }
    // #幽灵修复：BackendContext.exec（contract.js §BackendContext）——preflight 经 ghClient/glab 执行 gh/glab。
    // 契约形状 {stdout,stderr,code}；exit code≠0 不抛（调用方判）；超时 terminate；opts.timeout/signal 透传。
    // #606 补测点：这条路此前一条日志都不留（唯一记录点在 github 房，而各操作上下文都没带记录器），于是
    //   面板主取数路、探测预检、登录用户与写操作起了多少外部命令全都看不见。这里按需补 exec.run：一次调用
    //   落一行，只记命令名 / 工作区短指纹 / 耗时 / 退出码 / 发起链名，不记完整参数、令牌与原始路径。
    // 第四个参数 via = 「这条命令由哪条链起的」：造操作上下文的调用方传链名，日志只记这个固定名字。
    async function detectionExec(cmd, args, opts, via) {
      const argv = [String(cmd)].concat(args || [])
      const c = (opts && opts.cwd) || ''
      // 起始时刻只在开关打开时才取：关着时这一行读一个布尔就结束，连时钟都不读，后面那行自然也不落。
      const execT0 = (logCtx && logCtx.isEnabled('debug')) ? Date.now() : 0
      // #963 出站同一口径：gh / glab 是真实出站（git 是本地命令，不进准入）。gh 按读写探活分档，glab 沿用旧默认。
      const cmdBase = String(cmd || '').split(/[\\/]/).pop() || ''
      const deIsGh = /^gh(\.exe)?$/i.test(cmdBase)
      const deIsGlab = /^glab(\.exe)?$/i.test(cmdBase)
      const deIsOutbound = deIsGh || deIsGlab
      const deBucket = (deIsGh && isWriteGhArgs(args)) ? 'write' : 'read'
      let deRelease = null
      if (deIsOutbound) {
        try { deRelease = await getGhLane().acquire({ bucket: deBucket, signal: (opts && opts.signal) || undefined }) }
        catch (eDeQ) {
          return { stdout: '', stderr: 'cancelled while queued for gh admission', code: -1 }
        }
      }
      // #723（T19）：这一笔真实出站先报给闸（I1）。本通道是操作上下文的 exec 出口（tracker 三个房间与快照
      // 都走它），gh / glab / git 都是"起了一个进程"，一起报才能保证账上条数 = 真起的命令数。#965：这一块
      // 在拿名额之后 —— 排队等待不算这一笔，取消排队的不进账。
      try {
        const g = gateOf()
        if (g) {
          // #927：GraphQL 要看第二段（`gh api graphql …` 第一段是 api）；只看第一段会把面板与工具那一路的
          // GraphQL 当 REST 记（点数记成 0）。口径与 repoKeys.js 对齐。
          const a0 = String((args && args[0]) || '')
          const a1 = String((args && args[1]) || '')
          const isGraphql = a0.indexOf('graphql') >= 0 || (a0 === 'api' && a1.indexOf('graphql') >= 0)
          g.noteOutbound({ requests: 1, points: isGraphql ? 1 : 0 })
        }
      } catch (eR) { /* 报账失败不许影响已经起来的这一条命令 */ }
      let handle
      try {
        handle = subprocess.spawn({
          argv: argv,
          cwd: c || DEFAULT_CWD,
          stdio: { stdin: 'ignore', stdout: { maxBytes: 4 * 1024 * 1024 }, stderr: { maxBytes: 256 * 1024 } },
          graceMs: 2000,
          // 隧道出口（操作上下文的 exec：ghClient 的 gh、探测预检、后端谓词都走它）：按程序名与子命令查规则表。
          // 「登录态」那格（preflight:ghAuth）也走这条路 —— 它从此**戴着工牌**跑，含义是「消费面给的身份能不能用」
          // （Q7=(b) 的裁决）；「宿主 gh 自己登没登录」归体检工具，不在这条链上。
          env: await identityEnvFor(cmdBase, args),
        })
      } catch (e) {
        if (deIsOutbound) { try { if (deRelease) deRelease() } catch {} }
        throw new Error('exec spawn failed: ' + String((e && e.message) || e))
      }
      // #969：gh 默认超时按读写探活分档（调用方显式 timeout 优先）；glab 与 git 沿用旧默认。
      const timeoutMs = (opts && opts.timeout != null) ? opts.timeout : (deIsGh ? timeoutForGhArgs(args) : TIMEOUT_MS)
      // 调用方取消信号（#895）：中止即杀进程，不留没人等的写入；没有信号时与原来一字不差。
      let onAbortSig = null
      const abortP = new Promise(function (resolve) {
        const sig = opts && opts.signal
        if (!sig || typeof sig.addEventListener !== 'function') return
        if (sig.aborted === true) { try { handle.terminate() } catch (e2) {} resolve({ exitCode: -1, signal: 'aborted' }); return }
        onAbortSig = function () { try { handle.terminate() } catch (e2) {} resolve({ exitCode: -1, signal: 'aborted' }) }
        try { sig.addEventListener('abort', onAbortSig, { once: true }) } catch (e) {}
      })
      let outcome
      try {
        outcome = await Promise.race([
          handle.done,
          timer.timeout(timeoutMs).then(function () { try { handle.terminate() } catch (e2) {} return { exitCode: -1, signal: 'timeout' } }),
          abortP,
        ])
      } catch (e) {
        outcome = { exitCode: -1, signal: 'error' }
      }
      try { if (opts && opts.signal && onAbortSig && typeof opts.signal.removeEventListener === 'function') opts.signal.removeEventListener('abort', onAbortSig) } catch (e) {}
      const out = (handle.collected && handle.collected.stdout) ? handle.collected.stdout.readFrom(0) : { text: '' }
      const err = (handle.collected && handle.collected.stderr) ? handle.collected.stderr.readFrom(0) : { text: '' }
      try { if (execT0 && logCtx.isEnabled('debug')) logCtx.fire('debug', 'exec.run', { argv0: progName(argv[0]), cwdHash: hash8(c || DEFAULT_CWD), latencyMs: Date.now() - execT0, exitCode: (outcome && typeof outcome.exitCode === 'number') ? outcome.exitCode : -1, via: String(via || 'unspecified') }) } catch (eL) {}
      if (deIsOutbound) { try { if (deRelease) deRelease() } catch {} }
      return { stdout: out.text || '', stderr: err.text || '', code: outcome.exitCode }
    }
    async function getDetectionService() {
      if (_detectionService) return _detectionService
      const registry = await getTrackerRegistry()
      const platform = await getPlatform()
      const ws = await getWorkspaceStore()
      const fsSvc = ctx.get('fs')
      try {
        const mod = await import('./tracker/detection/detectionService.js')
        const create = mod.createDetectionService || mod.default
        const decideBackend = (((await getDecisionFn().catch(function () { return {} })) || {}).decideBackend) || null
        // skillProbe 内联（复用 probeSkill 双源逻辑；全量名单 = shared/matt-skills.js 单源，二十多项）
        // #280/#fix-banner：旧版硬编码 10 名，遗漏 grill-with-docs / wizard / grill-me / to-questionnaire / wait-what / writing-for-agents 等导致横幅永远报警
        // #968 技能按需：平时（链求值、普通探测）只问链条目录要的三项，人亲手点重查才问全量。
        // 范围由探测编排层按重查标记带来（见 detectionService），这里只按范围选名单；重查标记同时透给单项探测，
        // 让它绕过短时记住（刚装好的技能重查立即可见），平时则命中记住、不重复问。
        const skillProbe = async ({ cwd, skillScope, force }) => {
          // probeNames：全量即 shared/matt-skills.js:MATT_SKILL_PROBE_NAMES（单源）；链上三项即链目录真源；改探测集只改各真源一处即可
          const probeNames = selectSkillProbeNames(await getMattSkillProbeNames(), (typeof getChainSkillNames === 'function') ? await getChainSkillNames() : null, skillScope)
          const probes = {}
          let missing = []
          let hasPending = false
          let pendingError = null
          for (let i = 0; i < probeNames.length; i++) {
            const name = probeNames[i]
            try {
              const r = await probeSkill(name, 'zh', cwd, { force: !!force })
              probes[name] = r
              if (r.level === 'pending') { hasPending = true; if (!pendingError && r.error) pendingError = r.error }
              else if (r.level !== 'ok') missing.push(name)
            } catch (e) { const err = String((e && e.message) || e); probes[name] = { ok: false, level: 'bad', detail: err, hint: 'prompt:installSkills', error: err }; missing.push(name) }
          }
          const ok = missing.length === 0 && !hasPending
          return { ok, missing, probes, hasPending, pendingError, pending: hasPending }
        }
        // #683（F1）：判定链要读宿主侧那份记忆（用户选的后端按工作区记着），实例由 index.js 单点持有 ——
        //   那条读-改-写队列必须全进程只有一条，不能在这里另建一份。
        _detectionService = create({ registry, getPlatform, getFs: () => fsSvc, getTimers: () => ({ setTimeout: (fn, ms) => timer.timeout(fn, ms), clearTimeout: (id) => { try { clearTimeout(id) } catch {} } }), workspaceStore: ws, skillProbe, resolveRepoHandle: async (h) => ({ cwd: h.cwd || '', refId: h.refId || '' }), exec: detectionExec, getChoiceStore: getChoiceStore, logCtx: logCtx, decideBackend: decideBackend })
      } catch (e) {
        // 兜底：最小二联（explicit → matches）不含 preflight/skill
        _detectionService = {
          detect: async (handle, opts) => {
            const plat = await getPlatform()
            const expMod = await import('./tracker/detection/explicitDetector.js')
            const expFn = expMod.detectExplicit || expMod.default
            const exp = await expFn(handle, { platform: plat, cwd: handle.cwd, fs: fsSvc }, registry)
            let sel = exp.selection
            if (!sel) { const ctx2 = { cwd: handle.cwd, platform: plat, fs: fsSvc, caller: 'detect', timers: { setTimeout: (fn, ms) => timer.timeout(fn, ms), clearTimeout: (id) => { try { clearTimeout(id) } catch {} } } }; sel = await registry.select(handle, ctx2) }
            return { handle, selection: sel, repoHandle: { cwd: handle.cwd || '', refId: (sel && sel.ref && sel.ref.refId) || '' }, explicit: { raw: exp.raw, parsed: exp.parsed }, preflight: null, skillProbes: null, at: Date.now() }
          }
        }
      }
      return _detectionService
    }
  function clearWorkspaceStore() { try { if (_workspaceStore && typeof _workspaceStore.clear === 'function') _workspaceStore.clear() } catch {} }
  // #683（F1）：宿主侧那份记忆（H）的单例就在这里建 —— 读它的是两处（绑定写入、判定读取），而它内部
  //   那条读-改-写队列必须全进程只有一条（两个窗口同时写才排得成队）。规则与字段见 src/host/choiceStore.js 文件头。
  let _choiceStoreP = null
  function getChoiceStore() {
    if (!_choiceStoreP) _choiceStoreP = (async function () {
      const mod = await import('./choiceStore.js')
      return mod.createChoiceStoreForHost({ getHome: async function () { const p = await getPlatform(); return p.getHome() }, getTrackerRegistry: function () { return getTrackerRegistry.apply(null, arguments) }, logCtx: logCtx })
    })().catch(function () { return null })
    return _choiceStoreP
  }
  let _decideBackendP = null // #1003 单出口装配点（跨层引用基线记名；映射挂函数上整包递，下游零新增边）
  const getDecisionFn = () => (_decideBackendP || (_decideBackendP = import('./tracker/detection/backendDecision.js').then(
    function (m) { const fn = m.decideBackend || (m.default && m.default.decideBackend) || null; if (fn) { try { fn.selectionFromOutlet = m.selectionFromOutlet || (m.default && m.default.selectionFromOutlet) || null } catch (eAttach) {} } return { decideBackend: fn } },
    function () { return { decideBackend: null } })))
  return { getTrackerRegistry, getPlatform, getWorkspaceStore, detectionExec, getDetectionService, getChoiceStore, clearWorkspaceStore, getDecisionFn }
}
