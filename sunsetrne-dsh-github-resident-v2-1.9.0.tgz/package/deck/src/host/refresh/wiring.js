// src/host/refresh/wiring.js —— 刷新机制的宿主接线（#723 T19）
//
// 这个文件只做一件事：把刷新机制那几件已经落库的东西**在宿主里真的装起来**，并交回去。它不判断任何业务：
// 闸与账本是 gate.js 与 ledger.js 的产物，写事件订阅是 writeEvents.js 的产物，会话↔票处理链是 sessionTickets.js
// 的产物，界面读数由 sessionChainReadout.js 拼 —— 这里只把它们之间的依赖接上。单开一个文件而不写进
// src/host/index.js 的原因：那个文件贴着 350 行上限（verify-file-granularity 的零增长基线），#723 起不许再加行。
//
// 装起来的四件（票面 3a/3b/3c/3e）：
//   a 闸与账本：createLedger + createGate，send 真的被调用（后面几件取数都经它）；
//   b 写事件订阅：createWriteEvents(...).attach(ctx)，活跃集合变化时 allowRoot / 切走时 forgetRoot；
//   c 视野模型：wf.focus 那一份「当前在看谁」就是这里的唯一来源（syncAttention 读它）；
//   e 会话↔票处理链：createSessionTickets() 真的建起来，并把界面读数交给快照回包。
//
// 日志：本文件不新增事件。它调到的每一个模块各自记自己那几行（闸的 refresh.decide / refresh.skipped、
// 账本的 quota.spend、写事件的 write.event、处理链的 sessionTickets.chain）。
import { createLedger } from './ledger.js'
import { createGate } from './gate.js'
import { createWriteEvents } from './writeEvents.js'
import { createSessionTickets } from './sessionTickets.js'
import { buildSessionChainReadout, SESSION_CHAIN_FIELD } from './sessionChainReadout.js'
import { createAttention, createFocusHandler } from './attention.js'
// #723（T19c）第 D 件：这批 deck_* 工具。装配口在共享层（createDeckTools 只收参数、不 import 工具文件），
// 具体工厂由 ../platform/deckToolsAssembly.js 一处读进来 —— 收在那一层是因为宿主层文件之间不许互引（同层引用门禁），
// 宿主层里再读一次那批文件就要新增 7 条同层边，本票不许。见那个文件的文件头与交付报告第 6 节。
import { createDeckToolsForHost, DECK_TOOL_FILES, withCap } from '../platform/deckToolsAssembly.js'
// deck 工具前置三处的等待上限：保读数含一次远端读数（读档 12 秒加排队），给 15 秒；
// 本机记忆与工作区文件是本地读，给 5 秒。超时都走既有的失败继续路径（保不住照旧往下走、
// 读不到按缺席跳过），成功路径一字不动——挂住的文件服务或排满的出站队列不能卡住整笔调用。
const DECK_ENSURE_TIMEOUT_MS = 15000
const DECK_EXPLICIT_TIMEOUT_MS = 5000
import { createNamingSummary, readFirstUserText } from '../platform/namingSummary.js'   // #746：命名摘要编排（单例，见下）；#746 首句直读（随单下发供免锁比对）
import { hookDeckAgentTools, makeDeckRegisterReport } from '../../shared/deck-tools/agent-register.js' // #741 注册那一步（向 agent 交这批工具）：形状、循环与报告住共享层（两边都要用），这里只递表
import { publishDeckTableOwned, noteDeckGate } from '../../shared/deck-tools/exec-cell.js' // #758 同进程共享格：行与宿主同一进程，表放进格子里行直接取，不经调用面
import { createSandboxPolicyFor } from '../platform/deckSandbox.js'
import { createDeckQuotaSync } from '../platform/deckQuotaSync.js' // #758 剩余额度读数接线：差读数先免费读一次，裁决数字不动（平台区，不新增宿主层边）
// #723（T19c）第 E 件：行级增量那半边（refresh/patch.js）同理收在 src/host/platform/refreshAssembly.js 一处。
import { createPatchForHost } from '../platform/refreshAssembly.js'
import * as budget from '../../shared/refresh/budget.js'
import * as toolCost from '../../shared/refresh/tool-cost.js'
// #724：闸那一侧的工作区钥匙（短散列）只有一份实现，住在共享层（宿主层文件之间不许互引，而链求值那侧也要用
// 同一把钥匙）。本文件把它转出来，「活跃集合、写事件白名单、这批 deck_* 工具、行级增量、检查链记账」五处同源。
import { hash8, workspaceKeyOf } from '../../shared/refresh-workspace-key.js'
import { parseWorkspaceFile, WORKSPACE_FILE_REL } from '../../shared/deck-tools/workspace-file.js'
export { workspaceKeyOf } from '../../shared/refresh-workspace-key.js'

/** 把一堆依赖包装成「取一次、以后复用」的惰性实例（模块加载失败不许把整个插件带崩）。 */
function once(fn) {
  let box = { done: false, value: null }
  return function () {
    if (!box.done) {
      box.done = true
      try { box.value = fn() } catch (e) { box.value = null }
    }
    return box.value
  }
}

/**
 * 造宿主入口那一侧**唯一的那一套**刷新机制（调用多少次都只建一次，所有使用者共用同一个实例）。
 *
 * 为什么「唯一」是硬要求而不是省事：闸的活跃集合、写事件的白名单、视野模型、处理链、界面读数这五件
 * 认的是**同一个「当前在看谁」**。宿主要是建了两套（哪怕两套代码一模一样），标活跃标在一套上、
 * 过闸走在另一套上，后台档的 background-inactive 就会把写事件那一笔恒判推迟 —— 生产里看起来谁都在
 * 工作，实际一次都发不出去，而且读数那一边永远空着。（#723 复核抓到的正是这个：入口一处、wf.focus 又一处。）
 */
export function makeRefreshLoader(deps) {
  let load = null
  return async function () {
    if (!load) load = (async function () {
      const w = createRefreshWiring(deps)
      try { w.attach() } catch (eAt) {}
      // 界面读数（e）：快照回包要挂的那个字段由它产出，形状归 refresh/sessionChainReadout.js 一处。
      const chainReadout = function () { return w.chainReadoutOf() }
      // wf.focus 的处理器（c）：用的就是这一套里的视野模型；上报之后把活跃集合同步给白名单与闸。
      const focus = (function () {
        let h = null
        return async function (args) {
          if (!h) h = createFocusHandler({ attention: w.attention, afterReport: function () { return w.syncAttention() } })
          return await h(args)
        }
      })()
      return Object.assign({}, w, { chainReadout: chainReadout, chainField: SESSION_CHAIN_FIELD, focus: focus })
    })()
    return await load
  }
}

/**
 * 装一套刷新机制。deps 由宿主入口显式传入（本文件不 import 宿主同层的模块，除本目录这几个）：
 *   ctx            宿主上下文（写事件订阅要 ctx.on）
 *   logCtx         宿主日志出口（{ fire, isEnabled }）
 *   canonicalKey   会话目录 → 工作区键的既有出口（src/host/repoKeys.js 的 canonicalKey）
 *   runGh / execProc / getRepoKey / getCacheDir / readDiskCache / writeDiskCache / getTrackerRegistry / getPlatform
 *                  宿主既有出口，交给各件跑腿用
 *   trackerRegistry 可选：后端注册表（这批 deck 工具的壳要用它选后端）
 *   gate / ledger  可选：已经造好的闸与账本（门禁与单测里注入用）；不给就现场造
 *
 * 回包：{ ledger, gate, writeEvents, sessionTickets, attention, chainReadoutOf, noteWorkspaceActive,
 *        makeFetch, attach, stats }
 */
export function createRefreshWiring(deps) {
  const d = deps || {}
  const logCtx = d.logCtx || null

  const ledger = d.ledger || createLedger({ logCtx: logCtx })
  const gate = d.gate || createGate({ ledger: ledger, logCtx: logCtx })

  // #758 剩余额度读数接线：动手前先保一次读数（差就免费读，不差不打）；闸、账本、起 gh 三件都在本文件手里，包成函数递给工具依赖，失败只影响这一次调用。
  let deckQuotaSync = null
  function quotaSyncOf() {
    if (!deckQuotaSync) {
      try {
        deckQuotaSync = createDeckQuotaSync({
          send: function (req, perform) { return gate.send(req, perform) },
          syncDue: function () { try { return ledger.syncDue() } catch (eS) { return false } },
          syncServer: function (readings) { try { return ledger.syncServer(readings) } catch (eW) { return null } }, noteRateLimited: function (bucket, seconds, workspaceKey) { try { return gate.noteRetryAfter({ bucket: bucket, seconds: seconds, workspaceKey: workspaceKey }) } catch (e) { return null } }, // #927 ①：读数里剩 0 时按服务端的重置时刻降档
          runGh: function (a, c) { if (typeof d.runGh === 'function') return d.runGh(a, c); return Promise.resolve({ ok: false, error: 'no-runGh' }) },
          logCtx: logCtx,
        })
      } catch (eC) { deckQuotaSync = null }
    }
    return deckQuotaSync
  }
  function ensureDeckReading(cwd, workspaceKey) {
    try {
      const q = quotaSyncOf()
      if (!q || typeof q.ensureReading !== 'function') return Promise.resolve({ ok: false, reason: 'missing-dep' })
      // 排队无上限的出站不能卡住整笔调用：超时按保不住走老路（调用方照旧被闸推迟）。
      return withCap(q.ensureReading(cwd, workspaceKey), DECK_ENSURE_TIMEOUT_MS).then(function (r) { return (r && r.ok === true) ? r.value : { ok: false, reason: (r && r.timedOut) ? 'sync-timeout' : 'ensure-threw' } }, function () { return Promise.resolve({ ok: false, reason: 'ensure-threw' }) })
    } catch (eE) { return Promise.resolve({ ok: false, reason: 'ensure-threw' }) }
  }

  // 写事件触发的那一次取数（b）：闸放行之后真去做的那一步；真取行级增量（refresh/patch.js 的 run）由 T18 那批接。
  async function fetchForWriteEvent(step, meta) {
    return { requests: 0, points: 0 }
  }

  // e：会话↔票处理链。喂数据的是 b 那条订阅（工具结果一到就 note 一笔），读数是下面那个读数。
  // #781：把归一出口递进去，note() 先洗根再算散列（调用方传所选目录原文时与读回侧同格）。
  const sessionTickets = d.sessionTickets || createSessionTickets({
    getCacheDir: d.getCacheDir, logCtx: logCtx, canonicalKey: d.canonicalKey,
  })

  // b：写事件订阅（门前是归我们的工作区根白名单，见 writeEvents.js 文件头）；判定过的那一笔喂给处理链（note），否则界面恒空。
  // #746：命名摘要编排单例（ctx 与 getNaming 由宿主入口经 deps 给；任一缺失则钩子静默降级）。
  let namingSummary = null
  function summaryOf() {
    if (!namingSummary && typeof d.getNaming === 'function') {
      try { namingSummary = createNamingSummary({ ctx: d.ctx, getNaming: d.getNaming, logCtx: logCtx }) } catch (e) { namingSummary = null }
    }
    return namingSummary
  }
  // #746 Knife4：直达钩子失败可观测 —— 内层永不抛错，失败只记既有 warn 事件（不新增事件），不影响建票返回。
  function onDeckWrite(info) {
    const warnHook = function (eH) {
      try { if (logCtx) logCtx.fire('warn', 'host.call.fail', { method: 'wf.namingDirect', kind: 'naming-direct', errorHash: hash8(String((eH && eH.message) || eH).slice(0, 120)) }) } catch (eL) {}
    }
    try {
      const s = summaryOf()
      if (s && typeof s.onDeckWrite === 'function') {
        const r = s.onDeckWrite(info)
        if (r && typeof r.catch === 'function') r.catch(warnHook)
      }
    } catch (e) { warnHook(e) }
    return { ok: true }
  }
  function onFirstAssistant(sid) { try { const s = summaryOf(); if (s) s.maybeSummarize(sid) } catch (e) {} }
  // 首条用户消息那一下催一次改名（底座就是在这时候写首句名）：每个会话只催一次，且只认账上有号、还没锁的会话
  // —— 账上没有就什么都不做，省掉一次会读会话日志的整轮计划单（每句都催的代价在生产日志里是几十秒级的）。
  const firstUserNudged = new Set()
  function onFirstUser(sid) {
    try {
      if (!sid || typeof d.getNaming !== 'function' || firstUserNudged.has(sid)) return
      if (firstUserNudged.size > 500) firstUserNudged.clear()
      firstUserNudged.add(sid)
      Promise.resolve(d.getNaming()).then(function (h) {
        if (!h || typeof h.getEntry !== 'function' || typeof h.handleNamingPlan !== 'function') return null
        return Promise.resolve(h.getEntry(sid)).then(function (e) { return (e && !e.locked) ? h.handleNamingPlan() : null })
      }).catch(function () {})
    } catch (e) {}
  }
  // #746：受踪判定（供写事件白名单之外的窄门：只认命名守护账上有号的会话，取数记账链不走这里）。
  function isNamingTracked(sid) {
    try {
      if (!sid || typeof d.getNaming !== 'function') return Promise.resolve(false)
      return Promise.resolve(d.getNaming()).then(function (h) {
        if (!h || typeof h.getEntry !== 'function') return false
        return Promise.resolve(h.getEntry(sid)).then(function (e) { return !!e }).catch(function () { return false })
      }).catch(function () { return false })
    } catch (e) { return Promise.resolve(false) }
  }
  const writeEvents = d.writeEvents || createWriteEvents({
    gate: gate, fetch: fetchForWriteEvent, canonicalKey: d.canonicalKey, logCtx: logCtx,
    note: function (input) { try { return sessionTickets.note(input) } catch (e) { return null } },
    backendOf: function (rootKey) { return backendOfRoot(rootKey) },
    onFirstAssistant: onFirstAssistant,
    onFirstUser: onFirstUser,
    isNamingTracked: isNamingTracked,
  })

  // c：视野模型。wf.focus 上报「我在看谁」之后，活跃集合就在这里，b 的白名单跟着它走。
  const attention = d.attention || createAttention({ canonicalKey: d.canonicalKey, logCtx: logCtx })

  /**
   * 「这个工作区现在用哪个后端」（#723 T19）：链只认 github / gitlab / markdown 三个白名单名字
   * （src/shared/refresh/chain.js 的 CHAIN_BACKENDS），空串与别的名字都会被它丢掉并说 chain.bad-backend。
   * 两条来源，都不在本文件里另写判定：
   *   ① 宿主既有的后端注册表（reg.describe）—— 用户手动选择那一档；
   *   ② 宿主既有的探测服务（getDetectionService().detect）—— 锚文件那一档（不传 hint、不强制）。
   * 两条都问不出来就如实回空串：让链丢掉并说原因（界面照实说读不到），**不编一个假名字**让它看着能记。
   */
  async function backendOfRoot(rootKey) {
    const cwd = String(rootKey || '')
    if (!cwd) return ''
    try {
      if (typeof d.getTrackerRegistry === 'function') {
        const reg = await d.getTrackerRegistry()
        if (reg && typeof reg.describe === 'function') {
          const info = reg.describe({ cwd: cwd })
          const id = String((info && info.backend) || '')
          if (id) return id
        }
      }
    } catch (e) { /* 往下问探测服务 */ }
    try {
      if (typeof d.getDetectionService === 'function') {
        const svc = await d.getDetectionService()
        if (svc && typeof svc.detect === 'function') {
          const res = await svc.detect({ cwd: cwd }, {})
          const id = String((res && res.selection && res.selection.backendId) || '')
          if (id) return id
        }
      }
    } catch (e2) { /* 问不出来就空串 */ }
    return ''
  }

  /** 界面要的那份读数（e）。挂在快照回包上，界面读不到时它会如实说 ok:false + 代号。 */
  function chainReadoutOf() {
    return buildSessionChainReadout({ tickets: sessionTickets, at: Date.now() })
  }

  // 上一次同步给写事件白名单的那些根（切走的那几个要 forgetRoot）。
  let allowed = []
  // #735：盘读回守卫（内存按进程活、盘跨进程；重启后每个根第一次被看见时读回一格，一根只读一次）。
  const restoredRoots = new Set()

  /**
   * 把「现在在看哪些工作区根」同步给写事件的白名单（b）与闸的活跃集合（c）——**同一份来源**（视野模型）。
   * 每次 wf.focus 上报之后调一次：新来的进白名单、切走的收摊，两个去处一起改。
   *
   * #723（T19）最关键的一处：闸那边如果没接活跃集合，写事件触发的那一次取数会被**恒判推迟**
   * （policy.js 的 background-inactive：后台档不在活跃集合里就一次都不发）—— 接线看起来接上了、
   * 实际一笔都发不出去。所以这两个去处必须由同一份「当前在看谁」同时喂，钥匙也必须是同一把：
   * writeEvents 过闸时带的 workspaceKey 是它自己的短散列（rootHash，见 writeEvents.js 的 fire），
   * 闸按那把钥匙认活跃集合，所以这里标活跃用的也是同一把（#724 起只有一处实现：workspaceKeyOf）。
   */
  async function syncAttention() {
    let roots = []
    try {
      const st = attention.stateOf()
      roots = (st && Array.isArray(st.active)) ? st.active.map(function (x) { return String(x.root || '') }).filter(Boolean) : []
    } catch (e) { roots = [] }
    for (const root of roots) {
      if (allowed.indexOf(root) < 0) { try { await writeEvents.allowRoot(root) } catch (eA) {} }
      try { gate.setWorkspace(workspaceKeyOf(root), { active: true }) } catch (eG) {}
      // #735：新根把盘上这一格读回来（重启丢的内存与别的进程写的格子都靠这一次；restore 永不抛错）。
      // #781：等它落定再往下走 —— 不等的话紧接着取快照会赶在读完之前，第一次看到空、第二次才有，
      // 重启后第一眼空很容易当成丢了。读失败时把标记拿掉，下次切进这个根再试一次。
      if (!restoredRoots.has(root)) {
        restoredRoots.add(root)
        try { await sessionTickets.restore({ rootKey: root }) }
        catch (eR) { try { restoredRoots.delete(root) } catch (eD) {} }
      }
    }
    for (const root of allowed) {
      if (roots.indexOf(root) < 0) {
        try { writeEvents.forgetRoot(root) } catch (eF) {}
        try { gate.setWorkspace(workspaceKeyOf(root), { active: false }) } catch (eG2) {}
      }
    }
    allowed = roots
    return roots
  }

  /** 一个工作区现在算不算活跃（闸裁决的输入之一：不在活跃集合里的后台档一次都不发）。 */
  function noteWorkspaceActive(root, active) {
    // 与 syncAttention 用同一把钥匙（workspaceKeyOf）：散列层级不同就会让活跃集合里那一格认不出来，
    // 于是这条路上的每一笔都被判「推迟」（#723 复核抓到的那个「接上了却没走通」）。
    try { return gate.setWorkspace(workspaceKeyOf(root), { active: !!active }) } catch (e) { return null }
  }

  /** b 真订阅。宿主入口在 apply 里调一次（attach 要一个 ctx）。 */
  function attach() {
    let detach = function () {}
    try { const r = writeEvents.attach(d.ctx); if (r && typeof r.detach === 'function') detach = r.detach } catch (e) {}
    return { detach: detach }
  }

  // ── D（#723 T19c）：这批 deck_* 工具在宿主里装起来 ─────────────────────────────────────────
  // 把这批工具工厂交给共享层装配口 createDeckTools，并把它要的依赖如实给全：gate（本文件造的那一个闸）、
  // registry（后端注册表，选后端走它的三级联）、budget 与 estimate/costInputFrom（额度与算账两件）、
  // handleFor（会话→注册表里绑过的真实句柄）、backendCtx（platform / fs / exec，exec 走 platformChannel
  // 的 detectionExec，也就是起进程那一层）、invalidate（写后作废那个工作区的快照缓存）、hourUsage（问账本）。
  // planStore 没有注入：批量建图的中间态因此退回进程内存，工具会在返回值里如实说 durable:false。
  // 注意（2026-09-26）：loadDefineTool 固定给 null，走原生形状直接注册——照官方工具写法，插件不 import 框架包，
  // 注册纯数据对象；从前这里动态 import 自带副本，挂载后全部工具调用报 prepare undefined。
  // 退路输出与参数形状见 shared/deck-tools/agent-register.js（deckAgentOutputSchemaRaw）。
  let deckToolsP = null; try { hookDeckAgentTools(d.ctx, deckToolsForHost, function () { return Promise.resolve(null) }, makeDeckRegisterReport(logCtx)) } catch (eH) {} // #741 注册那一步：表装好就向 agent 交这批工具，成败落既有日志（deckToolsForHost 声明提升，这里可直接用）
  async function deckToolsForHost() {
    if (!deckToolsP) {
      deckToolsP = (async function () {        const empty = { tools: {}, names: [], definitions: [], missing: [], reason: '', files: DECK_TOOL_FILES }
        let registry = null
        try { registry = d.getTrackerRegistry ? await d.getTrackerRegistry() : null } catch (eR) { registry = null }
        if (!registry || typeof registry.select !== 'function') return Object.assign({}, empty, { reason: 'no-registry' })
        let platform = null
        try { platform = d.getPlatform ? await d.getPlatform() : null } catch (eP) { platform = null }
        // 后端 ctx 一次取好、之后每笔调用复用同一份：壳按调用同步取它，所以这里不能给一个异步函数。
        const backendObj = {
          platform: platform,
          fs: (function () { try { return (d.ctx && typeof d.ctx.get === 'function') ? d.ctx.get('fs') : undefined } catch (e) { return undefined } })(),
          exec: function () {
            if (typeof d.detectionExec === 'function') { try { return d.detectionExec.apply(null, arguments) } catch (e) { return Promise.reject(e) } }
            return Promise.resolve({ ok: false, kind: 'env', error: '这个宿主实例没有把起进程的出口（detectionExec）传进来，远端后端的读写做不了' })
          },
          logEvent: function (level, event, fields) { try { if (logCtx && typeof logCtx.fire === 'function') logCtx.fire(level, event, fields) } catch (e) {} },
          isEnabled: function (level) { try { return logCtx ? logCtx.isEnabled(level) : (level === 'error' || level === 'warn') } catch (e) { return level === 'error' || level === 'warn' } },
        }
        const built = createDeckToolsForHost({
          gate: gate,
          registry: registry,
          budget: budget,
          estimate: toolCost.estimateToolCost,
          costInputFrom: toolCost.toolCostInputFrom,
          handleFor: function (s) { try { const list = (typeof registry.allBindings === 'function') ? registry.allBindings() : []; const want = String((s && s.cwd) || ''); const wash = (p) => String(p || '').replace(/\\/g, '/').replace(/\/+$/, ''); const wantW = wash(want); for (let i = 0; i < list.length; i++) { const c = (list[i] && (list[i].cwd || (list[i].handle && list[i].handle.cwd))) || ''; if (String(c) === want || wash(c) === wantW) return list[i].handle || { cwd: want } } } catch (e) {} return { cwd: (s && s.cwd) || '' } },
          // 934：会话目录洗加锚根的宿主唯一异步出口（与绑定侧同一把钥匙）；缺席时壳沿用原始目录。
          canonicalKey: (typeof d.canonicalKey === 'function') ? function (raw) { return d.canonicalKey(raw) } : undefined,
          // 947 显式后两层读口：查不到一律 null（缺席即跳过，不猜）。挂住时同样按缺席跳过。
          readChoice: function (rootCwd) { try { const p = (typeof d.getChoiceStore === 'function') ? d.getChoiceStore().then(function (cs) { return (cs && typeof cs.getWorkspace === 'function') ? cs.getWorkspace(rootCwd) : null }, function () { return null }).then(function (got) { return (got && got.found === true && got.backendId) ? { backendId: got.backendId, rev: got.rev || 0 } : null }) : Promise.resolve(null); return withCap(p, DECK_EXPLICIT_TIMEOUT_MS).then(function (r) { return (r && r.ok === true) ? r.value : null }, function () { return null }) } catch (e) { return Promise.resolve(null) } },
          readWorkspaceFileText: function (rootCwd) { try { const fsSvc = backendObj && backendObj.fs; if (!fsSvc || typeof fsSvc.resolve !== 'function' || typeof fsSvc.readText !== 'function') return Promise.resolve(null); const p = Promise.resolve(fsSvc.resolve(WORKSPACE_FILE_REL, { cwd: rootCwd })).then(function (t) { return fsSvc.readText(t) }, function () { return null }).then(function (txt) { return (typeof txt === 'string' && txt) ? txt : null }, function () { return null }); return withCap(p, DECK_EXPLICIT_TIMEOUT_MS).then(function (r) { return (r && r.ok === true) ? r.value : null }, function () { return null }) } catch (e) { return Promise.resolve(null) } },
          parseWorkspaceFile: parseWorkspaceFile,
          sandboxPolicyFor: createSandboxPolicyFor(d.ctx),
          backendCtx: function () { return backendObj },
          invalidate: function (info) { try { const root = (info && info.workspace && info.workspace.root) || (info && info.cwd); if (typeof d.setCache === 'function' && root) d.setCache({ ts: 0, snapshot: null, error: null, cwd: String(root) }) } catch (e) {} },
          onTicketCreated: onDeckWrite, chainNote: function (input) { try { return sessionTickets.note(input) } catch (e) { return null } }, // #746 建票直达命名守护；#775 主动上报写同一份链（report）
          hourUsage: function () { try { return ledger.hourOf('ai-tool') || {} } catch (e) { return {} } },
          ensureReading: function (cwd, workspaceKey) { return ensureDeckReading(cwd, workspaceKey) }, // #758 动手前保读数：差就免费读一次，不差不打；失败调用方照旧被闸推迟
          noteGate: function (info) { try { noteDeckGate(info) } catch (eN) {} }, // #758 闸口径迹：探针读走，线上卡在哪段一眼可见
          log: logCtx || null,
          // #723（T19c）：工作区键用与活跃集合同一把短散列（workspaceKeyOf）——**不许**在这里用别的归一
          // （散列层级不同、长度不同、空串，都会让闸里那一格从来不是活跃，于是每一笔都被判推迟；
          // 这一条有门禁盯着：tests/verify-deck-tools-host-wiring.js 与 verify-delta-wiring.js，
          // 另加 #724 的「同一个工作区根在闸里只许有一格」tests/verify-refresh-workspace-key.js）。
          workspaceKeyOf: workspaceKeyOf,
          now: Date.now,
        })
        return Object.assign({ reason: '', files: DECK_TOOL_FILES }, built)
      })().catch(function () { return { tools: {}, names: [], definitions: [], missing: [], reason: 'assembly-failed', files: DECK_TOOL_FILES } })
      try { publishDeckTableOwned(deckToolsP, d.ctx, 'deck table cell') } catch (eP) {} // #758 同进程共享格：发布与释放整个放进 ctx.effect 拥有的生命周期（execute 立刻执行）：ctx 还活着才发布、卸载时 release 随 effect 退格；ctx 已卸则 effect 先抛 INACTIVE_EFFECT，这里一个字都不发，迟到的懒装不会在格子里留一份永远放不掉的表。跨进程时格子永远是空的，行按原路退回。
    }
    return await deckToolsP
  }

  // ── E（#723 T19c）：行级增量真的能在宿主里跑起来 ────────────────────────────────────────────
  // 以前探测到变化之后没人去跑 refresh/patch.js，客户端只能整池重建；现在它在这里装起来，由 wf.probe 那条路在
  //「探测说变了」之后调用。依赖由宿主入口显式传入：readSnapshot / writeSnapshot 读写的正是宿主那份快照缓存与
  // 磁盘缓存（与客户端看到的列表同一份）；send / decide 是闸的两半，读路径的账与裁决一个字都另不算。
  let patchRunner = null
  function patchOf() {
    if (!patchRunner) {
      patchRunner = createPatchForHost({
        readSnapshot: function (cwd) { try { const e = (typeof d.getCache === 'function') ? d.getCache(cwd) : null; return (e && e.snapshot) ? e.snapshot : null } catch (eR) { return null } },
        writeSnapshot: async function (cwd, snap) {
          try { if (typeof d.setCache === 'function') d.setCache({ ts: Date.now(), snapshot: snap, error: null, cwd: cwd }) } catch (eW) {}
          try { const repo = await d.getRepoKey(cwd); if (repo && typeof d.writeDiskCache === 'function') await d.writeDiskCache(repo, snap) } catch (eD) {}
        },
        indexOfSnapshot: function (snap) { return (typeof d.issueIndexFromSnapshot === 'function') ? d.issueIndexFromSnapshot(snap) : {} },
        probeIndex: function (cwd, sinceIso) { return (typeof d.fetchIssueIndex === 'function') ? d.fetchIssueIndex(cwd, sinceIso) : Promise.resolve({ ok: false }) },
        getRepoKey: function (cwd) { return (typeof d.getRepoKey === 'function') ? d.getRepoKey(cwd) : Promise.resolve(null) },
        runGh: function (args2, cwd) { return (typeof d.runGh === 'function') ? d.runGh(args2, cwd) : Promise.resolve({ ok: false, error: 'no-runGh' }) },
        send: function (req, perform) { return gate.send(req, perform) },
        decide: function (req) { return gate.decideFor(req) },
        // 与活跃集合、写事件白名单同一把短散列（见 syncAttention）：不一致就会让探测这条路每一笔都被判「推迟」。
        workspaceKeyOf: workspaceKeyOf,
        now: Date.now,
        logCtx: logCtx,
      })
    }
    return patchRunner
  }

  /**
   * 跑一次行级增量，回 patch.run 的原话（见 refresh/patch.js 文件头那一张表）。
   * 只在两条依赖齐了才跑（跑 gh 的出口与探测索引的出口）——缺任何一个都如实回 failed，
   * 让调用方照旧走整池那条老路，绝不假装补过。
   */
  async function deltaRefresh(cwd, opts) {
    if (typeof d.runGh !== 'function' || typeof d.fetchIssueIndex !== 'function') return { mode: 'failed', reason: 'no-transport' }
    try { return await patchOf().run(cwd, opts || {}) } catch (e) { return { mode: 'failed', reason: 'patch-threw' } }
  }

  /** 切进一个工作区那一下要问的事（有待办就整池、并清待办）。 */
  async function deltaEnter(cwd) {
    if (typeof d.getCache !== 'function') return { mode: 'use-cache', reason: 'no-cache-port' }
    try { return await patchOf().enterWorkspace(cwd) } catch (e) { return { mode: 'use-cache', reason: 'patch-threw' } }
  }

  return {
    ledger: ledger,
    gate: gate, send: function (req, perform) { return gate.send(req, perform) }, // #927：面板取数那两路要过闸（它们是「人的动作」那一类，只记账、不降档）
    writeEvents: writeEvents,
    sessionTickets: sessionTickets,
    attention: attention,
    hash8: hash8,
    chainReadoutOf: chainReadoutOf,
    deckToolsForHost: deckToolsForHost,
    deltaRefresh: deltaRefresh,
    deltaEnter: deltaEnter,
    syncAttention: syncAttention,
    noteWorkspaceActive: noteWorkspaceActive,
    firstTextOf: function (sid) { try { return readFirstUserText(d.ctx, sid) } catch (e) { return Promise.resolve(null) } }, // #746 首句直读（读而不激活；失败即 null）
    titleFactOf: function (sid) { try { const ctx = d.ctx; if (!ctx || typeof ctx.get !== 'function') return null; const ss = ctx.get('sessions'), ts = ctx.get('sessionTitle'); if (!ss || typeof ss.get !== 'function' || !ts || typeof ts.get !== 'function') return null; const session = ss.get(sid); if (!session) return null; const snap = ts.get(session); if (!snap || typeof snap.title !== 'string' || !snap.title) return null; const kind = snap.source && typeof snap.source.kind === 'string' ? snap.source.kind : ''; return kind ? { kind: kind, title: snap.title } : null } catch (e) { return null } }, // 标题来源事实（写这条名的那一次是谁写的：user 人写的／fallback 底座首句名／provider 底座模型取名），取自宿主会话与标题两个原生服务；缺服务或读不到即 null，执行点退回旧判据
    attach: attach,
    once: once,
    stats: function () {
      const out = { gate: null, writeEvents: null, sessionTickets: null, allowedRoots: allowed.length }
      try { out.gate = gate.stats() } catch (e) {}
      try { out.writeEvents = writeEvents.stats() } catch (e) {}
      try { out.sessionTickets = sessionTickets.stats() } catch (e) {}
      return out
    },
  }
}
