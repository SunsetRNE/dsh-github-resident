// src/host/refresh/gate.js —— 刷新机制的唯一出口闸（#706 T2 第二批）
//
// 依据：定稿第三章「三层 + 一道闸」与第四章第 01 件。它只回答一句：这一笔去 GitHub 的调用，
// 现在放行、降级，还是推迟？放行之后再记一笔真实花费。裁决本身一行都不在这里 —— 它调 refresh-core
// 那份纯函数产物 policy.js（第一批的成果），数字全部从 budget.js 取好注入。所以本文件里没有一条裁决规则、
// 没有一个额度数字，这两个 import 就是「只许复用、不许再写一份」的落地方式。
//
// 守住五件事（票面点名的五条硬要求，逐条对应下面一段代码）：
//   1. **唯一出口**：分类（人的动作 / 生命周期 / 后台 / AI 工具）、记账、裁决、推迟队列四件事都在这里做。
//      静态扫描门禁（tests/verify-gh-gateway.js）扫整个 src，要求每一个能起 gh 进程的调用点都登记在册。
//   2. **记账单位是真实出站 HTTP 请求数**：调用方报几条、传输层真发几条，两个数各自记账并当场对账；
//      分页、重试、兜底链、扇出都要算进去，所以闸不认「逻辑上一次调用」这个说法。
//   3. **不排队、按步记账**：发送之间互不排队（不同工作区、同一工作区的并发都直接发，本地文件的写保护见各自房间的单写者队列）；每一步的真实花费按这一步的计数器归属（见 shared/step-cost.js），并发算不进对方。
//   4. **推迟 ≠ 失败**：被推迟的进推迟队列，同一工作区只留最后一次，5 分钟（DEFER_EXPIRY_MS）过期即丢；
//      丢弃不算失败、不计连续失败次数。只有真失败才进 failuresSinceSuccess，由裁决那侧安排退避。
//   5. **运行期漏网计数**：传输层每真发一条就报一次（noteOutbound），与闸记下来的条数之差就是绕开闸
//      发出去的条数（escaped()）—— 这个数不为 0，就说明有人偷偷发了请求。
//
// 二级限流（Retry-After）也是降档信号：noteRetryAfter() 一次就把所在桶按红档处理（主桶没用完也降档），并把那个工作区标成撞限流。
// #998：连续失败到门槛之后由 failure-window.js 那台状态机放一笔探针进来试（细节见那个文件）。
import { decide, aiToolAdmission, degradePlanFor, REQUEST_KINDS, REASONS, FAILURE_DEFER_AT, nextAttemptDelayMs } from '../../shared/refresh/policy.js'
import * as budget from '../../shared/refresh/budget.js'
import * as failureWindow from '../../shared/refresh/failure-window.js'
import { measureStep, noteStepOutbound } from '../../shared/step-cost.js'
import { refusalTextRef } from '../../shared/refresh/refusal-text.js'

/** 四个类别（谁在做事）。与 policy.js 的 RequestCategory 同一套取值。 */
export const GATE_CATEGORIES = ['user-action', 'lifecycle', 'background', 'ai-tool']

/** 类别 → 记哪一档账。插件自己的刷新（后台与生命周期）记一档，人的动作与 AI 工具各记一档。 */
export const ACCOUNT_OF_CATEGORY = { 'user-action': 'user-action', 'lifecycle': 'plugin', 'background': 'plugin', 'ai-tool': 'ai-tool' }

/**
 * 调用点 → 类别。分类是本闸的第一件事：以后新加一个取数功能，先在这里给它一个身份，
 * 拿不到身份的按「后台」算（最先被牺牲的那一档，是最保守的兜底），并计入 stats().unclassified 让人看见。
 */
export const CALL_SITE_CATEGORIES = {
  'panel.refresh': 'user-action',      // 面板上的刷新按钮
  'panel.detail': 'user-action',       // 点开一张票、翻一页评论
  'panel.write': 'user-action',        // 发评论、认领、改标签、关闭、建票
  'workspace.enter': 'lifecycle',      // 切进一个工作区那一次（缓存先铺满，再补探）
  'workspace.linger': 'background',    // 刚离开 30 秒内的收尾节拍
  'probe.tick': 'background',          // 变化探测（活跃工作区那一下）
  'patch.apply': 'background',         // 行级补行（只取变的那几条）
  'reconcile.tick': 'background',      // 每 10 分钟一次的整池对账
  'chain.eval': 'background',          // 检查链求值（已改成事件驱动）
  'naming.sweep': 'background',        // 命名守护的兜底一跳
  'quota.sync': 'background',          // 每分钟读一次服务端剩余（不扣配额，但仍是真实出站）
  'tool.call': 'ai-tool',              // AI 通过我们的工具发起的调用
  'event.write': 'background',         // #723（T19）写完一笔触发的那次取数（writeEvents.js 发）
}

/** 请求种类 → 记哪一个桶。REST 数请求条数、GraphQL 数点数，两桶各自一份额度与档位。 */
export const BUCKET_OF_KIND = {
  'quota-read': 'rest', probe: 'rest', detail: 'rest', preflight: 'rest', chain: 'rest',
  naming: 'rest', write: 'rest', patch: 'graphql', rebuild: 'graphql', reconcile: 'graphql', 'tool-batch': 'graphql',
}

/** 从 budget.js 取一套裁决要用的数字（形状与 tests/verify-policy.js 里那份一致，两处同源）。 */
export function policyLimits(src) {
  const b = src || budget
  return {
    probeIntervalMs: b.PROBE_INTERVAL_MS,
    probeIntervalYellowMs: b.PROBE_INTERVAL_YELLOW_MS,
    reconcileIntervalMs: b.RECONCILE_INTERVAL_MS,
    rebuildMinIntervalYellowMs: b.REBUILD_MIN_INTERVAL_YELLOW_MS,
    aiToolMaxPointsPerCall: b.AI_TOOL_MAX_POINTS_PER_CALL,
    aiToolMaxRequestsPerCall: b.AI_TOOL_MAX_REQUESTS_PER_CALL,
    aiToolMaxPointsPerHour: b.AI_TOOL_MAX_POINTS_PER_HOUR,
    aiToolMaxRequestsPerHour: b.AI_TOOL_MAX_REQUESTS_PER_HOUR,
    failureBackoffMs: b.CHAIN_BACKOFF_MS,
  }
}

/** 调用点 → 类别；给了类别就直接用它（校验取值）。两者都没有的按「后台」算，并计入漏分类计数。 */
export function classify(source, explicitCategory) {
  if (explicitCategory) {
    if (GATE_CATEGORIES.indexOf(explicitCategory) < 0) throw new Error('没有这个类别：' + String(explicitCategory))
    return { category: explicitCategory, known: true }
  }
  const hit = CALL_SITE_CATEGORIES[String(source)]
  if (hit) return { category: hit, known: true }
  return { category: 'background', known: false }
}

function num(v) { return (typeof v === 'number' && isFinite(v)) ? v : 0 }

/** 报数归一：数字 = 请求条数；对象取 requests/points；两者都没有算「没报数」（只按实测记账，不计对不上）。 */
function readReport(report) {
  if (typeof report === 'number') return { requests: report, points: 0 }
  const r = report || {}
  const hasReq = typeof r.requests === 'number' && isFinite(r.requests)
  const hasPts = typeof r.points === 'number' && isFinite(r.points)
  if (!hasReq && !hasPts) return null
  return { requests: num(r.requests), points: num(r.points) }
}

/** 8 位十六进制短散列：只在日志里代替原文（路径、错误正文），不参与判定。 */
function shortHash(s) {
  try {
    const t = String(s || '')
    let h = 5381
    for (let i = 0; i < t.length; i++) h = (((h << 5) + h + t.charCodeAt(i)) >>> 0)
    return ('0000000' + h.toString(16)).slice(-8)
  } catch (e) { return '00000000' }
}

/**
 * 建一道闸。deps: { ledger, logCtx?, now?, hash8? }。
 * ledger 是本目录的账本（ledger.js）—— 两个文件不互相 import：宿主接线的时候把它们拼起来，
 * 闸只按形状用它（view / spend / noteRateLimited / hourOf / syncDue）。
 */
export function createGate(deps) {
  const opts = deps || {}
  const ledger = opts.ledger
  if (!ledger || typeof ledger.view !== 'function' || typeof ledger.spend !== 'function') {
    throw new Error('闸要一本账：deps.ledger 缺 view / spend 这两条')
  }
  const now = typeof opts.now === 'function' ? opts.now : Date.now
  const logCtx = opts.logCtx || null
  const hash8 = typeof opts.hash8 === 'function' ? opts.hash8 : shortHash
  const limits = policyLimits(opts.budget)

  const workspaces = new Map()   // 工作区键 → { active, failuresSinceSuccess, rateLimitedUntil, backoffWindowStartedAt }
  const deferred = new Map()     // 工作区键 → { req, category, kind, bucket, at }
  const stats = {
    accounted: { requests: 0, points: 0 },   // 闸记下来的（= 传输层真发的）
    transport: { requests: 0, points: 0 },   // 传输层报上来的（真发出去几条）
    claimed: { requests: 0, points: 0 },     // 调用方自己报的数（用来对账）
    mismatch: 0,                             // 报数与真发数对不上的次数
    sent: 0, deferred: 0, coalesced: 0, droppedExpired: 0, retryAfter: 0, unclassified: 0,
  }
  const byCategory = {}
  for (const c of GATE_CATEGORIES) byCategory[c] = 0

  function wsState(key) {
    let s = workspaces.get(key)
    if (!s) { s = { active: false, failuresSinceSuccess: 0, rateLimitedUntil: 0, backoffWindowStartedAt: 0 }; workspaces.set(key, s) }
    return s
  }

  function workspaceView(key) {
    const s = wsState(key)
    return { active: !!s.active, failuresSinceSuccess: s.failuresSinceSuccess, rateLimited: s.rateLimitedUntil > now(), backoffWindowStartedAt: s.backoffWindowStartedAt }
  }

  /** 裁决的输入：类别 + 种类 + 桶的档位与账 + 工作区状态。 */
  function inputFor(req) {
    const bucket = req.bucket
    const q = ledger.view(bucket)
    const s = wsState(req.workspaceKey)
    // 连续失败那一轮的窗口（#998）：到门槛之后哪一笔可以当探针放进来试，判据只有 failure-window.js 一份。
    const win = failureWindow.failureWindowOf(s)
    const trialDue = win.failures >= FAILURE_DEFER_AT && failureWindow.halfOpenTrialIsDue(
      win, now(), nextAttemptDelayMs(win.failures, limits), budget.FAILURE_HALF_OPEN_DELAY_MS,
    )
    return {
      category: req.category, kind: req.kind, tier: q.tier,
      quota: { allowance: q.allowance, used: q.used, remaining: q.remaining, reserve: q.reserve },
      workspace: { active: !!s.active, failuresSinceSuccess: s.failuresSinceSuccess, rateLimited: s.rateLimitedUntil > now(), halfOpenTrialDue: trialDue },
    }
  }

  // 账本三个事件之一（按需级 P1）：这一笔的结论与原因。外层先判调试开关，关着连字段对象都不组装。
  function fireDecide(req, verdict, reason, tier) {
    try { if (logCtx && logCtx.isEnabled('debug')) logCtx.fire('debug', 'refresh.decide', { category: req.category, kind: req.kind, verdict: verdict, reason: reason, tier: tier }) } catch (eL) {}
  }

  // 账本三个事件之一（按需级 P1）：被跳过的那些（后台档被推迟、额度不足、过期丢弃）。
  function fireSkipped(key, kind, reason, pending) {
    try { if (logCtx && logCtx.isEnabled('debug')) logCtx.fire('debug', 'refresh.skipped', { keyHash: hash8(key), kind: kind, reason: reason, pending: pending }) } catch (eL) {}
  }

  /** 只看结论不发送（界面与门禁都要能用同一套裁决问一句）。 */
  function decideFor(req) {
    const r = normalize(req)
    return decide(inputFor(r), limits)
  }

  function normalize(req) {
    const r = req || {}
    const cls = classify(r.source, r.category)
    if (!cls.known) stats.unclassified += 1
    const kind = REQUEST_KINDS.indexOf(r.kind) >= 0 ? r.kind : 'probe'
    const bucket = (r.bucket === 'graphql' || r.bucket === 'rest') ? r.bucket : (BUCKET_OF_KIND[kind] || 'rest')
    return { source: r.source, category: cls.category, kind: kind, bucket: bucket, workspaceKey: String(r.workspaceKey || 'unknown'), plan: Array.isArray(r.plan) && r.plan.length ? r.plan : [{}] }
  }

  /**
   * 真发一步：这一步实际发出去的条数由这一步的计数器归属（并发的另一步记在它自己的计数器上）。
   * 失败也照样记账 —— 发出去的那几条就是已经花掉的额度，账不许因为失败就不记（I6）。
   */
  async function runStep(req, step, perform) {
    let actual = { requests: 0, points: 0 }
    let reported = null
    let failure = null
    const m = await measureStep(function () { return perform(step, { category: req.category, kind: req.kind, bucket: req.bucket }) })
    if (m.thrown) failure = m.thrown
    else reported = readReport(m.result)
    actual = { requests: m.actual.requests, points: m.actual.points }
    if (reported) {
      stats.claimed.requests += reported.requests
      stats.claimed.points += reported.points
      if (reported.requests !== actual.requests || reported.points !== actual.points) stats.mismatch += 1
    }
    // 账记的是真发出去的那几条（传输层说了算），不是调用方报的数；报到哪儿去由账本按档与桶分开记。
    stats.accounted.requests += actual.requests
    stats.accounted.points += actual.points
    const account = ACCOUNT_OF_CATEGORY[req.category] || 'plugin'
    const after = ledger.spend({ account: account, bucket: req.bucket, kind: req.kind, requests: actual.requests, points: actual.points })
    if (failure) {
      // 一次真失败：计数加一，窗口从此刻重开（窗口长短的判据在 refresh-core/src/failure-window.ts）。
      const next = failureWindow.recordFailure({ failures: wsState(req.workspaceKey).failuresSinceSuccess, windowStartedAt: 0 }, now())
      wsState(req.workspaceKey).failuresSinceSuccess = next.failures
      wsState(req.workspaceKey).backoffWindowStartedAt = next.windowStartedAt
      throw failure
    }
    wsState(req.workspaceKey).failuresSinceSuccess = 0
    return { requests: actual.requests, points: actual.points, claimed: reported || { requests: 0, points: 0 }, remaining: after.remaining, tier: after.tier, result: m.result }
  }

  /**
   * 闸的唯一出口。req: { source|category, kind, bucket?, workspaceKey?, plan? }；perform(step) 真去发请求
   * 并**每条真实出站都先报一次 noteOutbound**，返回值是它自己报的花费（会被拿来实现对账）。
   */
  async function send(req, perform) {
    const r = normalize(req)
    const v = decide(inputFor(r), limits)
    // 放了探针进来试的那一笔：窗口起点改成此刻（见 refresh-core/src/failure-window.ts）。
    // ① 这一笔要是失败，下一次等待从此刻重新算，不会连环重试；② 这一笔要是成功，下面的归零当场开锁。
    if (v.verdict === 'allow' && v.reason === 'failure-half-open') {
      wsState(r.workspaceKey).backoffWindowStartedAt = failureWindow.consumeHalfOpenTrial(now())
    }
    fireDecide(r, v.verdict, v.reason, ledger.view(r.bucket).tier)
    byCategory[r.category] = (byCategory[r.category] || 0) + 1
    if (v.verdict === 'defer') {
      const prev = deferred.get(r.workspaceKey)
      if (prev) stats.coalesced += 1
      deferred.set(r.workspaceKey, { req: r, category: r.category, kind: r.kind, bucket: r.bucket, at: now() })
      stats.deferred += 1
      fireSkipped(r.workspaceKey, r.kind, v.reason, deferred.size)
      return { sent: false, verdict: 'defer', reason: v.reason, detail: REASONS[v.reason] || '', requests: 0, points: 0 }
    }
    if (typeof perform !== 'function') throw new Error('闸放行了却没有发送函数：' + r.kind)
    let requests = 0
    let points = 0
    let remaining = 0
    let tier = 'green'
    let result = null   // #927：把这一步真做出来的东西原样带回去（面板取数那两路要用它的返回值）
    for (const step of r.plan) {
      const out = await runStep(r, step, perform)
      requests += out.requests
      points += out.points
      remaining = out.remaining
      tier = out.tier
      result = out.result
    }
    stats.sent += 1
    return { sent: true, verdict: v.verdict, reason: v.reason, detail: REASONS[v.reason] || '', requests: requests, points: points, remaining: remaining, tier: tier, steps: r.plan.length, result: result }
  }

  /** 传输层每真发一条就报一次（生产里挂在起 gh 进程那一层）。绕开闸发的那几条就靠它露出来。 */
  function noteOutbound(entry) {
    const e = entry || {}
    stats.transport.requests += num(e.requests) || 1
    stats.transport.points += num(e.points)
    try { noteStepOutbound(e) } catch (e2) {}
    return { requests: stats.transport.requests, points: stats.transport.points }
  }

  /** 撞上限流（含二级限流的 Retry-After）：桶降档 + 工作区标记 + 计数。 */
  function noteRetryAfter(signal) {
    const s = signal || {}
    const r = normalize(s)
    const at = ledger.noteRateLimited(r.bucket, s.seconds, now())
    if (s.workspaceKey) wsState(r.workspaceKey).rateLimitedUntil = Math.max(wsState(r.workspaceKey).rateLimitedUntil, at.until)
    stats.retryAfter += 1
    return { bucket: r.bucket, until: at.until, tier: ledger.view(r.bucket).tier }
  }

  /** 推迟队列：到期的交回调用方重发，过期（5 分钟）的直接丢 —— 丢不是失败，也不重试。 */
  function drain(at) {
    const t = (typeof at === 'number') ? at : now()
    const ready = []
    let dropped = 0
    for (const [key, e] of Array.from(deferred.entries())) {
      deferred.delete(key)
      if ((t - e.at) >= budget.DEFER_EXPIRY_MS) { dropped += 1; stats.droppedExpired += 1; fireSkipped(key, e.kind, 'defer-expired', deferred.size) }
      else ready.push({ workspaceKey: key, req: e.req, ageMs: t - e.at })
    }
    return { ready: ready, dropped: dropped, pending: deferred.size }
  }

  /** AI 工具那一档的准入：超顶是「拒绝」，不是推迟；两种拒绝的文案必须分得开。 */
  function admitAiTool(call, req) {
    const r = normalize(Object.assign({ source: 'tool.call' }, req, { category: 'ai-tool' }))
    const q = ledger.view(r.bucket)
    const hour = ledger.hourOf('ai-tool')
    const quota = { allowance: q.allowance, used: q.used, remaining: q.remaining, reserve: q.reserve }
    const a = aiToolAdmission({ points: num(call.points), requests: num(call.requests) }, hour, quota, limits)
    const children = num(call.childTickets)
    const plan = children > 0 ? budget.shardPlan(children) : { shards: 1, perShard: budget.AI_TOOL_SHARD_SIZE }
    fireDecide(r, a.admitted ? 'allow' : 'reject', a.reason, q.tier)
    if (!a.admitted) fireSkipped(r.workspaceKey, 'tool-batch', a.reason, deferred.size)
    return { admitted: a.admitted, reason: a.reason, points: a.points, requests: a.requests, remaining: q.remaining,
      shards: plan.shards, perShard: plan.perShard, text: a.admitted ? '' : refusalTextRef(a, q, hour, plan, limits) }
  }

  /** 某个桶现在的降档安排（探测节拍、对账节拍、最短重建间隔），数值全部来自 budget.js。 */
  function planOf(bucketName) {
    return degradePlanFor(ledger.view(bucketName || 'rest').tier, limits)
  }

  /** 运行期漏网计数：传输层真发的条数减去闸记下来的条数。不为 0 就说明有人绕开了闸。 */
  function escaped() {
    return {
      requests: stats.transport.requests - stats.accounted.requests,
      points: stats.transport.points - stats.accounted.points,
    }
  }

  return {
    send: send,
    decideFor: decideFor,
    planOf: planOf,
    admitAiTool: admitAiTool,
    noteOutbound: noteOutbound,
    noteRetryAfter: noteRetryAfter,
    drain: drain,
    escaped: escaped,
    stats: function () {
      return {
        accounted: { requests: stats.accounted.requests, points: stats.accounted.points },
        transport: { requests: stats.transport.requests, points: stats.transport.points },
        claimed: { requests: stats.claimed.requests, points: stats.claimed.points },
        escaped: escaped(), mismatch: stats.mismatch, sent: stats.sent, deferred: stats.deferred,
        coalesced: stats.coalesced, droppedExpired: stats.droppedExpired, retryAfter: stats.retryAfter,
        unclassified: stats.unclassified, byCategory: Object.assign({}, byCategory), pending: deferred.size,
      }
    },
    workspaceView: workspaceView,
    setWorkspace: function (key, patch) {
      const s = wsState(String(key))
      if (patch && typeof patch.active === 'boolean') s.active = patch.active
      return workspaceView(String(key))
    },
  }
}
