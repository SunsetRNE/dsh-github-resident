/**
 * views/ListTab.js — 主列表（排序/过滤/chips/行动作，5.5）
 * 契约：模块真源（ESM 导出）；scripts/build.mjs 构建时剥行首 export 拼回
 * src/client/index.js 的 `// ==== leaf:... (spliced by build) ====` 标记处（一源两物）。
 */
export     const MAP_ROW_GUARD_NARROW = 320
export     const MAP_ROW_GUARD_WIDE = 440
export     const authorColor = function(l){let h=0;for(let i=0;i<l.length;i++)h=(h*31+l.charCodeAt(i))%360;h=(h*137.508)%360;let s=0.72,ll=0.5,c=(1-Math.abs(2*ll-1))*s,x=c*(1-Math.abs((h/60)%2-1)),m=ll-c/2,r=0,g=0,b=0;if(h<60){r=c;g=x}else if(h<120){r=x;g=c}else if(h<180){g=c;b=x}else if(h<240){g=x;b=c}else if(h<300){r=x;b=c}else{r=c;b=x}r=Math.round((r+m)*255);g=Math.round((g+m)*255);b=Math.round((b+m)*255);return '#'+[r,g,b].map(v=>v.toString(16).padStart(2,'0')).join('');}
// 2026-09-11 同类毛病一并修（与 views/shared/tagsFit.js 同一回事；纪律「布局零抖动」见
//   docs/adr/20260911-zero-layout-jitter.md，证据见 #602）：原写法每个地图行都
//   「写一次类名（把编号改横排、并把标题切进测量态）→ 立即读一次 scrollWidth」，量改交替，
//   48 个地图行就是 48 次强制重排。现分相改四趟：先一次读完所有行宽（测量相）
//   → 单独一段只写类名并把要量的行切进测量态 → 只读（测量相，整趟只重排一次）
//   → 只写（变更相：收掉测量态、放不下的退回竖排）。
export     const fitMapRows = function () {
      if (typeof document === 'undefined') return
      const rows = document.querySelectorAll('.dsws-aggrow')
      // 第一趟（只读）：行宽由外层容器决定，与行内编号是横排还是竖排无关，所以先读再写读到的是同一个值。
      const items = []
      for (let i = 0; i < rows.length; i++) {
        const rowEl = rows[i]
        const idcol = rowEl.querySelector('.dsws-idcol')
        const title = rowEl.querySelector('.dsws-tt-wrap')
        if (!idcol || !title) continue
        items.push({ idcol: idcol, title: title, isMap: !!idcol.querySelector('.dsws-chip-m'), avail: rowEl.clientWidth })
      }
      // 第二趟（只写）：非地图行与极窄行去掉横排；宽行直接横排；中间行先横排并切进测量态。
      const measure = []
      for (let i = 0; i < items.length; i++) {
        const it = items[i]
        if (!it.isMap || it.avail < MAP_ROW_GUARD_NARROW) { it.idcol.classList.remove('h'); continue }
        it.idcol.classList.add('h')
        if (it.avail < MAP_ROW_GUARD_WIDE) { it.title.classList.add('dsws-measure'); measure.push(it) }
      }
      // 第三趟（只读）：标题在测量态下放不放得下。这一趟不写任何样式，所以只触发一次重排。
      for (let i = 0; i < measure.length; i++) {
        const it = measure[i]
        it.fits = it.title.scrollWidth <= it.title.clientWidth + 1
      }
      // 第四趟（只写）：收掉测量态；放不下的退回竖排。
      for (let i = 0; i < measure.length; i++) {
        const it = measure[i]
        it.title.classList.remove('dsws-measure')
        it.title.classList.remove('measure')
        if (!it.fits) it.idcol.classList.remove('h')
      }
    }
export     const ListTab = ({ st, narrow }) => {
      const cx = React.useContext(DswsCtx)
      const h = cx ? cx.h : React.createElement
      // v1.3.3 UI：每次渲染后执行贪心折叠（含窗口/列宽变化后的重渲染）
      // v1.5 T10 提速：按内容指纹跳过 —— 仅快照内容/tab/过滤变化才重排（refreshing 态等无关渲染不触发布局测量）
      React.useLayoutEffect(function () {
        // #606 常规测点（折叠测量耗时）：本副作用跑在提交阶段，落在渲染期计时的盲区里，
        //   是「那一帧在建什么」的主要嫌疑之一，所以把这段耗时累加进 panelClock 交给 DockSync 打日志；
        //   本文件在渲染目录里但不在可写日志的点名名单里（见 tests/verify-log-truncate.js 第 4 组），
        //   所以这里只累加数字，不写日志。
        const _tFit0 = isEnabled('debug') ? panelNow() : 0
        const _addFit = function () { try { if (_tFit0) panelClock.fitMs = Math.round((panelClock.fitMs || 0) + (panelNow() - _tFit0)) } catch (eF) {} }
        const fp = String((st.snapshot && st.snapshot.generatedMs) || '') + '|' + st.tab + '|' + st.stateFilter + '|' + (st.lblFilters || []).join(',')
        if (_tagsFpOf.get(st) === fp) { _addFit(); return }
        _tagsFpOf.set(st, fp)
        fitAllTags()
        try { fitMapRows() } catch (e) {}
        _addFit()
      })
      // Map #120 T1：标题适配 + 宽度护栏 的容器尺寸监听（面板拖拽 / 字体加载 / window resize）
      React.useLayoutEffect(function () {
        const doFit = function () { try { fitMapRows() } catch (e) {} }
        doFit()
        let ro = null
        try {
          if (typeof ResizeObserver !== 'undefined') {
            ro = new ResizeObserver(function () { doFit() })
            // #646：面板容器现在在右侧边栏里（Dock 的根节点带 data-dsws-host），页内浮窗已退役
            const panel = document.querySelector('[data-dsws-host]')
            const body = document.querySelector('.dsws-body')
            if (panel) try { ro.observe(panel) } catch (e) {}
            if (body) try { ro.observe(body) } catch (e) {}
            document.querySelectorAll('.dsws-aggrow').forEach(function (el) { try { ro.observe(el) } catch (e) {} })
          }
        } catch (e) {}
        const onWin = function () { doFit() }
        if (typeof window !== 'undefined') window.addEventListener('resize', onWin)
        let fontsDone = false
        if (typeof document !== 'undefined' && document.fonts && document.fonts.ready) {
          document.fonts.ready.then(function () { if (!fontsDone) { fontsDone = true; doFit() } })
        }
        return function () {
          try { if (ro) ro.disconnect() } catch (e) {}
          if (typeof window !== 'undefined') window.removeEventListener('resize', onWin)
        }
      }, [])
      // #690：历史票按需翻页。这一钩子在「看得到已关闭票」的两处生效（状态筛到「已关闭」，或底部那条
      //   折叠行被展开）：进去先把第一页备上，滚到底再顺着游标取下一页。三个触发点共用同一份页数据。
      useClosedPageScroll(st, st.stateFilter === 'closed' || st.closedFoldOpen === true)
      // effort 维度：仓库里有几个 effort（去重排序，来自共享小件；单 effort 后端恒 []，界面不变）
      const effortNames = effortNamesOf(st)
      const multiEffort = effortNames.length > 1
      // effort 筛选（会话私有，不持久化）：没选=全部；选了=只看这些 effort 的行
      const effPass = function (x) {
        const sel = st.effFilters || []
        return !sel.length || sel.indexOf(effortOf(x)) >= 0
      }
      // #689 工单口径：拉取请求不进主列表（面板另有专门的拉取请求页签；口径判断住在 store-derived 的
      //   isTicketRow，与 KPI、状态栏共用同一处）。池子（snapshot.issues）本身不动，仍是原样全收。
      // #690：再并上「按需翻回来的那些页」里池子没有的行（issuePageRowsOf 已按身份去掉重复的），
      //   于是已关闭那一堆里既有首屏那一百条、也有用户翻出来的更早的票；静默刷新只换池子，页数据不动。
      const issues = ticketRowsOf((st.snapshot && Array.isArray(st.snapshot.issues)) ? st.snapshot.issues : []).concat(issuePageRowsOf(st, 'list'))
      const openIssues = issues.filter(function (x) { return x.state !== 'CLOSED' })
      const closedIssues = issues.filter(function (x) { return x.state === 'CLOSED' })
      // #374：多维排序 —— map 行恒置顶，map 组与普通组各自按所选维度排序；默认 更新时间↓（与现状一致）
      const sortIssues = function (arr) {
        const dir = st.sortDir === 'asc' ? 1 : -1
        return arr.slice().sort(function (a, b) {
          let c
          if (st.sortKey === 'number') { c = a.number - b.number; if (c !== 0) return dir * c }
          else if (st.sortKey === 'title') {
            c = String(a.title).toLowerCase().localeCompare(String(b.title).toLowerCase())
            if (c !== 0) return dir * c
          } else {
            c = String(a[st.sortKey] || '').localeCompare(String(b[st.sortKey] || ''))
            if (c !== 0) return dir * c
          }
          return String(a.effortId||'').localeCompare(String(b.effortId||'')) || (a.number - b.number)  // 同键兜底：先 effort 再编号升序（稳定）
        })
      }
      const isMapIssue = function (x) { return x.type === 'map' || ((x.labels || []).some(function (l) { return l.name === 'wayfinder:map' })) }
      const sortedMaps = sortIssues(openIssues.filter(isMapIssue))
      const sortedOpen = sortIssues(openIssues.filter(function (x) { return !isMapIssue(x) }))
      const closedSorted = sortIssues(closedIssues)
      const groups = compute(st)
      const occ = groups.reduce(function (n, g) { return n + g.blocked.length + g.claimed.length }, 0)
      // #284：环境坏项计数改从链快照步骤派生（fail/current 均为需处理项）
      const nBad = chainSteps(st).filter(function (s) { return s.status === 'fail' || s.status === 'current' }).length
      // 标签统计（含地图子票）与配色：票面最终色（工作区改色已在票面），不直读 palette
      const stat = {}, colorOf = {}
      const snapLabels = (st.snapshot && Array.isArray(st.snapshot.labels)) ? st.snapshot.labels : null
      if (snapLabels) snapLabels.forEach(function (l) { if (l && l.name && l.color) colorOf[String(l.name).trim()] = String(l.color).trim().replace(/^#/, '') })
      const allForColor = issues.slice()
      ;(st.snapshot && Array.isArray(st.snapshot.maps) ? st.snapshot.maps : []).forEach(function(m){(m.tickets||[]).forEach(function(t){allForColor.push(t)})})
      allForColor.forEach(function (x) {(x.labels||[]).forEach(function(l){const nm=l&&l.name?String(l.name).trim():'';if(!nm)return;stat[nm]=(stat[nm]||0)+1;if(l.color)colorOf[nm]=String(l.color).trim().replace(/^#/, '')})})
      const tagNames = Object.keys(stat).sort(function (a, b) { return stat[b] - stat[a] })
      // #375：全量 label（快照 labels 字段优先；旧快照无该字段降级 issue 统计）；配色按票面最终色已覆盖，缺失才用快照表
      const labelNames = snapLabels ? snapLabels.map(function (l) { return l.name }) : tagNames.slice()
      // 点击记忆双键排序：次数降序 → 最近点击降序 → 出现频次降序 → 名称序
      const sortedLabels = labelNames.slice().sort(function (a, b) {
        const ca = labelClicks[a], cb = labelClicks[b]
        const na = ca ? ca.n : 0, nb = cb ? cb.n : 0
        if (na !== nb) return nb - na
        const ta = ca ? ca.ts : 0, tb = cb ? cb.ts : 0
        if (ta !== tb) return tb - ta
        const fa = stat[a] || 0, fb = stat[b] || 0
        if (fa !== fb) return fb - fa
        return String(a).localeCompare(String(b))
      })
      // v15-26：主列表关联 map 子票阻塞信息（open 阻塞者才算阻塞；数据来自快照 maps.tickets.blockedBy，无需额外请求）
      // effort 维度：阻断表由共享函数产出（按票身份 (effort, 编号) 键入、阻塞引用只在同 effort 内解析）
      const blockOf = mapBlockOf(st.snapshot)
      // #544 独立票阻塞边：快照 issues 自带 blockedBy（列表查询片段已复用，零请求），
      // 只挂自己身上（已是地图子票的行跳过，不碰地图层级与计数），逻辑见 store-derived.applyStandaloneBlocks。
      // 此处不包 try：函数缺失说明构建拼接坏了，必须 loud；单票坏数据由函数内逐票兜底，不崩整表。
      applyStandaloneBlocks(st, blockOf)
      // #374：状态过滤（全部/Open/阻塞/已关闭）与 label 过滤叠加
      // v1.3.3 T3：blocked 过滤真正实现 —— open 且存在 open 阻塞者（blockOf 命中）
      const showOpen = st.stateFilter !== 'closed'
      const showClosedList = st.stateFilter === 'closed'
      // v1.5：多选标签过滤（OR 语义：命中任一选中标签即显示）
      const byLabel = function (x) {
        const ls = st.lblFilters || []
        if (!ls.length) return true
        const labs = x.labels || []
        if (!labs.length) return ls.indexOf('needs-triage') >= 0
        return labs.some(function (l) { return ls.indexOf(l.name) >= 0 })
      }
      const openRows = sortedMaps.concat(sortedOpen).filter(effPass)
      const closedRows = closedSorted.filter(effPass)
      const openFiltered = (st.lblFilters && st.lblFilters.length) ? openRows.filter(byLabel) : openRows
      // v1.3.3 #6：阻塞 = 被占用口径（isOccupied：有 assignee 或存在 open 阻塞者）——与 KPI「占用 N」一致，
      //   用户点「阻塞」应筛出全部被占用项（此前 blockOf 只覆盖 map 子票的 blockedBy，漏掉 assignee 占用的）
      const filteredOpen = showOpen ? (st.stateFilter === 'blocked' ? openFiltered.filter(function (x) { return isOccupied(st, x) })
        : (st.stateFilter === 'frontier' ? openFiltered.filter(function (x) { return !isOccupied(st, x) }) : openFiltered)) : []
      const filteredClosed = showClosedList ? ((st.lblFilters && st.lblFilters.length) ? closedRows.filter(byLabel) : closedRows) : []
      // v14-18：chips 常显深一档边框（边框色 = label 色 HSL 亮度 -16%）
      const chip = (nm, withCount, on, isAll) => {
        const c = colorOf[nm]
        const borderColor = isAll ? 'rgba(255,255,255,.35)' : (darken(c, 0.16) || 'rgba(188,140,255,.6)')
        const selColor = isAll ? 'rgba(255,255,255,.65)' : (c ? '#' + c : '#bc8cff')
        return h('span', chipProps({
          key: nm,
          className: 'dsws-chip',
          // v14-1：「全部」恒清空过滤并保持选中，与普通标签 toggle 语义分离
          // #375：点选即记点击记忆（次数 + 最近点击时间，双键排序）
          onClick: function (e) {
            e.stopPropagation()
            // v1.5：多选 toggle —— 选中/取消单个标签，互不覆盖
            const cur = st.lblFilters || []
            st.lblFilters = isAll ? [] : (cur.indexOf(nm) >= 0 ? cur.filter(function (x) { return x !== nm }) : cur.concat([nm]))
            if (!isAll) {
              const c = labelClicks[nm] || { n: 0, ts: 0 }
              labelClicks[nm] = { n: c.n + 1, ts: Date.now() }
              saveLabelClicks()
            }
            emit(st)
          },
          style: {
            cursor: 'pointer', marginRight: 4, marginBottom: 3, fontSize: 10,
            background: isAll ? 'rgba(255,255,255,.08)' : (hexA(c, 0.18) || 'rgba(188,140,255,.16)'),
            color: isAll ? 'var(--dsw-alias-label-secondary,#a1a1aa)' : (c ? '#' + c : '#bc8cff'),
            border: '1px solid ' + (on ? selColor : borderColor),
          },
        }), nm)
      }
      // KPI 口径：与全局一致，但跟随 effort 筛选（未选 effort 时就是全局）
      // #689：两个数字优先读宿主给的后端计数（deck.counts）—— 「已关闭」直接是它；「可接」= 后端说的未关闭
      //   张数减去本地数出来的阻塞（阻塞要逐票看指派人、看有没有开放阻塞者，后端计数给不了）。
      //   拿不到计数、或界面带着筛选时退回按池子派生：deckCountsOf 那时会返回 null（全仓数字与筛过的一屏
      //   不是一个口径），宁可退回派生值，也不拿全仓数字冒充筛过的数字。
      const kpiFiltered = !!((st.effFilters || []).length)
      const kpiCounts = deckCountsOf(st, kpiFiltered)
      const kpiOpenScoped = openIssuesOf(st).filter(effPass)
      const kpiOcc = kpiOpenScoped.filter(function (x) { return isOccupied(st, x) }).length
      const kpiFrontier = kpiCounts ? Math.max(0, kpiCounts.open - kpiOcc) : (kpiOpenScoped.length - kpiOcc)
      const kpiClosed = kpiCounts ? kpiCounts.closed : closedIssues.filter(effPass).length
      // 折叠行那两个数：N（一共多少张）来自后端计数、x（列表里已经加载了多少张）就是手上这些行。
      //   带任何筛选时 N 退回手上的行数 —— 后端给的是全仓总数，与筛过的列表对不上会让人以为少了票。
      const foldCounts = deckCountsOf(st, !!(((st.effFilters || []).length) || ((st.lblFilters || []).length)))
      const kpi = (num, lab, icon, color) => h('div', { style: { display: 'inline-flex', alignItems: 'center', gap: 3, fontSize: 11, color: 'var(--dsw-alias-label-secondary,#a1a1aa)' } }, [Ic({ n: icon, size: 11, color: color }), h('span', null, String(num) + ' ' + lab)])
      return h('div', null, [
        // v1.5：已选标签过滤条（仅标签 · 颜色 = 该标签配置色 · 点 ✕ 关闭）
        (st.lblFilters && st.lblFilters.length) ? h('div', { style: { display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 4, marginBottom: 6 } }, [
          h('span', { style: { fontSize: 10, color: 'var(--dsw-alias-label-caption,#8b8b95)', flex: 'none' } }, tr('list.filterActive')),
          (st.lblFilters || []).map(function (nm) {
            const c = colorOf[nm]
            const hex = c ? '#' + c : '#bc8cff'
            return h('span', { key: 'f-label-' + nm, className: 'dsws-chip', style: { fontSize: 10, background: hexA(c, 0.18) || 'rgba(188,140,255,.16)', color: hex, border: '1px solid ' + (darken(c, 0.16) || 'rgba(188,140,255,.6)') } }, [
              nm,
              h('span', chipProps({ onClick: function (e) { e.stopPropagation(); st.lblFilters = (st.lblFilters || []).filter(function (x) { return x !== nm }); emit(st) }, 'aria-label': tr('list.filterRemoveAria', { name: nm }), style: { cursor: 'pointer', marginLeft: 4, fontWeight: 700 } }), '✕'),
            ])
          }),
          h('span', chipProps({ key: 'f-label-clear', className: 'dsws-chip', onClick: function (e) { e.stopPropagation(); st.lblFilters = []; emit(st) }, style: { fontSize: 10, cursor: 'pointer', background: 'rgba(255,255,255,.06)', color: 'var(--dsw-alias-label-secondary,#a1a1aa)', border: '1px solid rgba(255,255,255,.15)' } }), tr('list.filterClear')),
        ]) : null,
        // B Timeline 定版（2026-08-28）：全屏红卡（NoRepoCard）不再挂载于列表页顶部——
        //   远端未关联/环境未就绪由检查页行内红卡表达，列表页保持 KPI + 列表（无顶部错误信息）
        // KPI 行 + 环境提示（v18-30：可接/占用 = 列表 open issue 口径）
        h('div', { style: { display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4, flexWrap: 'wrap', position: 'relative' } }, [
          kpi(kpiFrontier, tr('list.kpi.takeable'), 'target', '#4ade80'),
          kpi(kpiOcc, tr('list.kpi.occupied'), 'lock', '#f0883e'),
          kpi(kpiClosed, tr('list.kpi.closed'), 'check', '#52525b'),
          // #689 的 partial 状态不再单独占一格（橙色胶囊太抢眼，又长得像按钮但点不动）——
          //   改为数字右上角一颗 5px 圆点 + 悬浮说明追加一句（圆点是状态不是控件；竖条试过，太生硬）。
          h('span', { style: { flex: 1 } }),
          // #685：「体检」按钮 —— 贴这一行的右边缘（左三枚是读数、右边这颗是动作，用位置把两类分开；
          //   与页签行那枚刷新按钮形成「面板级操作都在右侧」的一致手势，#681 定版）。
          //   件数口径见 #678（未关闭 + 不是地图 + 不在任何地图的子票里，与列表里独立票的行数一致），
          //   算不出来时只显示名字、绝不显示 0；三种情况整颗不渲染（见 healthCheckVisible）。
          //   点一下开一个新会话并把当前后端的体检提示词带过去（讲清为什么见 openHealthCheck 里那段注释）。
          (function () {
            if (!healthCheckVisible(st)) return null
            const nHc = healthCheckCountOf(st)
            const isPartial = !!(st.snapshot && st.snapshot.deck && st.snapshot.deck.partial === true) // #689：行数据不全时数字右上角多一颗圆点，悬浮里追加一句（圆点是状态不是控件）
            const btnTier = (!narrow && tr('list.healthCheck').length > 6) ? '' : (nHc == null ? ' narrow-icon' : ' narrow-count')
            const hcStyle = { display: 'inline-flex', alignItems: 'center', gap: 3, flex: 'none', alignSelf: 'center', fontSize: 11, padding: '1px 6px', background: 'rgba(255,255,255,.06)', borderColor: 'rgba(255,255,255,.15)', color: 'var(--dsw-alias-label-secondary,#a1a1aa)', position: 'relative' }
            if (btnTier === ' narrow-icon') { hcStyle.padding = '0'; hcStyle.justifyContent = 'center' }
            else if (btnTier === ' narrow-count') { hcStyle.padding = '1px 5px'; hcStyle.gap = 2 }
            return h(Tip, { content: tr('list.healthCheckTitle') + (isPartial ? '\n' + tr('list.partialTitle') : '') }, h('button', {
              className: 'dsws-btn' + btnTier,
              onClick: function (e) { e.stopPropagation(); openHealthCheck(st) },
              style: hcStyle,
            }, [Ic({ n: 'clipboard', size: 11 }), (btnTier === ' narrow-count' || btnTier === '') ? h('span', null, tr('list.healthCheck') + (nHc == null ? '' : ' ' + nHc)) : null, (isPartial ? h('span', { 'aria-label': tr('list.partial'), style: { position: 'absolute', top: 1, right: 3, width: 5, height: 5, borderRadius: '50%', background: '#f59e0b', boxShadow: '0 0 0 1px rgba(0,0,0,.6)', pointerEvents: 'none' } }) : null)]))
          })(),
          // T2 #2：刷新按钮已上移至面板 tabs 行（页内浮窗退役后，面板只有右侧边栏这一处）
        ]),
        // B Timeline 定版（2026-08-28）：「N 项环境未就绪」红条已移除（顶部无错误信息；状态由检查页行级表达）
        // effort 筛选行（仅多 effort 仓库出现）：点一下只看某个 effort，再点取消；与状态/label 过滤叠加
        multiEffort ? h('div', { style: { display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 4, marginBottom: 6 } }, [
          h('span', chipProps({ key: 'eff-all', className: 'dsws-chip', onClick: function (e) { e.stopPropagation(); st.effFilters = []; emit(st) }, style: { cursor: 'pointer', fontSize: 10, background: !(st.effFilters || []).length ? 'rgba(88,166,255,.18)' : 'rgba(255,255,255,.06)', color: !(st.effFilters || []).length ? '#58a6ff' : 'var(--dsw-alias-label-secondary,#a1a1aa)', border: '1px solid ' + (!(st.effFilters || []).length ? 'rgba(88,166,255,.6)' : 'rgba(255,255,255,.15)') } }), tr('list.all')),
          effortNames.map(function (nm) {
            const on = (st.effFilters || []).indexOf(nm) >= 0
            return h(Tip, { content: nm }, h('span', chipProps({ key: 'eff-' + nm, className: 'dsws-chip', 'aria-label': nm, onClick: function (e) {
              e.stopPropagation()
              const cur = st.effFilters || []
              st.effFilters = on ? cur.filter(function (x) { return x !== nm }) : cur.concat([nm])
              emit(st)
            }, style: { cursor: 'pointer', fontSize: 10, maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', background: on ? 'rgba(88,166,255,.18)' : 'rgba(255,255,255,.06)', color: on ? '#58a6ff' : 'var(--dsw-alias-label-secondary,#a1a1aa)', border: '1px solid ' + (on ? 'rgba(88,166,255,.6)' : 'rgba(255,255,255,.15)') } }), nm))
          }),
        ]) : null,
        // #374/#375：状态过滤 + 排序 + label 过滤 chips（全部小号紧凑同排，窄屏换行不增高；展开态点选 label 不收起）
        h('div', { style: { display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 0, marginBottom: 6 } }, [
          ['all', 'open', 'closed', 'blocked', 'frontier'].map(function (k) {
            const on = st.stateFilter === k
            return h('span', chipProps({ key: 'stf-' + k, className: 'dsws-chip', onClick: function (e) {
              e.stopPropagation(); st.stateFilter = k; listPrefs.stateFilter = k; saveListPrefs(); emit(st)
            }, style: { cursor: 'pointer', marginRight: 4, marginBottom: 3, fontSize: 10, background: on ? 'rgba(188,140,255,.18)' : 'rgba(255,255,255,.06)', color: on ? '#c084fc' : 'var(--dsw-alias-label-secondary,#a1a1aa)', border: '1px solid ' + (on ? 'rgba(188,140,255,.6)' : 'rgba(255,255,255,.15)') } }), tr('list.state.' + k))
          }),
          h('span', { style: { width: 1, height: 12, background: 'var(--dsw-alias-border-l1,#2a2d35)', margin: '0 4px 3px', flex: 'none' } }),
          ['updatedAt', 'createdAt', 'number', 'title'].map(function (k) {
            const on = st.sortKey === k
            const arrow = on ? (st.sortDir === 'asc' ? '↑' : '↓') : ''
            return h('span', chipProps({ key: 'srt-' + k, className: 'dsws-chip', onClick: function (e) {
              e.stopPropagation()
              if (st.sortKey === k) { st.sortDir = st.sortDir === 'asc' ? 'desc' : 'asc' }
              else { st.sortKey = k; st.sortDir = (k === 'title') ? 'asc' : 'desc' }
              listPrefs.sortKey = st.sortKey; listPrefs.sortDir = st.sortDir; saveListPrefs(); emit(st)
            }, style: { cursor: 'pointer', marginRight: 4, marginBottom: 3, fontSize: 10, background: on ? 'rgba(88,166,255,.16)' : 'rgba(255,255,255,.06)', color: on ? '#58a6ff' : 'var(--dsw-alias-label-secondary,#a1a1aa)', border: '1px solid ' + (on ? 'rgba(88,166,255,.55)' : 'rgba(255,255,255,.15)') } }), tr('list.sort.' + k) + arrow)
          }),
          h('span', { style: { width: 1, height: 12, background: 'var(--dsw-alias-border-l1,#2a2d35)', margin: '0 4px 3px', flex: 'none' } }),
          chip(tr('list.all'), false, !st.lblFilters || !st.lblFilters.length, true),
          // #405：filter row 默认可见数 9 → 4（与 per-row 一致）；+N 触发条件 + 数字同步
          (st.expLabels ? sortedLabels : sortedLabels.slice(0, 4)).map(function (nm) { return chip(nm, true, (st.lblFilters || []).indexOf(nm) >= 0, false) }),
          (!st.expLabels && sortedLabels.length > 4) ? h(Tip, { content: tr('list.tagsTitle', { names: sortedLabels.join('、') }) }, h('span', chipProps({ key: 'lbl-more', className: 'dsws-chip', onClick: function (e) { e.stopPropagation(); st.expLabels = true; emit(st) }, style: { fontSize: 10, marginRight: 4, marginBottom: 3, background: 'rgba(188,140,255,.1)', color: '#bc8cff', border: '1px dashed rgba(188,140,255,.55)', cursor: 'pointer' } }), '+' + (sortedLabels.length - 4))) : null,
          st.expLabels ? h(Tip, { content: tr('list.tagsCollapseTitle') }, h('span', chipProps({ key: 'lbl-less', className: 'dsws-chip', onClick: function (e) { e.stopPropagation(); st.expLabels = false; emit(st) }, style: { fontSize: 10, marginRight: 4, marginBottom: 3, background: 'rgba(255,255,255,.06)', color: 'var(--dsw-alias-label-caption,#8b8b95)', border: '1px dashed rgba(255,255,255,.3)', cursor: 'pointer' } }), tr('list.collapse'))) : null,
        ]),
        // #690：历史票翻页那一行 —— 「已加载 x / 共 N」、翻页位置失效、取不到、后端不支持翻页各说各的
        //   （出处见 views/ListTabClosed.js 的注释；x 与折叠行那两个数同源：就是当前列表里真的画出来的行数）。
        closedPagesNode(h, st, closedRows.length),
        // T3 #5：加载遮罩（替代单行文本，全屏遮罩 + 转圈 + 禁点）
        // v1.3.3 修复：加载遮罩仅首开无数据时显示（手动刷新已走静默路径，不再叠加）
        // #58 缓存优先：已有快照（本 store 或 per-cwd 缓存）时不显示全屏 loading，秒开旧列表 + 后台静默刷新；行形骨架见 #953（同一时刻只用一个主力过程）。
        (st.snapMode === 'loading' && !st.snapshot && !getCachedSnapshot(st.cwd)) ? h('div', { className: 'dsws-loading-shade', style: { position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.45)', backdropFilter: 'blur(2px)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 10, zIndex: 5, pointerEvents: 'auto' } }, [
          h('span', { style: { fontSize: 12, color: '#e6edf3' } }, tr('list.loading')),
          h('div', { 'aria-hidden': 'true', style: { width: '80%', display: 'flex', flexDirection: 'column', gap: 8 } }, ['96%', '82%', '90%', '70%', '86%'].map(function (w, i) { return h('div', { key: i, className: 'dsws-fb-skel', style: { width: w, height: 12, borderRadius: 6 } }) })),
        ]) : null,
        (st.snapMode === 'err' && !st.snapshot && !getCachedSnapshot(st.cwd)) ? h('div', { style: { color: '#f87171', fontSize: 12, padding: '14px 0', textAlign: 'center', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4 } }, [Ic({ n: 'alert', size: 12 }), h('span', null, tr('list.errFull', { err: st.snapError }))]) : null,
        // #715（诚实显示）：这一行说清「这份数据多新、上次刷新成不成、现在是不是降级」。取数时刻取快照的 generatedMs（不是渲染时刻）；判据与词条见 views/shared/truthLines.js，没有事实的那句不画（不替宿主编事实）。
        (function () {
          // 2026-09-22 维护者定：「上次更新」那一条搬去面板头部第一行右侧那个小时间标签（panel/Dock.js），这一行从此只说其余那些状态句（刷新失败 / 已暂停 / 落后 / 已推后 / 未在刷新…），同一条信息不再出现两次。
          const ls = truthNoticeLines(st, Date.now())
          if (!ls.length) return null
          const tone = function (t) { return t === 'red' ? '#f87171' : (t === 'yellow' ? '#f59e0b' : 'var(--dsws-label-caption,#8b8b95)') }
          return h('div', { className: 'dsws-truth', style: { display: 'flex', flexWrap: 'wrap', gap: 8, alignItems: 'center', fontSize: 11, padding: '2px 2px 4px' } }, ls.map(function (ln) { return h('span', { key: ln.kind || ln.key, style: { color: tone(ln.tone) } }, tr(ln.key, ln.params)) }))
        })(),
        // v1.5 B5 降级横幅：走 REST 通道取回来的那份数据要明说 —— 判据（restFallbackView）与画法都在 views/shared/RestFallbackBanner.js。
        h(RestFallbackBanner, { key: 'restFallback', st: st }),
        // #374：状态过滤渲染 —— open 主体 / closed 列表 / 「全部」态保留已关闭折叠行
        showOpen ? (filteredOpen.length === 0 ? h('div', { style: { fontSize: 12, color: 'var(--dsw-alias-label-secondary,#a1a1aa)', padding: '14px 0', textAlign: 'center' } }, tr('list.none')) : filteredOpen.map(function (x) { return listIssueRow(h, st, x, true, narrow, blockOf, colorOf, multiEffort) })) : null,
        showClosedList ? (filteredClosed.length === 0 ? h('div', { style: { fontSize: 12, color: 'var(--dsw-alias-label-secondary,#a1a1aa)', padding: '14px 0', textAlign: 'center' } }, tr('list.none')) : filteredClosed.map(function (x) { return listIssueRow(h, st, x, false, narrow, blockOf, colorOf, multiEffort) })) : null,
        // v14-4⑤：列表底部「已关闭 (N)」折叠行（仅「全部」状态显示；默认收起，只占一行，展开可见）
        // #689：文案改成「已关闭 N（已加载 x）」—— N 是后端计数说的总数，x 是列表里真加载到的行数；
        //   两个不一样时（本仓现在就是）用户一眼能看出「还有多少没装进来」，而不是以为列表就是全部。
        (st.stateFilter === 'all' && closedRows.length) ? h('details', { style: { marginTop: 8 }, onToggle: function (e) { const open = !!(e && e.target && e.target.open); st.closedFoldOpen = open; emit(st); if (open) loadIssuePage(st, { view: 'list' }) } }, [
          h('summary', { style: { fontSize: 11, color: 'var(--dsw-alias-label-caption,#8b8b95)', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4, padding: '4px 2px', userSelect: 'none' } }, [
            Ic({ n: 'check', size: 11 }),
            h('span', null, tr('list.closedN', { n: foldCounts ? foldCounts.closed : closedRows.length, x: closedRows.length })),
          ]),
          h('div', null, closedRows.map(function (x) { return listIssueRow(h, st, x, false, narrow, blockOf, colorOf, multiEffort) })),
        ]) : null,
      ])
    }
