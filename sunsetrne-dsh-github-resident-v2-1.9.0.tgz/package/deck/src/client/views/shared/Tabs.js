/**
 * views/shared/Tabs.js — 共享 tabs 行（阶段 2 叶子迁移 · #97 T4 去重）
 * Dock/Overlay 原各实现一遍的 tabsTip/tabsTipOff/tabBtn + 动作按钮行（wayfinder/bug/刷新 + tooltip + 版本号）
 * 合成此处；消费：`const tabs = useTabsRow(s, tabsRef)`，渲染 `tabs.items`（容器由调用方自备，样式各异）。
 * 契约：模块真源（ESM 导出）；scripts/build.mjs 构建时剥行首 export 拼回
 * src/client/index.js 的 `// ==== leaf:... (spliced by build) ====` 标记处（一源两物）。
 */
export const useTabsRow = function (s, tabsRef) {
  const [tabTip, setTabTip] = React.useState(null)
  const tabsTip = function (e, text, priority) {
    const t = tabsRef && tabsRef.current
    setTabTip(null)
    if (!t || !text || typeof e === 'undefined') return
    // 门控：仅当该 priority 的按钮自身已折叠时才显示 tooltip（文字被藏、需悬浮提示）
    const btn = t.querySelector('[data-priority="' + priority + '"]')
    if (!btn || !btn.classList.contains('collapsed')) return
    if (typeof window === 'undefined') return
    const W = 238
    let x = e.clientX + 12, y = e.clientY + 12
    if (x + W > window.innerWidth) x = e.clientX - 12 - W
    setTabTip({ x: x, y: y, text: text })
  }
  const tabsTipOff = function () { setTabTip(null) }
  const tabBtn = (id, icon, label, priority) => h('button', { className: 'dsws-tab' + (s.tab === id ? ' on' : ''), 'data-priority': priority, onMouseMove: function (e) { tabsTip(e, label, priority) }, onMouseLeave: tabsTipOff, onClick: function () { s.tab = id; emit(s); if (!snapFresh(s)) loadSnapshot(s, false) }, style: { display: 'inline-flex', alignItems: 'center', gap: 4 } }, [
    Ic({ n: icon, size: 12 }),
    h('span', null, label),
  ])
  // #506 拉取请求独立页签：能力门控显隐，只读能力位，不写后端名字。
  const showPr = (typeof prTabVisible === 'function') ? prTabVisible(s) : false
  // #818 版本管理页签（地图 #810）：照「拉取请求」这条先例做能力门控显隐。判据 vcTabVisible 由视图那一侧提供
  //   （会排在 tabs 之前拼接），这里只做「有就用、没有就当这个能力不存在」的兜底，不自己定义它。
  const showVc = (typeof vcTabVisible === 'function') ? vcTabVisible(s) : false
  // 折叠优先级随 #818 调整（原来依次是 列表4 / 拉取请求5 / 技能6 / 环境检查7）：折叠机按数值
  //   从大到小逐个收，数值越大越早让位。新页签插在列表之后、占 5，既有三项各加一档挪成 6/7/8，两个理由：
  //   1) 既有三项之间「拉取请求 → 技能 → 环境检查」的相对折叠次序一个字不动；
  //   2) 新页签紧随列表之后显示，在需要让位的页签里最晚被折叠（比列表先走，比既有三项都晚）。
  const items = [
    tabBtn('list', 'list', tr('panel.tabList'), 4),
    showVc ? tabBtn('versionControl', 'branch', tr('panel.tabVersionControl'), 5) : null,
    showPr ? tabBtn('pr', 'swap', tr('panel.tabPr'), 6) : null,
    tabBtn('skills', 'compass', tr('panel.tabSkills'), 7),
    tabBtn('checks', 'gear', tr('panel.tabChecks'), 8),
    h('span', { style: { flex: 1 } }),
    // v1.5 T6 修订（V2 描边紫 · 刷新左侧）：新增 wayfinder —— 注入 /wayfinder + 仓库信息 + 需求引导
    // issue #4：新增 BUG 单 —— 同构按钮（新会话预填 /wayfinder 新增 BUG 单 prompt）
    h('button', { className: 'dsws-btn', 'data-priority': 2, onMouseMove: function (e) { tabsTip(e, tr('panel.newWayfinderTitle'), 2) }, onMouseLeave: tabsTipOff, onClick: function () { openTextInNewSession(s, newWayfinderText(s), newSessionTitleNew('requirement')) }, style: { display: 'inline-flex', alignItems: 'center', gap: 4, padding: '2px 8px', fontSize: 11, flex: 'none', background: 'transparent', border: '1px solid #c084fc', color: '#c084fc', fontWeight: 600 } }, [
      Ic({ n: 'map', size: 11 }),
      h('span', null, tr('panel.newWayfinder')),
    ]),
    h('button', { className: 'dsws-btn', 'data-priority': 1, onMouseMove: function (e) { tabsTip(e, tr('panel.newBugTitle'), 1) }, onMouseLeave: tabsTipOff, onClick: function () { openTextInNewSession(s, newBugWayfinderText(s), newSessionTitleNew('bug')) }, style: { display: 'inline-flex', alignItems: 'center', gap: 4, padding: '2px 8px', fontSize: 11, flex: 'none', background: 'transparent', border: '1px solid #f87171', color: '#f87171', fontWeight: 600 } }, [
      Ic({ n: 'bug', size: 11 }),
      h('span', null, tr('panel.newBug')),
    ]),
    // T2 #2 那颗「刷新」2026-09-22 挪出这一排了：维护者要求它离开面板的第二排，与「上次更新」的时间盒子
    //   并排放到面板头部第一行右侧（画在 panel/Dock.js 的头部那一行里）。所以这一排从此没有 priority=3
    //   的元素，版本号「什么时候让位」的判据也跟着换了口径 —— 见 Dock.js 折叠机第 3 步（按其真实处境判）。
    (tabTip && portalTop) ? portalTop(h('div', { style: { position: 'fixed', left: tabTip.x, top: tabTip.y, zIndex: 2147483000, padding: '4px 8px', borderRadius: 6, background: 'var(--dsw-alias-bg-layer-3,#0c0e12)', border: '1px solid var(--dsw-alias-border-l2,#3a3f4a)', color: 'var(--dsw-alias-label-primary,#e6edf3)', fontSize: 11, lineHeight: 1.5, pointerEvents: 'none', boxShadow: '0 4px 16px rgba(0,0,0,.4)', maxWidth: 220 } }, tabTip.text)) : null,
    // #repo-link：版本号可点——新窗打开插件仓库主页（DSW_REPO_URL 构建期注入，见 index.js；hover 样式在 styles.js .dsws-ver）
    h(Tip, { content: DSW_REPO_URL }, h('a', { className: 'dsws-ver', href: DSW_REPO_URL, target: '_blank', rel: 'noreferrer', style: { fontSize: 9, flex: 'none', fontVariantNumeric: 'tabular-nums' } }, DSW_VERSION)),
  ]
  return { tabsRef: tabsRef, items: items }
}
