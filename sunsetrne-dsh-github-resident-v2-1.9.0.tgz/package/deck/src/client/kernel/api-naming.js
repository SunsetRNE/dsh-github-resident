/**
 * src/client/kernel/api-naming.js — 内核模块（#457 由 api.js 拆出之交接头、草稿、预设与建会话、命名守护）
 *
 * 契约：本文件为模块真源（ESM 导出）；scripts/build.mjs 在构建时去掉每行行首
 * export 关键字，把声明体文本拼回 src/client/index.js 的拼接标记处（apply 闭包内
 * 原位），与 ctx.js/seam 同模式，一源两物，src 零复制。
 * 接口冻结清单见 docs/architecture/kernel-contract.md（G3 · #91 拍板）。
 */
    export const injectFixate = (st) => { inject(st, fixateText(st)) }

    // v24-48：交接 —— 第一击自动注入 /handoff 模板（带时间戳文件名 + 引导句）并记忆该时间戳；
    // 第二击优先读「第一击模板里的同一个文件」（模板写什么名就读什么名，不再查目录导致旧文件名）；
    // 仅当未点过第一击（如刷新后）才回退 host 查最新实际文档；+ 复制 + 开新空白会话
    // v25 · T2b（F1 修正）：交接两击走模板渲染；{ts} 第一击注入时生成并记忆；
    //   {file} = 第一击模板渲染后解析出的实际文件名（用户改文件名结构也一致），解析失败兜底时间戳 + '.md'
    // #787：交接记忆（时间戳、真实文件名、记下那一刻的目录）已搬进会话自己的 store
    //  （st.handoffTs / st.handoffFile / st.handoffCwd，见 store-snapshot.js），此处不再保留模块级全局，
    //   多会话各记各的，读时目录对不上视为无记忆。
    export const handoffPrompt = function (ts) {
      return renderTemplate('handoff1', { ts: ts })
    }
    // 从第一击注入文本解析 .scratch/handoff/<name>.md 的实际文件名（T1 规格 §2 发现 1；短标题方案下主路径走前缀探测，此处仅兼容保留）
    export const extractHandoffFile = function (text) {
      const m = String(text || '').match(/\.scratch\/handoff\/([^\s"'`]+\.md)/)
      return m ? m[1] : null
    }
    // 拼绝对路径：{path} = cwd/.scratch/handoff/{file}（跨工作区 / 用户自行查看移动用；分隔符跟随 cwd）
    export const absHandoffPath = function (cwd, file) {
      if (!cwd || !file) return file || ''
      const sep = cwd.indexOf('/') >= 0 ? '/' : '\\'
      return (cwd.replace(/[\\/]+$/, '')) + sep + '.scratch' + sep + 'handoff' + sep + file
    }
    export const handoffReadText = function (file, cwd) {
      if (!file) return ''
      return renderTemplate('handoff2', { path: absHandoffPath(cwd, file), file: file })
    }
    // 跨会话预填（issue #12 BUG4 r3 终极修复）：单变量保留，但消费侧彻底锁死 deps 为 [props.sessionId]，
    //   当前会话的 props 重渲染不会再触发 effect 重跑，从根本上消除「当前会话 effect 抢先消费」竞态。
    // r4（#62/#63 回归 2026-08-21）：旧 r3 用 boolean consumedDraftRef 导致首次消费后 ref=true 常驻，任何新会话 effect 直接 return（62/63 新开会话不注入）；且旧单槽是全局单变量，旧会话重渲染若 deps 含 props 可能抢先消费。r4 改为 sid 锚定消费。
    // #787：首条草稿已搬进目标会话自己的 store（storeOf(新编号).incomingDraft，取完清空），此处不再保留模块级全局单槽，
    //   连续创建多个新会话时各归各，不覆盖。
    // ============ 单点工厂 createPTCSession 原子化（#363 · 承接 #361 闸门与 #362 可判定门禁）============
    // 目标：任何入口新建会话必为 PTC 且已归属工作区且首条可原子化注入，三者同一次创建内成立。
    // 工厂是会话创建的唯一出口：所有新建分支都经此函数，入参显式携带 agentPreset:'ptc'。
    // 复用闸门同步谓词：可复用仅当 blank 并且预设健康（首版字面 code 判不健康）并且工作区键非空且等于目标。
    // 空永不复用：空工作区隔离，切断空对空与空对非空的跨区污染（#361 空文件夹幽灵 选 A）。
    export const getRowPreset = function(row) {
      if (!row) return ''
      try {
        if (row.projectionValues && typeof row.projectionValues.agentPreset === 'string' && row.projectionValues.agentPreset) return row.projectionValues.agentPreset
      } catch (e) {}
      try {
        if (row.header && typeof row.header.agentPreset === 'string' && row.header.agentPreset) return row.header.agentPreset
      } catch (e2) {}
      return ''
    }
    export const isHealthyPreset = function(preset) {
      // #478 未知即不可复用：读不到或空一律不健康（投影未到瞬间不得放行，随后显形为 code 的幽灵）。
      // 保留 #361 V1 的字面 code 拒绝并补 broken 拒绝；其余非空值沿用旧语义（未来合法新增预设自动放行，不硬编码四预设名单）。
      const v = String(preset || '').trim()
      if (!v) return false
      if (v === 'code') return false
      if (v === 'broken') return false
      return true
    }
    export const isReusableBlank = function(row, normTarget) {
      if (!row || !row.blank) return false
      const preset = getRowPreset(row)
      if (!isHealthyPreset(preset)) return false
      const rawCwd = row.cwd || ''
      let normRow = ''
      try {
        normRow = typeof keyOf === 'function' ? keyOf(rawCwd) : String(rawCwd || '').trim()
        if (typeof keyOf !== 'function') {
          let tmp = String(rawCwd || '').trim().toLowerCase().split(String.fromCharCode(92)).join('/')
          while (tmp.indexOf('//') >= 0) tmp = tmp.split('//').join('/')
          while (tmp.length > 1 && tmp.charAt(tmp.length - 1) === '/') tmp = tmp.slice(0, -1)
          normRow = tmp
        }
      } catch (e) {
        let tmp = String(rawCwd || '').trim().toLowerCase().split(String.fromCharCode(92)).join('/')
        while (tmp.indexOf('//') >= 0) tmp = tmp.split('//').join('/')
        while (tmp.length > 1 && tmp.charAt(tmp.length - 1) === '/') tmp = tmp.slice(0, -1)
        normRow = tmp
      }
      if (!normRow) return false
      if (normRow !== normTarget) return false
      return true
    }
    export const buildCreateOpts = function(workspaceId, cwd) {
      // 单点入参构造：有工作区标识优先，无则回落路径，但两分支必带 agentPreset:'ptc'（#362 判据 P）
      // #364：回退矩阵的唯一显式锚点——workspaceId 有则走 {workspaceId,ptc}，无则走 {cwd,ptc}，
      //   两分支互斥（防 bad-request workspaceId+cwd 同传），且 cwd 即使为空也携带 ptc 让上层 doFallback 之前仍满足 P。
      if (workspaceId) return { workspaceId: workspaceId, agentPreset: 'ptc' }
      return { cwd: cwd, agentPreset: 'ptc' }
    }
    export const createPTCSession = function(sessions, workspaceId, cwd, text) {
      // 单点工厂：唯一调用 sessions.create 的出口，显式 ptc + 工作区 + 首条原子化（#363）
      // #364 保真与兼容增强：首条在同链路内原子化写入目标会话自己的 store；
      //   若首次创建因 alpha 新参（workspaceId 不认 / agentPreset 更名）抛错，则自动回退到 {cwd,ptc} 或兼容 presetId 重试，
      //   仍保证 ptc 显式且首条不丢，避免因底座入参变化导致创建链中断而丢首条。
      // #787：首条写进目标会话自己的 store（storeOf(新编号).incomingDraft，本会话界面取完清空），
      //   连续创建多个新会话时各归各；storeOf 是闭包调用时依赖（见 kernel-contract）。
      //   P1-2：新编号为空不写（storeOf(空) 会回共用 store，不许污染它），链照走，由调用方回落处理。
      if (!sessions || typeof sessions.create !== 'function') return Promise.reject(new Error('sessions.create not available'))
      const mountDraft = function (sid) { if (sid) storeOf(sid).incomingDraft = text; return sid }
      const opts = buildCreateOpts(workspaceId, cwd)
      const doCreate = function (o) { try { return sessions.create(o) } catch (eSync) { return Promise.reject(eSync) } }
      return doCreate(opts).then(function(sid) {
        // 首条原子化：与创建同链路写入目标会话 store（#787 会话隔离）
        return mountDraft(sid)
      }).catch(function(err) {
        const msg = String((err && err.message) || err || '')
        // 回退 1：workspaceId 不认 → 回落 cwd+ptc（兼容 workspaceId 必填化回退或未登记场景）
        const hasWid = !!(opts && opts.workspaceId)
        if (hasWid && /workspaceId|workspace/i.test(msg) && /bad-request|unknown|invalid|not.*found/i.test(msg)) {
          const fb = buildCreateOpts(null, cwd)
          return doCreate(fb).then(function(sid2) {
            return mountDraft(sid2)
          })
        }
        // 回退 2：agentPreset 更名兼容（如 presetId）→ 试探兼容键
        // #739：0.1.7 系再加裸键 preset 一试（presetId、agentPresetId 仍保留，门禁点名两者不断言第三键）。
        if (/agentPreset|preset/i.test(msg) && /bad-request|unknown|invalid/i.test(msg)) {
          const alt = hasWid ? { workspaceId: workspaceId, presetId: 'ptc' } : { cwd: cwd, presetId: 'ptc' }
          // 同时尝试 agentPresetId 与裸 preset 兜底
          return doCreate(alt).catch(function() {
            const alt2 = hasWid ? { workspaceId: workspaceId, agentPresetId: 'ptc' } : { cwd: cwd, agentPresetId: 'ptc' }
            return doCreate(alt2)
          }).catch(function() {
            const alt3 = hasWid ? { workspaceId: workspaceId, preset: 'ptc' } : { cwd: cwd, preset: 'ptc' }
            return doCreate(alt3)
          }).then(function(sid3) {
            return mountDraft(sid3)
          })
        }
        throw err
      })
    }
    // ============ 命名守护（#265 · 草稿档垂直线 · 界面半渲染钩子）============
    // 分工（#264 D2）：host 常驻轻量任务持跟踪态并产出「待办改名计划单」（wf.namingPlan）；
    // 本侧只做渲染钩子 —— 拉取计划单、按本机语言落地档位词、经会话门面（face.rename）执行改名、回报结果。
    // 纯判定真源 = src/shared/naming-titles.js 等 3 个文件（构建经 shared:namingTitles 等 3 个 splice 注入本闭包，无第二处实现）。
    // 旧 #211 的 5 秒手改跳过标记（死代码）自本版起全面移除：手改保护由值比对锁真检测承担。
    // #709（T5）：从前这里有 NAMING_POLL_MS = 5000 与 _namingPollTimer（自续轮询用）。两者随轮询一起退役。
    let _namingPullBusy = false
    // #746：排队单执行跳过的原因账（每会话每窗口只记一次，防刷屏；窗口关掉账就没了，本来也只用来定位当场问题）
    export let _skipLogged = {}
    // 值比对锁的「当前标题」来源：会话列表快照 byId[sid].title（DSH 客户端会话服务的公开快照仓库，控制流推送会更新它）。
    // 2026-10-03 核查：客户端 sessions 服务没有 get(sid)（get 在宿主侧 dsh-session 那套服务上），从前那条「优先实时接口」
    // 分支永远走不到，已删；快照是客户端唯一真源（#315 担心的旧照片竞态由控制流推送 + 执行前二次确认兜住）。
    export function namingCurrentTitleOf(sid) {
      try {
        const sessions = ctx.get('sessions')
        if (!sessions || !sessions.list || typeof sessions.list.getSnapshot !== 'function') return null
        const snap = sessions.list.getSnapshot()
        const row = snap && snap.byId ? snap.byId[sid] : null
        if (row && typeof row.title === 'string' && row.title) return row.title
      } catch (e) {}
      return null
    }
    export function namingHintOf(st, title) {
      // #746：线索源恢复——#345 移除面包屑后本函数恒为空，占位永远拿不到语义名；
      //   现改从本次占位标题直接取语义段（去首个 [...] 前缀，留 80 字），零 token、本机可算；
      //   沙箱桩忽略多余入参，旧调用形状可直接替换。
      try {
        const t = String((typeof title === 'string' && title) ? title : '')
        const seg = t.replace(/^\s*\[[^\]]*\]\s*/, '').trim().slice(0, 80)
        return seg ? seg : null
      } catch (eH) { return null }
    }
    function reportNamingResult(sid, outcome, extra) {
      try {
        if (typeof host !== 'undefined' && typeof host.call === 'function') {
          host.call('wf.namingResult', Object.assign({ sessionId: sid, outcome: outcome }, extra || {})).catch(function (e) { try { log('warn', 'host.call.fail', { method: 'wf.namingResult', kind: 'naming-result', errorHash: dswsLogHash(dswsLogTrunc(String((e && e.message) || e), 120, 'error')) }) } catch (eL) {} })
        }
      } catch (e) {}
    }
    // 执行一条计划单：值比对锁判定（判手改即锁定回报，永不触碰）→ 按档位合成目标名
    //   （draft 本机语言落地 composeDraftTitle；numbered 语言无关 newSessionTitle —— [#n] 前缀
    //    契约 #205 由共享核心保证永不破坏）→ face.rename → 回报
    export function executeNamingOrder(o) {
      if (!o || !o.sessionId) return
      const sid = o.sessionId
      const lock = o.lock || {}
      const cur = namingCurrentTitleOf(sid)
      if (cur === null) { try { if (isEnabled('debug') && !_skipLogged[sid]) { _skipLogged[sid] = 1; log('debug', 'naming.guard.event', { reason: 'skip-cur-null-' + dswsLogHash(sid) }) } } catch (eDbg) {}; return }  // 当前标题不可读：本轮跳过，绝不盲写
      // 先合成目标名，再归因：这样「现名已经就是目标」也能被归因认出来（宿主刚改完、这里拿同一张单再跑一遍是常事）。
      let target = null
      if (o.kind === 'draft') {
        let langIsEn = false
        try { langIsEn = typeof promptLang === 'function' && promptLang() === 'en' } catch (eLang) {}
        target = composeDraftTitle({ hint: o.hint, lang: langIsEn ? 'en' : 'zh', baselineTitle: (o.lock && o.lock.baselineTitle) || '' })
      } else if (o.kind === 'numbered') {
        const num = Number(o.number)
        if (!isFinite(num) || num < 0) return
        try { target = newSessionTitle({ number: num, numberText: o.numberText, title: o.title || '' }) } catch (eT) { return }
      } else {
        return
      }
      // 分歧归因只问共享核心一处：在位就收敛回报，让位就回报并把理由带走（宿主照原样记进 naming.lock）。
      const code = classifyDivergence({ currentTitle: cur, lastMachineTitle: lock.lastMachineTitle, baselineTitle: lock.baselineTitle, baselineIsOurs: lock.baselineIsOurs, firstUserText: lock.firstUserText, titleSource: lock.titleSource, targetTitle: target })
      if (lock.locked || code === DIVERGENCE.HAND_EDIT) { try { log('info', 'naming.guard', { sidHash: dswsLogHash(sid), outcome: 'locked', hintHash: dswsLogHash(o.hint || '') }) } catch (eL) {}; reportNamingResult(sid, 'locked', { currentTitle: cur, reason: code }); return }
      if (code === DIVERGENCE.UNKNOWN_TITLE) { try { if (isEnabled('debug') && !_skipLogged[sid]) { _skipLogged[sid] = 1; log('debug', 'naming.guard.event', { reason: 'skip-unknown-' + dswsLogHash(sid) }) } } catch (eDbg) {}; return }
      // 收敛只认「现名逐字等于目标」：现名是我们写的但还不是目标时必须继续写，不能收敛——
      // 否则占位永远升不上草稿（#746 交接卡死：在位是指到达目标，不是有我们经手过）。
      if (!target || target === cur) { try { log('info', 'naming.guard', { sidHash: dswsLogHash(sid), outcome: 'renamed', hintHash: dswsLogHash(o.hint || '') }) } catch (eL) {}; reportNamingResult(sid, 'renamed', { title: cur || target }); return }  // 已在位（含上次改名刚落定）→ 收敛记账
      try {
        const sessions = ctx.get('sessions')
        if (!sessions || typeof sessions.scope !== 'function' || typeof sessions.sessionOf !== 'function') return
        const scope = sessions.scope(sid)
        const face = scope ? sessions.sessionOf(scope) : null
        if (!face || typeof face.rename !== 'function') return
        // #315 防御：若面对象暴露会话标识，校验必须与订单 sid 一致，防止跨会话错写（宿主对非当前会话面解析回退到当前会话时拦截）
        try {
          const faceSid = (face && (face.sessionId || face.id || face.sid)) || (scope && (scope.sessionId || scope.id || scope.sid))
          if (faceSid && String(faceSid) !== String(sid)) {
            reportNamingResult(sid, 'failed', { error: 'session face mismatch: expected ' + sid + ' got ' + faceSid })
            return
          }
        } catch (eFaceCheck) {}
        // 二次校验：执行前再次确认当前标题仍为判定时的 cur，防止并发改名竞态错写
        try {
          const cur2 = namingCurrentTitleOf(sid)
          if (cur2 !== cur) {
            reportNamingResult(sid, 'failed', { error: 'title changed before rename' })
            return
          }
        } catch (eCur2) {}
        Promise.resolve(face.rename(target)).then(function (r) {
          try { log('info', 'naming.guard', { sidHash: dswsLogHash(sid), outcome: (r && r.ok) ? 'renamed' : 'failed', hintHash: dswsLogHash(o.hint || '') }) } catch (eL) {}
          if (r && r.ok) reportNamingResult(sid, 'renamed', { title: (r.value && r.value.title) || target })
          else reportNamingResult(sid, 'failed', { error: (r && r.error && r.error.message) || 'rename failed' })
        }).catch(function () { reportNamingResult(sid, 'failed', { error: 'rename rejected' }) })
      } catch (eExec) {}
    }
    // ==== 面板级失败可见性（#267 · F4）====
    // 定败（有限重试耗尽）会话的两条化解路，均「只读探测、绝不盲写」：
    //   手改 → 值比对锁判 locked 回报（「手改永不被覆盖」闭环收尾，横幅随锁定终局消失）；
    //   值一致（上次实际改名已落定但回报丢失）→ 按目标名收敛记账 renamed。
    export function reconcileNamingFailure(f) {
      if (!f || !f.sessionId || typeof classifyDivergence !== 'function') return false
      const sid = f.sessionId
      const cur = namingCurrentTitleOf(sid)
      if (!cur) return false
      const lock = f.lock || {}
      const code = classifyDivergence({ currentTitle: cur, lastMachineTitle: lock.lastMachineTitle, baselineTitle: lock.baselineTitle, baselineIsOurs: lock.baselineIsOurs, firstUserText: lock.firstUserText })
      if (code === DIVERGENCE.UNKNOWN_TITLE) return false
      if (lock.locked || code === DIVERGENCE.HAND_EDIT) { reportNamingResult(sid, 'locked', { currentTitle: cur, reason: code }); return true }
      let target = null
      if (f.kind === 'numbered' || f.stage === NAMING_STAGES.NUMBERED) {
        const num = Number(f.number)
        if (!(isFinite(num) && num >= 0)) return false
        try { target = newSessionTitle({ number: num, numberText: f.numberText, title: f.numberTitle || '' }) } catch (eT) { return false }
      } else {
        let langIsEn = false
        try { langIsEn = typeof promptLang === 'function' && promptLang() === 'en' } catch (eLang) {}
        target = composeDraftTitle({ hint: f.hint, lang: langIsEn ? 'en' : 'zh', baselineTitle: (lock && lock.baselineTitle) || '' })
      }
      if (target && target === cur) { reportNamingResult(sid, 'renamed', { title: cur }); return true }
      return false
    }
    // 定败清单 → 共享 store（DetailsDock 常驻横幅消费）；账目里会话已消失的不呈现（防幽灵横幅，账不动）。
    export function applyNamingFailurePanel(failures) {
      try {
        const arr = Array.isArray(failures) ? failures : []
        let rows = null
        try {
          const sessions = ctx.get('sessions')
          if (sessions && sessions.list && typeof sessions.list.getSnapshot === 'function') {
            const snap = sessions.list.getSnapshot()
            rows = snap && snap.byId ? snap.byId : {}
          }
        } catch (eR) {}
        const vis = arr.filter(function (f) { return f && f.sessionId && (!rows || rows[f.sessionId]) }).map(function (f) {
          return Object.assign({}, f, { _title: (rows && rows[f.sessionId] && rows[f.sessionId].title) ? String(rows[f.sessionId].title) : '' })
        })
        const sh = storeOf(null)
        const key = JSON.stringify(vis)
        if (sh.namingFailKey !== key || !sh.namingFailures) {
          sh.namingFailKey = key
          sh.namingFailures = vis
          emit(sh)
        }
      } catch (eF) {}
    }
    // 渲染钩子：拉取计划单 → 执行 → 回报（防重入；host 无单时零开销）
    // #266 追加：tracked 终局清理 —— 已终局（锁定/编号落定）且会话已不存在于 DSH 列表的
    //   受踪账目经 wf.cancelNewSessionWatcher 注销（防账目堆积；未终局项绝不误删）。
    export function namingGuardianKick() {
      if (typeof host === 'undefined' || typeof host.call !== 'function') return
      if (_namingPullBusy) return
      _namingPullBusy = true
      host.call('wf.namingPlan', {}).then(function (res) {
        _namingPullBusy = false
        if (!res || !res.ok || !Array.isArray(res.orders)) { try { log('warn', 'host.call.fail', { method: 'wf.namingPlan', kind: 'naming-plan', errorHash: dswsLogHash(dswsLogTrunc('plan-not-ok', 120, 'error')) }) } catch (eL) {}; return }
        for (let i = 0; i < res.orders.length; i++) executeNamingOrder(res.orders[i])
        // #267：定败清单 → 只读协商化解 + 落共享 store（面板级横幅；化解即自动撤下）
        try {
          const fails = Array.isArray(res.failures) ? res.failures : []
          for (let i = 0; i < fails.length; i++) { try { reconcileNamingFailure(fails[i]) } catch (eRec) {} }
          applyNamingFailurePanel(fails)
        } catch (ePanel) {}
        try {
          if (!Array.isArray(res.tracked)) return
          const sessions = ctx.get('sessions')
          if (!sessions || !sessions.list || typeof sessions.list.getSnapshot !== 'function') return
          const snap = sessions.list.getSnapshot()
          const rows = snap && snap.byId ? snap.byId : null
          if (!rows) return
          for (let i = 0; i < res.tracked.length; i++) {
            const t = res.tracked[i]
            if (t && t.done && !rows[t.sessionId]) {
              host.call('wf.cancelNewSessionWatcher', { sessionId: t.sessionId }).catch(function (e) { try { log('warn', 'host.call.fail', { method: 'wf.cancelNewSessionWatcher', kind: 'naming-cancel', errorHash: dswsLogHash(dswsLogTrunc(String((e && e.message) || e), 120, 'error')) }) } catch (eL) {} })
            }
          }
        } catch (eClean) {}
      }).catch(function (e) { try { log('warn', 'host.call.fail', { method: 'wf.namingPlan', kind: 'naming-plan', errorHash: dswsLogHash(dswsLogTrunc(String((e && e.message) || e), 120, 'error')) }) } catch (eL) {}; _namingPullBusy = false })
    }
    // #709（T5）：命名守护的客户端拉询改事件驱动 —— 从前那条 5 秒自续轮询（NAMING_POLL_MS + tick）
    // 整体退役，客户端侧不再有任何自续定时器。
    // 为什么删得掉：宿主侧那三条宿主事件（`gh issue create` 被拦截、新会话注册、认领推送）已经把
    //「什么时候可能出编号」说清了；客户端这边只要在四种事件到来时催一次即可：
    //   切进工作区、点「重新检查」、做完可能改变它的动作（初始化 / 绑定后端 / 装技能）、写入成功之后。
    export function namingGuardianEvent(why) {
      const reason = String(why || 'event')
      try { if (isEnabled('debug')) log('debug', 'naming.guard.event', { reason: reason }) } catch (eL) {}
      namingGuardianKick()
    }
    // 随 apply 启动。注意这里**不启动任何循环**：只把上一代 apply（旧版本）万一留下的轮询清掉，
    // 然后做一次拉取（等价于「刚切进这个工作区」那一次）。
    export function startNamingGuardianEvents() {
      try {
        if (typeof globalThis !== 'undefined' && globalThis.__dswsNamingPollTimer) { try { clearTimeout(globalThis.__dswsNamingPollTimer) } catch (ePrev) {} globalThis.__dswsNamingPollTimer = null }
      } catch (eGuard) {}
      namingGuardianEvent('apply-start')
    }
    // 需求1（2026-08-18）：交接按钮 = 第一击（注入 /handoff 模板，不再变字）；「新会话交接」小按钮 = 原第二击逻辑
    // 需求1·二阶段 rev（2026-08-18）：灰/亮双态的真实依据 = 磁盘上确实存在交接文档（wf.handoffLatest 探测）。
    //   probeHandoffReady：探测 → 写 st.handoffReady + emit（右半亮蓝/灰 + 允许/禁止 的开关）；任何路径都不得在无文档时开新会话。
    // issue #12 BUG4 · 主路径（r2 终极形态）：用户刚点过第一击（handoffFile 已设）→ 直接用 handoffFile 作为 prompt
    //   文件名 + 亮蓝，**不查磁盘**。理由：prompt 必须与第一击注入的 `/handoff` 模板时间戳一致（用户视角的「两段文本应该对应同一份文档」），
    //   即便 AI 还没落盘，handoff-open 仍应预填 handoffFile（保证两段 prompt 一致）。若 AI 真没写，新会话 `/read` 会失败 —— 那是 AI 行为问题。
    //   未点过第一击（handoffFile=null，如刷新后 / 直接点右半）→ 调 wf.handoffLatest 探磁盘取 mtime 最新。
    //   始终返回 Promise.resolve(done(...))，让调用方（doHandoffOpen / probe chain）能稳定 .then。