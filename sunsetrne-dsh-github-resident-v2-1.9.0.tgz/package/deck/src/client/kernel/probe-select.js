/**
 * src/client/kernel/probe-select.js —— 后端选定的两条专用轨迹（#727 从 probe-snapshot.js 拆出）
 *
 * 契约：本文件为模块真源（ESM 导出）；scripts/build.mjs 在构建时去掉每行行首 export 关键字，
 * 把声明体文本拼回 src/client/index.js 里那条 probeSelect 拼接标记处（apply 闭包内原位），
 * 与 ctx.js/seam 同模式，一源两物，src 零复制。接口清单见 docs/architecture/kernel-contract.md。
 * 为什么拆出来：probe-snapshot.js 一直贴着「单文件 ≤350 行」那条上限（拆之前 280 行，
 *   加上本票这两段就过线了；#707 也是为同一个原因从它身上拆出过颜色与差异那三样）。
 *
 * 本文件管两件事，都与「这个工作区用哪个后端」这条事实有关：
 *   ① askSelectionOnce —— 进工作区时补问一次宿主那条专用电话（wf.selection）。
 *   ② 「那次快照等超时了、但它后来还是回来了」的回包怎么落地（_snapRequestKeyWas 判据 +
 *      _installLateSnapshotSelection 落地）。这两件事共用一条界线（_snapInstallState 声明在
 *      probe-snapshot.js，与那次请求的登记同处），所以同住一处。
 *
 * 为什么要有这两件事（真机现场 2026-09-24，skill-calorie 会话目录 D:\ilife\packages\skill-calorie）：
 *   刚进会话时横幅写「该工作区还没有设置 — 点击选择后端」，而旁边「环境 10/10」是绿的、更新时间
 *   也是真实时刻；打开一次右侧面板、或切到别的会话再切回来，就正常了。两条原因：
 *   ①「用哪个后端」这条几十字节的事实，原先只能搭最重的那趟车（wf.snapshot / wf.refresh 那份完整快照）
 *     才回得来，而客户端对它有一条固定的 30 秒死线（client loadSnapshot timeout 30s）；冷启动的大
 *     工作区（这个现场：52 张地图 / 950 张票 / 741 子票 / 磁盘快照 9.7 MB）首次重建要几分钟，死线
 *     一到客户端就放弃、什么都不装。参考：同期的「环境」那一格走 wf.chain、「时间」走 wf.probe，
 *     两条都没有这条死线 —— 所以只有「后端」这一格是空的。
 *   ② 那份回包后来还是到了（真机 12:16:21 落盘，客户端最后一次放弃是 12:16:19），可它一到就被
 *      原先那道守卫整份丢掉：守卫拿「回包自己带回来的工作区根」去比「请求发出时那条子目录键」，
 *      而正是这次的守卫自己先教会了客户端那个根 —— 比出来必然不等，于是判成「这个工作区换过了」。
 *      超时之后又没有任何重试（startAutoProbe 只在成功分支被调），所以那份结果永久作废。
 * 三条不变量（本文件与门禁 tests/verify-subdir-first-frame.js 按这三条写）：
 *   I1 便宜且专用：一条事实只由一条代价相称的专用通道投递。
 *   I2 未知 ≠ 否：「还没读到」必须与「确实没有设置」分开表达，凡涉及「未知」的判据都不推进状态机。
 *   I3 迟到的正确结果必须能落地：30 秒死线只决定「这次等待结束」，不决定「这份结果作废」。
 * 以后谁改它：改「进工作区时要不要补问一次后端」「迟到的快照回包还收不收」的人。
 *   probe-snapshot.js 那边只留接线（doLoad 里那几行调用）。
 */

// 进工作区时补问一次「这个工作区用哪个后端」（I1：几十字节的事实不搭 16 MB 的车）。
// 宿主那边这条电话本来就有（wf.selection），只是界面进工作区时一条都不用 —— 全仓原先只有设置页在调。
// 判据（口径只此一处）：
//   · 手上有后端时不问（缓存先命中就不该再打这条电话）；cwd 还不认识时也不问
//     （拿宿主的默认目录去问等于替用户认一个工作区 —— 那不叫修，那叫猜）。
//   · 每个工作区只问一次（幂等、限次）：问过就记在 st._selAskedKey 上，失败也不重问、不弹提示。
//   · 回包里 selection 为空时什么都不做（I2）：那是「还没读到证据」，不是「没有设置」。
// 拿到的那条走的是与快照同一条合并口（mergeSelection，住在 store-snapshot.js），
// 所以面板头、状态栏、引导链读到的都是同一份结论，不用各自改口径。
export const askSelectionOnce = function (st) {
  try {
    if (!st || typeof host === 'undefined' || typeof host.call !== 'function') return null
    if (st.selection && st.selection.backendId) return null
    if (!st.cwd) return null
    const k = wsKeyOf(st.cwd)
    if (!k) return null
    if (st._selAskedKey === k) return null
    st._selAskedKey = k
    // I2 的表达面：从这一刻起，「后端还说不准」这件事有了一个真的在途原因 ——
    //   状态栏据此不说「该工作区还没有设置」（见 statusbar/StatusBar.js 的 _selReading）。
    st.selPending = true
    emit(st)
    const method = 'wf.selection'
    const t0 = Date.now()
    // 跨边界调用先记一行（按需级，外层先判开关），与收到回包那一行配成一对。
    try { if (isEnabled('debug')) log('debug', 'host.call', { method: method, kind: 'selection', ok: true, latencyMs: 0 }) } catch (eL) {}
    return host.call(method, { cwd: st.cwd }).then(function (res) {
      try {
        const okRes = !!(res && (res.ok === true || (res.value && res.value.ok === true)))
        if (okRes) log('info', 'host.call', { method: method, latencyMs: Date.now() - t0, ok: true, kind: 'selection' })
        else log('warn', 'host.call.fail', { method: method, kind: 'selection', errorHash: dswsLogHash(dswsLogTrunc(String((res && res.error) || 'selection-failed'), 120, 'error')) })
      } catch (eL) {}
      // I2：回包里没有选择就是「还不知道」，什么都不做 —— 绝不拿空值去顶替一个结论。
      try {
        const sel = (res && res.selection) || (res.value && res.value.selection) || null
        if (sel && typeof mergeSelection === 'function' && mergeSelection(st, sel)) emit(st)
      } catch (eSel) {}
      st.selPending = false
      emit(st)
      return res
    }).catch(function (e) {
      try { log('warn', 'host.call.fail', { method: method, kind: 'selection', errorHash: dswsLogHash(dswsLogTrunc(String((e && e.message) || e), 120, 'error')) }) } catch (eL) {}
      st.selPending = false
      emit(st)
      return null
    })
  } catch (eAsk) { return null }
}

// 那份「等超时了、后来还是回来了」的回包，还能不能收下 —— 按**请求发出时**那条目录比。
// 为什么要换尺子：原来拿「回包自己带回来的根」去比「请求时那条子目录键」，而 learn 那一步就发生在
//   同一份回包里（先教会客户端根、再比对），于是子目录会话的第一份回包必判「工作区换过了」。
// 换尺子不许丢掉 #232 R4 / #45 的原意：请求时目录 A、现在目录 B（会话真的换走了）仍然判过期，
//   那条反证写在新门禁的「反向」一组里（把这条判据改回原样，子目录那一式必须变红）。
// 三种情形的判法：
//   · 请求时那条目录还是现在这条（两把键相等）：收。这就是改动前的旧判据，一行没动。
//   · 请求那条键上已经学到过根：拿同一个根重算这把请求键 —— 学到根之后它必然等于现在这把键。
//   · 两条都不成立（请求时目录 A、现在目录 B）：不收。
export const _snapRequestKeyWas = function (reqNorm, st) {
  try {
    const raw = (st && st.cwd) || ''
    if (!reqNorm || reqNorm === wsKeyOf(raw)) return true
    const hit = (typeof workspaceRootByCwd === 'object' && workspaceRootByCwd) ? workspaceRootByCwd[reqNorm] : ''
    if (hit && keyOf(hit) === wsKeyOf(raw)) return true
    return false
  } catch (e) { return false }
}

// 迟到的成功回包（Promise.race 已经判超时、可这份回包还是回到了）：至少把 selection 这一小块装上，
// 它正是「用哪个后端」那条事实的载体（I3）。为什么必须落地：死线只结束了「这次等待」，
//   而这份结果是真的、只差没赶上；不装的话用户只能靠再点一次刷新或换个会话再切回来才看得见它。
// 只装 selection 与 repository —— 快照正文那一大块等下一次正常取数，不在这里偷偷换掉用户正在看的画面。
// 三个前提缺一不可：这一次还没走过正常那一路、这条键上后面没发过更新的一次（且后端没换过）、
//   工作区没真的换走（#45 串台防线）。
export const _installLateSnapshotSelection = function (st, snap, reqNorm, mine) {
  try {
    if (!snap || !st || !mine) return false
    // #1009 收口 F1：迟到落地只在真的放弃等待之后生效。正常那一路先回来时，这一次还没放弃，
    //   这里一个字节都不装，也不再记那一行日志（原来靠正常路后置的标记挡，会被微任务顺序绕过）。
    if (!mine.gaveUp) return false
    // 同一次请求已装过就不重复装（按这次请求判，不跨请求共享；全局 handedOff 已退役）。
    if (mine.done === true) return false
    // 后来发过更新的一次、或用户已经换到别的后端：与正常那一路同一把尺子，扔（#669 第 5 件）。
    if (typeof _snapRespStale === 'function' && _snapRespStale(reqNorm, mine.seq, mine.reqBackend, st)) return false
    if (!_snapRequestKeyWas(reqNorm, st)) return false
    mine.done = true
    let changed = false
    if (snap.selection !== undefined && typeof mergeSelection === 'function') { try { if (mergeSelection(st, snap.selection)) changed = true } catch (eSel) {} }
    if (snap.repository !== undefined) { try { st.repository = snap.repository; if (st.cwd) setCachedRepository(st.cwd, snap.repository) } catch (eRep) {} }
    st.selPending = false
    try { st.snapPending = false } catch (ePendLate) {}
    if (changed) emit(st)
    // 这条轨迹按需记：迟到本身就少见，而「为什么这一格后来自己好了」正是以后要查的那一问。
    try { if (isEnabled('debug')) log('debug', 'snapshot.late.install', { keyHash: dswsLogHash(reqNorm), installed: !!changed }) } catch (eL) {}
    return changed
  } catch (eLate) { return false }
}

// #1009：装一份「真的拿到了」的快照。正常那一路与迟到那一路共用这一处 ——
//   两处各写一遍的话，判据（缓存优先落表、补标签颜色、回填布局、清错误态）迟早长岔。
// 装与不装由调用方判（_snapRespStale / _snapRequestKeyWas）；本函数只管装，返回 true = 装上了。
export const _snapInstallBody = function (st, snap) {
  try {
    if (!st || !snap || snap.ok !== true || !Array.isArray(snap.maps)) return false
    // v1.5 T10 R4：数据层增量 diff（新旧快照对比）—— 供多视图增量与 R5 视觉
    st.lastDiff = diffSnapshots(st.snapshot, snap)
    st.rowFlash = {}
    st.issueFlash = {}
    var _df = st.lastDiff
    _df.added.forEach(function (n) { st.rowFlash[n] = 'added' })
    _df.changed.forEach(function (n) { st.rowFlash[n] = 'changed' })
    if (_df.issueFlash) Object.keys(_df.issueFlash).forEach(function (k) { st.issueFlash[k] = _df.issueFlash[k] })
    // R5 视觉：有变化才提示 + 定时清除高亮（防堆积）
    if (_df.removed.length) flash(st, tr('panel.diffRemoved', { n: _df.removed.length }), 'info')
    scheduleFlashClear(st)
    st.snapshot = snap
    try { if (snap.setupLayout && typeof setCachedSetupLayout === 'function') setCachedSetupLayout(st.cwd, snap.setupLayout) } catch (eSL) {} // #683（F1 · R6）：宿主记住的布局回填本地（两壳各答一样时按时刻仲裁，本地刚点的那一下不会被顶回去）
    // #635：这份快照如果是「保存前就发出去、保存后才回来」的那一次刷新拿回来的，它不知道刚改过的
    // 标签颜色，装进来就会把面板倒回旧色。装进来之后先按那次保存确认过的色值补一遍，
    // 补的规则与记录都住在 views/labels/labelColorPatch.js（比那份记录旧才补，新的就作废记录）。
    try { if (typeof lcApplySavedColorsOnInstall === 'function') lcApplySavedColorsOnInstall(st, st.snapshot) } catch (eLC) {}
    st.snapMode = 'real'
    st.snapError = null
    // #155：同步 selection/repository 镜像
    try { if (typeof applySnapshotSelection === 'function') applySnapshotSelection(st, snap) } catch {}
    // #58 缓存优先：落内存表，供新会话秒开 — suspicious fallback 不污染缓存
    // #653：这里从前会先把同一份快照按 snap.repoRoot 存一把、再按所选目录存一把（两把键，两个桶），
    //   子目录会话与根会话因此各看各的。现在 setCachedSnapshot 自己按工作区键（wsKeyOf）落，
    //   只需要一次调用，同一工作区天然同桶。
    try {
      const nxt = snap.selection
      const cur = st.selection
      const isSuspicious = !!(nxt && nxt.backendId===null && !nxt.pending && nxt.source==='fallback' && cur && cur.backendId)
      if (!isSuspicious) {
        setCachedSnapshot(st.cwd, snap)
      }
    } catch (e) { /* 忽略 */ }
    // 拉取 backendModules（若 snapshot 未带，则另调 registry）
    try {
      if (!st.backendModules && typeof host !== 'undefined' && host.call) {
        host.call('wf.registry', { cwd: st.cwd }).then(function(r){
          if (r && r.ok && Array.isArray(r.modules)) { st.backendModules = r.modules; try{ setPresentationMap(r.modules) }catch{}; emit(st) }
        }).catch(function(){})
      }
    } catch {}
    // v1.5 T10：启动自动变化探测（幂等；快照就绪后生效）
    startAutoProbe()
    // v1.5 B5 修订：磁盘缓存秒开（fromCache）→ 不再 400ms 强制全量刷新。
    //   原逻辑每次打开面板 = 1 次额外 wf.refresh（aliases 大查询 ≈ 18 GraphQL 点），
    //   多仓库会话下成倍放大；变化检测已由低频 probe（5min + focus 限流）接管，
    //   磁盘缓存本身是最新全量快照，秒开直接展示即可，无需立即重建。
    return true
  } catch (e) { return false }
}

// #1009：等超时了、可那份回包后来还是回来了 —— 它算不算数、怎么算数。三种走法：
//   ① 还是这把工作区键上最新的一次、后端没换过、工作区也没真的换走 → **整份装上**，并把「上一次刷新」
//      那根针往前拨一次（这份数据确实是刚拿回来的）。为什么不再只补 selection 那一小块（#727 那版的做法）：
//      真机上更常见的后果是宿主辛苦拿回来的那份被丢掉，用户既没看到新数据、下一次还得整趟重跑。
//   ② 工作区确实换走了 → 不装进新视图（#45 串台防线照旧），但按**请求时那把键**落进内存表：
//      结果不作废，切回那个工作区时秒开。
//   ③ 回来的不是完整正文（304 / 空结果）→ 退回 #727 的原做法：只补 selection 与仓库引用那一小块。
// 三个前提：真的放弃等待过（mine.gaveUp，只在超时那一支立）、同一个请求的正常那一路没装过
//  （mine.done，两边同时就绪的竞态）、这份没被判过期；整份装之前再比一次数据新旧（最新者胜）。
export const _installLateSnapshot = function (st, snap, reqNorm, mine) {
  try {
    if (!snap || !st || !mine) return false
    // #1009 收口 F1：同上。超时那一支立 flag 之前，迟到的处理器不许装（正常回包先到正是这种情况）。
    if (!mine.gaveUp) return false
    if (mine.done === true) return false
    if (typeof _snapRespStale === 'function' && _snapRespStale(reqNorm, mine.seq, mine.reqBackend, st)) return false
    const hasBody = !!(snap.ok === true && Array.isArray(snap.maps))
    if (!hasBody) return _installLateSnapshotSelection(st, snap, reqNorm, mine)
    if (!_snapRequestKeyWas(reqNorm, st)) {
      try { setCachedSnapshot(reqNorm, snap) } catch (eC) {}
      return false
    }
    // #1009 收口 F2：装之前比数据新旧（最新者胜）。两边都有时间戳才比大小，来者大才装；
    //   只有一边有时，有值者胜；两边都没有时退回上面的序号判，不因缺字段丢掉。
    //   丢掉时沿用既有事件记一行（字段只用 keyHash 与 installed，不加字段），原因靠 installed:false 表达。
    try {
      const _incMs = (snap && typeof snap.generatedMs === 'number' && snap.generatedMs > 0) ? snap.generatedMs : 0
      const _curMs = (st.snapshot && typeof st.snapshot.generatedMs === 'number' && st.snapshot.generatedMs > 0) ? st.snapshot.generatedMs : 0
      if (_incMs > 0 && _curMs > 0) {
        if (!(_incMs > _curMs)) {
          try { if (isEnabled('debug')) log('debug', 'snapshot.late.install', { keyHash: dswsLogHash(reqNorm), installed: false }) } catch (eOld) {}
          try { st.snapPending = false } catch (ePendOld) {}
          return false
        }
      } else if (_incMs === 0 && _curMs > 0) {
        try { if (isEnabled('debug')) log('debug', 'snapshot.late.install', { keyHash: dswsLogHash(reqNorm), installed: false }) } catch (eOld2) {}
        try { st.snapPending = false } catch (ePendOld2) {}
        return false
      }
    } catch (eCmp) {}
    mine.done = true
    st.snapLoading = false
    try { st.snapPending = false } catch (ePendDone) {}
    const installed = _snapInstallBody(st, snap)
    if (installed) {
      try { touchProbeAt(reqNorm) } catch (ePA) {}
      try { emit(st) } catch (eE) {}
    }
    // 这条轨迹按需记：迟到本身就少见，而「为什么这一格后来自己好了」正是以后要查的那一问。
    try { if (isEnabled('debug')) log('debug', 'snapshot.late.install', { keyHash: dswsLogHash(reqNorm), installed: !!installed }) } catch (eL) {}
    return installed
  } catch (eLate2) { return false }
}
