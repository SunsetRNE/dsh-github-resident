/**
 * src/client/kernel/store-snapshot.js — 内核模块（#455 由 store.js 拆出之存储核、快照与链缓存、水合与提醒）
 *
 * 契约：本文件为模块真源（ESM 导出）；scripts/build.mjs 在构建时去掉每行行首
 * export 关键字，把声明体文本拼回 src/client/index.js 的拼接标记处（apply 闭包内
 * 原位），与 ctx.js/seam 同模式，一源两物，src 零复制。
 * 接口冻结清单见 docs/architecture/kernel-contract.md（G3 · #91 拍板）。
 */
    export const makeStore = () => ({
      open: false, tab: 'list', activeMap: null, activeIssue: null,
      // #552 导航栈（会话私有状态）：只存坐标不存正文，元素形状 { kind: 'map' | 'issue', n: 数字编号 }；
      // 进入压栈、返回弹栈、空栈回列表；activeMap 与 activeIssue 过渡期保留为栈顶镜像。
      navStack: [],
      issueCache: {}, issueMode: 'idle', issueError: null, issueDetail: null, issueCommentsMoreLoading: false, issueCommentsFailCount: 0, issueCommentsHasMore: true,
      // #255 评论输入区（受控）：草稿/提交态/分流错误/服务端确认闪烁
      cmtDraft: '', cmtSending: false, cmtError: null, cmtConfirm: null,
      notice: null, injector: null, tick: 0,
      pos: null, size: { w: 460, h: DEFAULT_PANEL_H },
      // 外观定死（用户拍板：图标/动作词不可配置）
      ui: { icon: 'compass', word: '沉淀' },
      snapshot: null,
      selection: null,
      repository: null,
      backendModules: null,
      backendMenuOpen: false,
      backendMenuPos: null,
      cwd: '', lblFilters: [], effFilters: [], expLabels: false,
      // 由 wf.cwd 带回来的工作区根（2026-09-19 加）：归属标志的早到来源，收下与写表在 probe-snapshot.js。
      sessionWorkspaceRoot: '',
      // #374：状态过滤 + 排序（默认 更新时间↓，与现状一致）
      stateFilter: listPrefs.stateFilter, sortKey: listPrefs.sortKey, sortDir: listPrefs.sortDir,
      chainSnapshot: null, chainLoadedAt: '', backendChain: null, fullChain: null,
      snapMode: 'loading', snapError: null, snapLoading: false,
      // #727：后端那条事实的读取状态。selPending =「这个工作区用哪个后端」还说不准、而且有真的在途原因（面板取数在飞，或那条专用电话在飞）；_selAskedKey = 已经为哪个工作区补问过那条电话（见 probe-select.js）。
      selPending: false, _selAskedKey: '',
      // T2 HoverTip 迁移（#381）：skillTip 已由 HoverTip 局部 state 统一，移除全局，skillHover 保留用于行高亮（后续可改 CSS :hover 再移除）
      refreshing: false, rowFlash: {}, issueFlash: {}, handoffReady: false, handoffSearching: false,
      // #787 交接会话隔离（会话私有状态）：本会话记下的时间戳、真实文件名、记下那一刻的目录。
      //   无记忆时为 null/空串；读时当时目录与当前目录对不上视为无记忆（fail-closed），绝不串到别的会话。
      handoffTs: null, handoffFile: null, handoffCwd: '',
      // #787 发出去防抖计时（800 毫秒）住会话自己身上；无记忆为 0。
      _lastHandoffOpenTs: 0,
      // #787 待注入本会话的首条草稿（别的会话交接过来）；本会话界面取完清空。
      incomingDraft: null,
      skillsOpen: false, skillHover: null, bugMenuOpen: false, bugMenuHover: false, bugMenuPos: null, takeMenuOpen: false, takeMenuHover: false, takeMenuPos: null, skillPopPos: null, expTags: {}, subs: [],
      noRepoCard: { expanded: false, name: '', visibility: 'private', loading: false, error: '', errorKind: '', errorRepoUrl: '' },
      switchConfirm: null,
      gateModalOpen: false, gateSelected: null, gateLoading: false, gateError: '',
    })
    // ── 工作区键：分桶一律按「工作区根」，不按会话所选目录（#653，规则见 #649 定版记录 3.2 节）──
    // 为什么客户端要认这条路：宿主从 #652 起把「哪个目录算这个会话的工作区」锚到了工作区根，
    //   而客户端这五样抽屉（面板快照、检查链快照、在途去重、后端选择镜像、仓库引用）此前都按
    //   「会话所选目录」分桶。同一个仓库里，根会话与子目录会话因此各占一桶、互不相认——
    //   子目录会话打开面板时看不到根会话已经取好的数据，只会空着。
    // 客户端自己算不出工作区根（要读文件系统：逐层向上找 `.git` 或主锚文件），所以这个值由宿主给：快照回包里的 workspaceRoot 一项。没拿到时一律退回所选目录，行为与改动前一致（诚实失败，不猜）。
    // 存法：所选目录的规整键 → 工作区根（在装快照时记下）。同一张表里也把「工作区根 → 工作区根」记一份，于是在途去重那种手上只有请求键的场景传进来也能命中自己。
    export const workspaceRootByCwd = {}
    export const rememberWorkspaceRoot = function (selected, root) {
      try {
        const sk = (typeof keyOf === 'function') ? keyOf(selected) : String(selected || '')
        const rk = (typeof keyOf === 'function') ? keyOf(root) : String(root || '')
        if (sk && rk) workspaceRootByCwd[sk] = rk
        if (rk) workspaceRootByCwd[rk] = rk
        // #683（F1 · ADR 的 R7d）：工作区根是**后来才**认出来的 —— 原先那份选择与布局按「会话所选目录」那把键存着，而从此读写都改走根键，老键那条就此没人再看（界面会一边说 Markdown、另一边说「还没有设置」）。认到根的这一刻把它搬过去；根键上已经有了就不动它。
        if (sk && rk && sk !== rk) { try { if (typeof migrateCachedChoiceToKey === 'function') migrateCachedChoiceToKey(sk, rk) } catch (eMv) {} }
      } catch (e) {}
    }
    // 分桶用的钥匙：给所选目录，回工作区根；认不出（宿主还没回过话）就回所选目录本身。
    export const wsKeyOf = function (selected) {
      try {
        const k = (typeof keyOf === 'function') ? keyOf(selected) : String(selected || '')
        if (!k) return ''
        const hit = workspaceRootByCwd[k]
        if (hit) return hit
        // 兜底两条：手上这份快照自己带着工作区根（磁盘缓存刚回放、或别的会话已经装过一次），
        // 以及 LRU 里那条记录。都能认出就顺手记进表，下一次直接命中。
        try { const e = snapshotByCwd.get(k); const r = e && e.snapshot && e.snapshot.workspaceRoot; if (r) { const rk = (typeof keyOf === 'function') ? keyOf(r) : String(r); if (rk) { workspaceRootByCwd[k] = rk; workspaceRootByCwd[rk] = rk; return rk } } } catch (e1) {}
        return k
      } catch (e) { return '' }
    }
    export const shared = makeStore()
    export const stores = {}
    // #58 缓存优先：按工作区键的内存快照表（新 store 秒开 + 跨会话同工作区共享，避免空 cwd 探路 miss）
    // 单源工作区键（#301 / #324）：全库仅一份 keyOf，经 shared:workspaceKey 拼入；#653 起分桶再走 wsKeyOf 锚到工作区根
    export const SNAP_CWD_LRU_MAX = 20
    export const snapshotByCwd = new Map() // Map<normCwd,{snapshot,version,ts}> LRU20
    export const touchLRUClient = function(map,key,val){ if(map.has(key)) map.delete(key); map.set(key,val); if(map.size>SNAP_CWD_LRU_MAX){ const first=map.keys().next().value; map.delete(first);} return val; }
    const dswsClientSnapHitN = { n: 0 } // #498 客户端快照命中采样计数（百一采样，只增不显）
    export const getCachedSnapshot = function (cwd) { try{ const k=wsKeyOf(cwd); const e=snapshotByCwd.get(k); const s=e?e.snapshot||e:null; try { if (s) { dswsClientSnapHitN.n += 1; if (isEnabled('debug') && dswsClientSnapHitN.n % 100 === 0) log('debug', 'client.snapshot.hit', { keyHash: dswsLogHash(String(k)), ageMs: Date.now()-(((e&&e.ts)||Date.now())), kind: 'memory' }) } } catch(eL){} return s; }catch(e){ return null; } }
    export const getCachedEntry = function(cwd){ try{ const k=wsKeyOf(cwd); return snapshotByCwd.get(k)||null; }catch(e){ return null; } }
    // 落缓存：键 = 工作区键（#653 起锚到工作区根，子目录会话与根会话同桶）
    export const setCachedSnapshot = function (cwd, snap) { if(!cwd||!snap||snap.ok!==true||!Array.isArray(snap.maps)) return; let s2=snap; if(snap.notModified===true||snap.status===304||snap.cached===true){ // #232 · 落库前剥除响应传输态标记（仅属当次请求，不属缓存实体）
      try{ s2=Object.assign({},snap); delete s2.notModified; delete s2.status; delete s2.cached; }catch(eS){ return } }
      try{ const k=wsKeyOf(cwd); const ver=s2.version||s2.etag||''; const ent={snapshot:s2, version:ver, ts:Date.now(), key:k, lastProbeAt:getProbeAt(k)}; touchLRUClient(snapshotByCwd,k,ent); try{ diskPutSnapshot(k, ent) }catch(eD1){} }catch(e){} }
    export const getSnapshotVersion = function(cwd){ try{ const e=getCachedEntry(cwd); return e?e.version||'':''; }catch(e){ return ''; } }
    // ============ #327 特性 A/B：上次探测时间 + 快照多级缓存（内存→磁盘→网络）============
    export const lastProbeAtByCwd = new Map() // Map<工作区键, ms> —— 对该工作区完成任一次检查（探针/刷新/快照校验）即推进，数据不变也走针
    export const getProbeAt = function (cwd) { try { const v = lastProbeAtByCwd.get(wsKeyOf(cwd)); return v || 0 } catch (e) { return 0 } }
    export const touchProbeAt = function (cwd, ms) {
      try {
        const k = wsKeyOf(cwd); if (!k) return
        lastProbeAtByCwd.set(k, ms || Date.now())
        // 组内全量会话走针：同工作区的 shared/stores 全部 emit，状态栏随重渲染取新时间
        try { if (shared.cwd && wsKeyOf(shared.cwd) === k) emit(shared) } catch (e1) {}
        try { Object.keys(stores).forEach(function (kk) { const st2 = stores[kk]; if (st2 && st2.cwd && wsKeyOf(st2.cwd) === k) emit(st2) }) } catch (e2) {}
      } catch (e) {}
    }
    export const SNAP_DISK_CAP = 24
    const _snapDbPromise = (function () {
      try {
        if (typeof window === 'undefined' || !window.indexedDB || !window.indexedDB.open) return null
        return new Promise(function (resolve) {
          let req
          try { req = window.indexedDB.open('dsws-cache', 1) } catch (e0) { resolve(null); return }
          req.onupgradeneeded = function () { try { req.result.createObjectStore('snapshots') } catch (e00) {} }
          req.onsuccess = function () { resolve(req.result) }
          req.onerror = function () { resolve(null) }
          req.onblocked = function () { resolve(null) }
        })
      } catch (e) { return null }
    })()
    // 落盘：fire-and-forget；条目形如 {key, snapshot, version, ts, lastProbeAt}；超出 SNAP_DISK_CAP 按最旧淘汰
    export const diskPutSnapshot = function (k, entry) {
      try {
        if (!_snapDbPromise || !k || !entry) return
        _snapDbPromise.then(function (db) {
          if (!db) return
          try {
            const st = db.transaction('snapshots', 'readwrite').objectStore('snapshots')
            st.put(entry, k)
            const allReq = st.getAll()
            allReq.onsuccess = function () {
              try {
                const rows = (allReq.result || []).filter(function (r) { return r && r.key })
                if (rows.length <= SNAP_DISK_CAP) return
                rows.sort(function (a, b) { return (a.ts || 0) - (b.ts || 0) })
                const kill = rows.slice(0, rows.length - SNAP_DISK_CAP)
                const tx2 = db.transaction('snapshots', 'readwrite').objectStore('snapshots')
                kill.forEach(function (r) { try { tx2.delete(r.key) } catch (e3) {} })
              } catch (eEv) {}
            }
          } catch (eTx) {}
        }).catch(function () {})
      } catch (e) {}
    }
    export const diskGetSnapshot = function (k) {
      try {
        if (!_snapDbPromise || !k) return Promise.resolve(null)
        return _snapDbPromise.then(function (db) {
          if (!db) return null
          return new Promise(function (resolve) {
            try {
              const req = db.transaction('snapshots', 'readonly').objectStore('snapshots').get(k)
              req.onsuccess = function () { try { resolve(req.result || null) } catch (e2) { resolve(null) } }
              req.onerror = function () { resolve(null) }
            } catch (e) { resolve(null) }
          })
        }).catch(function () { return null })
      } catch (e) { return Promise.resolve(null) }
    }
    // 链快照共享缓存（#324 · 键 = 工作区键 + 后端 id + 语言；#529 加语言维：中英快照分开存；#653：这里的「工作区键」走 wsKeyOf 锚到工作区根）
    export const CHAIN_CWD_LRU_MAX = 20
    export const chainByCwd = new Map() // Map<工作区键+'|'+backendId+'|'+lang, {snapshot, ts}>
    export const getChainCacheKey = function(cwd, backendId, lang){ try{ return wsKeyOf(cwd) + '|' + String(backendId||'') + '|' + String(lang||''); }catch(e){ return String(cwd||'')+'|'+String(backendId||'')+'|'+String(lang||''); } }
    export const getCachedChain = function(cwd, backendId, lang){ try{ const k=getChainCacheKey(cwd, backendId, lang); const e=chainByCwd.get(k); return e?e.snapshot:null; }catch(e){ return null; } }
    export const setCachedChain = function(cwd, backendId, lang, snap){ if(!cwd||!snap) return; try{ const k=getChainCacheKey(cwd, backendId, lang); const ent={snapshot:snap, ts:Date.now()}; if(chainByCwd.has(k)) chainByCwd.delete(k); chainByCwd.set(k, ent); if(chainByCwd.size>CHAIN_CWD_LRU_MAX){ const first=chainByCwd.keys().next().value; chainByCwd.delete(first);} }catch(e){} }
    // 水合守卫：刚点的那一下不被旧缓存盖掉（#1003 接替 userPicked 标记；只看时间，不落盘）。
    export const justPicked = function (st, c) {
      try {
        const sel = st && st.selection
        if (!sel || !sel.backendId || typeof sel.pickedAt !== 'number' || sel.pickedAt <= 0) return false
        const cacheMs = (c && typeof c.generatedMs === 'number' && c.generatedMs > 0) ? c.generatedMs : 0
        if (cacheMs > 0) return sel.pickedAt > cacheMs
        const incBid = c && c.selection && c.selection.backendId
        return !!(incBid && String(incBid) !== String(sel.backendId) && (Date.now() - sel.pickedAt) < 60000)
      } catch (e) { return false }
    }
    export const hydrateFromCache = function (st) {
      if (!st || !st.cwd) return false
      const c = getCachedSnapshot(st.cwd)
      // #653：这份缓存自己带着工作区根时先记住它，随后所有抽屉都按工作区根找（子目录会话秒显根会话的数据）
      try{ if(c && c.workspaceRoot) rememberWorkspaceRoot(st.cwd, c.workspaceRoot) }catch(eWr){}
      try{ if(c){ const _k=wsKeyOf(st.cwd); const _e=snapshotByCwd.get(_k); if(_e) touchLRUClient(snapshotByCwd,_k,_e);} }catch(e){}
      let changed=false
      // 胜负自证（#495）：记合并前双方版本号与谁胜出，串门时单行 #28 即可判定，不用跨行推理
      let _winnerVer = '', _loserVer = '', _outcome = 'current'
      if (c) {
        // 版本取舍：以最新生成时间者胜（水合与扇出一致，#301 契约）
        const incomingMs = c.generatedMs || 0
        const curMs = (st.snapshot && st.snapshot.generatedMs) || 0
        const _incVer = String((c && (c.version || c.etag)) || '')
        const _curVer = String((st.snapshot && (st.snapshot.version || st.snapshot.etag)) || '')
        _winnerVer = _curVer; _loserVer = _incVer
        if (!st.snapshot || incomingMs > curMs) {
          _winnerVer = _incVer; _loserVer = _curVer; _outcome = 'incoming'
          st.snapshot = c
          st.snapMode = 'real'
          st.snapError = null
          st.snapLoading = false
          changed=true
        } else if (st.snapMode !== 'real' && incomingMs === curMs) {
          st.snapMode = 'real'
          st.snapError = null
          changed=true
        } else if (!st.snapshot && c) {
          st.snapshot = c
          st.snapMode = 'real'
          st.snapError = null
          changed=true
        }
        // 同步 selection：水合的是旧缓存（切换前结论），刚点的那一下（pickedAt 更新）不合并，宿主新回包照旧纠正。
        if (c.selection !== undefined && !justPicked(st, c)) { if (mergeSelection(st, c.selection)) changed = true }
        if (c.repository !== undefined) { st.repository = c.repository; setCachedRepository(st.cwd, c.repository) }
        if (c.backendModules) { st.backendModules = c.backendModules; setPresentationMap(c.backendModules) } // backendModules 缓存
      }
      // selection 单独缓存兜底已随镜像退役而删（真相在宿主文件里，不在本地）。
      if (!st.repository) {
        const rep = getCachedRepository(st.cwd)
        if (rep) { st.repository = rep; changed=true }
      }
      // 链快照共享水合（#324 · 键 = 工作区键 + 后端 id + 语言；#529 加语言维，与 loadChain 同口径）
      try {
        const backendId = (st.selection && st.selection.backendId) || (c && c.selection && c.selection.backendId) || ''
        const chainLang = (typeof promptLang === 'function' ? promptLang() : 'zh')
        const cachedChain = getCachedChain(st.cwd, backendId, chainLang)
        if (cachedChain && !st.chainSnapshot) {
          st.chainSnapshot = cachedChain
          st.chain = cachedChain.chain || cachedChain
          st.fullChain = cachedChain.fullChain || null
          st.backendChain = cachedChain.backendChain || null
          st.chainLoadedAt = (typeof nowStr === 'function' ? nowStr() : '')
          st.chainLangLoaded = chainLang // #529：水合即该语言快照，记下供语言切换判定
          changed = true
        } else if (cachedChain && st.chainSnapshot) {
          // 已有链但缓存更新：以生成时间或加载时间新者为准
          const curT = st.chainLoadedAt || 0
          const cachedT = (cachedChain.generatedMs || cachedChain.ts || 0)
          // 简化：若不同对象则更新，保持最终一致
          if (cachedChain !== st.chainSnapshot) {
            // 保留选择：若缓存非空则覆盖，确保同工作区链一致
            // 不强制覆盖，避免闪烁，仅当缺失时秒显已处理；扇出时会统一覆盖
          }
        }
      } catch (eChainHydrate) {}
      try { if (changed) log('info', 'snapshot.hydrate', { cwdHash: dswsLogHash(st.cwd), source: 'memory', fresh: true, latencyMs: 0, winnerVersion: _winnerVer, loserVersion: _loserVer, outcome: _outcome }) } catch (eL) {}
      return changed
    }
    /**
     * 客户端 selection 合并唯一点（#1003：真相即宿主回包；本地无镜像，不写回）。
     *  - 有后端：覆盖；显式空：覆盖；fallback 空且当前有值：保留（防抖）；pending：保留。
     */
    export const mergeSelection = function (st, incoming) {
      if (!incoming || typeof incoming !== 'object') return false
      incoming = (typeof keepUserPick === 'function') ? keepUserPick(st.selection, incoming) : incoming
      if (!incoming.backendId) {
        if (incoming.pending) return false
        if (incoming.source === 'explicit') {
          try { log('info', 'backend.switch', { from: String((st.selection && st.selection.backendId) || ''), to: String(incoming.backendId || ''), cwdHash: dswsLogHash(st.cwd) }) } catch (eL) {}
          st.selection = incoming
          return true
        }
        const cur = st.selection
        if (cur && cur.backendId) return false // fallback null：尊重当前，不覆盖
          try { log('info', 'backend.switch', { from: String((st.selection && st.selection.backendId) || ''), to: String(incoming.backendId || ''), cwdHash: dswsLogHash(st.cwd) }) } catch (eL) {}
        st.selection = incoming
        return true
      }
      try { log('info', 'backend.switch', { from: String((st.selection && st.selection.backendId) || ''), to: String(incoming.backendId || ''), cwdHash: dswsLogHash(st.cwd) }) } catch (eL) {}
      st.selection = incoming
      return true
    }
    export const applySnapshotSelection = function (st, snap) {
      if (!st || !snap) return
      if (snap.selection !== undefined) {
        // 2026-08-28 审查：合并语义收口到 mergeSelection——真相>意图>fallback 尊重意图>pending 保留
        mergeSelection(st, snap.selection)
      }
      if (snap.repository !== undefined) {
        const curSel = st.selection
        const nxtSel = snap.selection
        const isSuspiciousFallback2 = !!(nxtSel && nxtSel.backendId===null && !nxtSel.pending && nxtSel.source==='fallback' && curSel && curSel.backendId)
        if (isSuspiciousFallback2) {
          // keep old repository as well
        } else {
          st.repository = snap.repository; if (st.cwd) setCachedRepository(st.cwd, snap.repository)
        }
      }
      if (snap.backendModules) { st.backendModules = snap.backendModules; setPresentationMap(snap.backendModules) }
      if (snap.repository && snap.repository.backend) {
        // 兼容旧 snapshot.repo 字段
        if (!st.snapshot) st.snapshot = snap
      }
    }
    export const getCwdSync = function (sid) {
      try {
        const sessions = ctx.get('sessions')
        if (sessions && sid) {
          try {
            if (sessions.list && typeof sessions.list.getSnapshot === 'function') {
              const snap = sessions.list.getSnapshot()
              const hit = ((snap && snap.byId) || {})[sid] || (function(){ try { const ls = snap && snap.items; if (Array.isArray(ls)) { for (let i = 0; i < ls.length; i++) { const r = ls[i]; if (r && (r.id === sid || r.sessionId === sid)) return r } } } catch (eScan) {} return null })()
              const rcwd = hit && (hit.cwd || hit.path || hit.directory || hit.workspacePath || hit.worktree || hit.projectDir || (hit.header && (hit.header.cwd || hit.header.path)) || (hit.meta && (hit.meta.cwd || hit.meta.path)))
              if (typeof rcwd === 'string' && rcwd) return rcwd
            }
          } catch (e2) {}
          if (typeof sessions.get === 'function') {
            const s = sessions.get(sid)
            if (s) {
              const header = s.header || s.meta
              const cwd = header && (header.cwd || header.path || header.worktree || header.projectDir || header.directory || header.workspacePath || header.root)
              if (typeof cwd === 'string' && cwd) return cwd
              const meta = s.meta
              const cwd2 = meta && (meta.cwd || meta.path || meta.worktree || meta.projectDir || meta.directory || meta.workspacePath || meta.root)
              if (typeof cwd2 === 'string' && cwd2) return cwd2
              if (typeof s.cwd === 'string' && s.cwd) return s.cwd
            }
          }
        }
      } catch (e) { /* 忽略 */ }
      return ''
    }
    export const storeOf = (sid) => {
      if (!sid) { return shared }
      let st = stores[sid]
      if (!st) {
        st = makeStore(); st.sessionId = sid; stores[sid] = st; try { if (typeof namingGuardianEvent === 'function') namingGuardianEvent('store-touch') } catch (eNT) {} try { if (typeof installDialogSignals === 'function') installDialogSignals() } catch (eDS) {} // #746 会话store首次落定顺带拉取并装对话框焦点监听（每会话每窗口一次；对话框挂载必经此路）
        // #58 新 store 同步补 cwd 并尝试水合 per-cwd 缓存（秒开）
        if (!st.cwd) {
          const sync = getCwdSync(sid)
          if (sync) st.cwd = sync
        }
        if (st.cwd) hydrateFromCache(st)
      } else {
        // 已有 store 若 cwd 仍空且可同步补齐，立即水合
        if (!st.cwd) {
          const sync = getCwdSync(sid)
          if (sync) { st.cwd = sync; hydrateFromCache(st) }
        }
      }
      return st
    }
    export const emit = (st) => { st.tick++; (st.subs || []).forEach(function (f) { f(st.tick) }) }
    export const sub = (st, f) => { st.subs.push(f); return () => { const i = st.subs.indexOf(f); if (i >= 0) st.subs.splice(i, 1) } }
    export const useStore = (sid) => {
      const st = storeOf(sid)
      const [, set] = React.useState(0)
      React.useEffect(() => sub(st, (n) => set(n)), [st])
      return st
    }
    // #77：「浮层小提示」这一族（NOTICE_COLOR / noticeIcon / flash）已搬去 kernel/notice.js ——
    //   退场相位要第二段定时器，这一份贴着 358 行冻结线，塞不进去。

